package verto.sintatico;
import verto.Verto;
import verto.exception.ErroSintaticoException;
import verto.lexico.Lexico;
import verto.semantico.Semantico;

/*
 * $Id: Sintatico.java,v 1.7 2008/04/24 12:01:25 ricardo Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2010 Lucas Eskeff Freitas
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

/**
 * Classe: Analisador Sint�tico
 * 
 * Este Analisador Sint�tico utiliza a t�cnica da An�lise Recursiva Descendente
 * que � uma t�cnica Top-Down. Para ser bem sucedida a an�lise, a gram�tica deve
 * pertencer a fam�lia das linguagens LL(1) 
 *  
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * @author Vandersilvio da Silva
 *  
 * @see Lexico
 * @see Sintatico
 * @see Semantico
 * @see ErroSintaticoException
 * 
 * @version 2.6.2
 */
public class Sintatico {

	/* A A��o semantica vem depois do reconhecimento da regra */
	
	private Lexico lexico;
	private Semantico semantico;
	
    private StringBuffer saidaSintatico;
    
    // Variavel utilizada na regra comando para tratar an�lise sint�tica de blocos sem comandos
    private boolean blocoVazio = true;
	
	public Sintatico( String linhas ) {

		saidaSintatico = new StringBuffer();
		
		lexico = new Lexico( linhas );
		
		semantico = new Semantico( lexico );

		programa();

	}
	
	/** 
	 * Metodo que implementa a regra [010]: 
	 * <programa> :- <declaracoes_globais> <funcoes>
	 */
	private void programa() {

		Verto.getInstance().setUltimaAcaoSintatica( "programa()" );
		
		semantico.acaoSemantica( 0 );
		if ( lexico.isTipoTokenAtual() ) {
			declaracoesGlobais();
			semantico.acaoSemantica( 2 );
		}
		semantico.acaoSemantica( 3 );
		prototipos();
		funcoes();
		reconheceRegra( "programa" );
		semantico.acaoSemantica( 900 );
		semantico.acaoSemantica( 999 );
	}

	/** 
	 * Metodo que implementa as regras [015] e [016]: 
	 * <declaracoes_globais> :- <declaracao_global> <declaracoes_globais>
	 * 			  	  		 |  <declaracao_global>
	 */
	private void declaracoesGlobais() {

		Verto.getInstance().setUltimaAcaoSintatica( "declaracoesGlobais()" );

		declaracaoGlobal();
		while ( ( lexico.getToken() != Lexico.T_FUNCAO ) &&
			    ( lexico.getToken() != Lexico.T_PROTOTIPO )) {
			declaracaoGlobal();
			reconheceRegra( "declaracoesGlobais" );
		}
	}

	/** 
	 * Metodo que implementa as regras [017] e [018]: 
	 * <prototipos> :- <prototipo> <prototipos>
	 * 			 	|  <prototipo>
	 */
	private void prototipos() {

		Verto.getInstance().setUltimaAcaoSintatica( "prototipos()" );
		
		if (lexico.getToken() == Lexico.T_PROTOTIPO ) {

			semantico.acaoSemantica( 17 );
			prototipo();
			while ( lexico.getToken() == Lexico.T_PROTOTIPO ) {
				prototipo();
				reconheceRegra( "prototipos" );
			}
		}
	}

	/** 
	 * Metodo que implementa as regras [020] e [021]: 
	 * <funcoes> :- <funcao> <funcoes>
	 * 			 |  <funcao>
	 */
	private void funcoes() {

		Verto.getInstance().setUltimaAcaoSintatica( "funcoes()" );

		semantico.acaoSemantica( 20 );
		funcao();
		while ( lexico.getToken() == Lexico.T_FUNCAO ) {
			funcao();
			reconheceRegra( "funcoes" );
		}
	}

	/** 
	 * Metodo que implementa a regra [025]: 
	 * <funcao> :- funcao <stipo> <id_funcao> ( <prms> ) <corpo_funcao> 
	 */
	private void funcao() {

		Verto.getInstance().setUltimaAcaoSintatica( "funcao()" );

		if ( lexico.getToken() == Lexico.T_FUNCAO ) {
			lexico.proximoToken();
			superTipo();
			identificadorFuncao();
			if ( lexico.getToken() == Lexico.T_ABRE_PAR ) {
				lexico.proximoToken();
				parametros( 51 );
				if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
					lexico.proximoToken();
					corpoFuncao();	
					reconheceRegra( "funcao" );
					semantico.acaoSemantica( 25 );
				} else {
					throw new ErroSintaticoException( "Eu esperava encontrar aqui: ')', mas encontrei: " +
													  lexico.getLexema() + " na linha: " +
													  lexico.getLinha() );
				}	
			} else {
				throw new ErroSintaticoException( "Eu esperava encontrar aqui: '(', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui a palavra reservada: 'FUNCAO', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}

	/** 
	 * Metodo que implementa a regra [026]: 
	 * <prototipo> :- prototipo <stipo> <id_prototipo> ( <prms> ) ; 
	 */
	private void prototipo() {

		Verto.getInstance().setUltimaAcaoSintatica( "prototipo()" );
		
		if ( lexico.getToken() == Lexico.T_PROTOTIPO ) {
			lexico.proximoToken();
			superTipo();
			identificadorPrototipo();
			if ( lexico.getToken() == Lexico.T_ABRE_PAR ) {
				lexico.proximoToken();
				parametros( 53 );
				if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
					lexico.proximoToken();
					if ( lexico.getToken() == Lexico.T_PONTO_VIRGULA ) {
						lexico.proximoToken();
						reconheceRegra( "prototipo" );
						semantico.acaoSemantica( 26 );	
					} else {
						throw new ErroSintaticoException( "Eu esperava encontrar aqui: ';', mas encontrei: " +
								  lexico.getLexema() + " na linha: " +
								  lexico.getLinha() );
					}
				} else {
					throw new ErroSintaticoException( "Eu esperava encontrar aqui: ')', mas encontrei: " +
													  lexico.getLexema() + " na linha: " +
													  lexico.getLinha() );
				}	
			} else {
				throw new ErroSintaticoException( "Eu esperava encontrar aqui: '(', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui a palavra reservada: 'FUNCAO', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}

	/** 
	 * Metodo que implementa a regra [030]: 
	 * <corpo_funcao> :- { <declaracoes_locais> <comandos> } 
	 */
	private void corpoFuncao() {

		Verto.getInstance().setUltimaAcaoSintatica( "corpoFuncao()" );

		if ( lexico.getToken() == Lexico.T_ABRE_CHAVE ) {
			lexico.proximoToken();
			if ( lexico.isTipoTokenAtual() ) {
				declaracoesLocais();
				semantico.acaoSemantica( 32 );
			}
			semantico.acaoSemantica( 33 );
			comandos();
			if ( lexico.getToken() == Lexico.T_FECHA_CHAVE ) {
				lexico.proximoToken();
				reconheceRegra( "corpoFuncao" );
			} else {
				throw new ErroSintaticoException( "Eu esperava encontrar aqui: '}', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui: '{', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}

	/** 
	 * Metodo que implementa as regras [035] e [036]: 
	 * <declaracoes_locais> :- <declaracao_local> <declaracoes_locais>
	 * 			  	  		|  <declaracao_local>
	 */
	private void declaracoesLocais() {

		Verto.getInstance().setUltimaAcaoSintatica( "declaracoesLocais()" );

		declaracaoLocal();
		while ( lexico.isTipoTokenAtual() ) {
			declaracaoLocal();
			reconheceRegra( "declaracoesLocais" );
		}
	}

	/** 
	 * Metodo que implementa a regra [040]: 
	 * <declaracao_global> :- <declaracao> ; 
	 */
	private void declaracaoGlobal() {

		Verto.getInstance().setUltimaAcaoSintatica( "declaracaoGlobal()" );

		declaracao();
		if ( lexico.getToken() == Lexico.T_PONTO_VIRGULA ) {
			lexico.proximoToken();
			reconheceRegra( "declaracaoGlobal" );
			semantico.acaoSemantica( 40 );
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui ';', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}

	/** 
	 * Metodo que implementa a regra [045]: 
	 * <declaracao_local> :- <declaracao> ; 
	 */
	private void declaracaoLocal() {

		Verto.getInstance().setUltimaAcaoSintatica( "declaracaoLocal()" );

		declaracao();
		if ( lexico.getToken() == Lexico.T_PONTO_VIRGULA ) {
			lexico.proximoToken();
			reconheceRegra( "declaracaoLocal" );
			semantico.acaoSemantica( 45 );
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui ';', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}

	/** 
	 * Metodo que implementa a regra [047]: 
	 * <id_funcao> :- <identificador> ; 
	 */
	private void identificadorFuncao() {

		Verto.getInstance().setUltimaAcaoSintatica( "identificadorFuncao()" );

		identificador();
		reconheceRegra( "identificadorFuncao" );
		semantico.acaoSemantica( 47 );
	}

	/** 
	 * Metodo que implementa a regra [048]: 
	 * <id_prototipo> :- <identificador> ; 
	 */
	private void identificadorPrototipo() {

		Verto.getInstance().setUltimaAcaoSintatica( "identificadorPrototipo()" );

		identificador();
		reconheceRegra( "identificadorPrototipo" );
		semantico.acaoSemantica( 48 );
	}

	/** 
	 * Metodo que implementa as regras [050] e [051]: 
	 * <prms> :- <parametro> , <prms>
	 * 		  |  <parametro>
	 */
	private void parametros( int acaoSemantica ) {

		Verto.getInstance().setUltimaAcaoSintatica( "parametros()" );

		if ( lexico.getToken() != Lexico.T_FECHA_PAR ) {
			parametro();
			while ( lexico.getToken() == Lexico.T_VIRGULA ) {
				lexico.proximoToken();
				parametro();
				reconheceRegra( "parametros" );
			} 
		} else {
		    reconheceRegra( "sem parametros" );
		}
		semantico.acaoSemantica( acaoSemantica );
	}

	/** 
	 * Metodo que implementa a regra [055] e [056]: 
	 * <declaracao>	:- 	<tipo> <lista_decl_ids>
     *              | 	constante <tipo> <lista_decl_ids>							[056]
	 * 
	 */
	private void declaracao() {

        Verto.getInstance().setUltimaAcaoSintatica( "declaracao()" );

        if ( lexico.getToken() == Lexico.T_CONSTANTE ) {
            lexico.proximoToken();
            tipo();
            listaDeclaracoesConstantes();
            semantico.acaoSemantica( 56 );
        } else {
            tipo();
            listaDeclaracoesIdentificadores();
            semantico.acaoSemantica( 55 );
        }
        reconheceRegra( "declaracao" );
    }

	/** 
	 * Metodo que implementa as regras [060] e [061]: 
	 * <lista_decl_ids>	:- <decl_id> , <lista_decl_ids>
	 * 		  |  <decl_id>
	 */
	private void listaDeclaracoesIdentificadores() {

		Verto.getInstance().setUltimaAcaoSintatica( "listaDeclaracoesIdentificadores()" );

		declaracaoId();
		while ( lexico.getToken() == Lexico.T_VIRGULA ) {
			lexico.proximoToken();
			declaracaoId();
			reconheceRegra( "listaDeclaracoesIdentificadores" );
		}
	}

	/** 
	 * Metodo que implementa as regras [062] e [063]: 
	 * <lista_decl_constantes>	:- <decl_constante> , <lista_decl_constantes>
	 * 		  |  <decl_constante>
	 */
	private void listaDeclaracoesConstantes() {

		Verto.getInstance().setUltimaAcaoSintatica( "listaDeclaracoesConstantes()" );

		declaracaoConstante();
		while ( lexico.getToken() == Lexico.T_VIRGULA ) {
			lexico.proximoToken();
			declaracaoConstante();
			reconheceRegra( "listaDeclaracoesConstantes" );
		}
	}
	
	/** 
	 * Metodo que implementa as regras [065] a [068]: 
	 * <decl_id> :- <identificador> ; 
	 */
	private void declaracaoId() {

		Verto.getInstance().setUltimaAcaoSintatica( "declaracaoId()" );

		semantico.acaoSemantica( 64 ); /* regra com finalidade de acumular offset */
		identificador();
		if ( lexico.getToken() == Lexico.T_ABRE_COLCHETES ) {
			lexico.proximoToken();
			numero();
			if ( lexico.getToken() == Lexico.T_FECHA_COLCHETES ) {
				lexico.proximoToken();
				semantico.acaoSemantica( 68 );
			} else {
				throw new ErroSintaticoException( "Eu esperava encontrar aqui: ']', mas encontrei: " +
						  lexico.getLexema() + " na linha: " +
						  lexico.getLinha() );
			}
		} else {
			semantico.acaoSemantica( 65 );
		}
		
		reconheceRegra( "declaracaoId" );
	}

	/** 
	 * Metodo que implementa as regras [064] e [063]: 
	 * <decl_id> :- <identificador> ; 
	 */
	private void declaracaoConstante() {

		Verto.getInstance().setUltimaAcaoSintatica( "declaracaoConstante()" );

		semantico.acaoSemantica( 64 ); /* regra com finalidade de acumular offset */
		identificador();
		semantico.acaoSemantica( 63 );
		semantico.acaoSemantica( 400 ); 
		if ( lexico.getToken() == Lexico.T_ATRIBUICAO ) {
			lexico.proximoToken();
            fatorSimples();
            reconheceRegra( "declaracaoConstante" );
			semantico.acaoSemantica( 73 );
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui: '=', mas encontrei: " +
					  lexico.getLexema() + " na linha: " +
					  lexico.getLinha() );
		}
	}

	/** 
	 * Metodo que implementa a regra [074]: 
	 * <parametro>	:- 	<tipo> <parametro_id>
	 */
	private void parametro() {

		Verto.getInstance().setUltimaAcaoSintatica( "parametro()" );

		tipo();
		parametroId();
		reconheceRegra( "parametro" );
	}

	/** 
	 * Metodo que implementa a regra [075]: 
	 * <parametro_id> :- <identificador> ; 
	 */
	private void parametroId() {

		Verto.getInstance().setUltimaAcaoSintatica( "parametroId()" );

		identificador();
		reconheceRegra( "parametroId" );
		semantico.acaoSemantica( 75 );
	}

	/** 
	 * Metodo que implementa as regras [080] e [081]: 
	 * <comandos> :- <comando> ; <comandos>
	 * 			  |  <comando> ;
	 */
	private void comandos() {

		Verto.getInstance().setUltimaAcaoSintatica( "comandos()" );

		comando();
		reconheceRegra( "comando" );
		while ( lexico.getToken() != Lexico.T_FECHA_CHAVE ) {
			comando();
			reconheceRegra( "comando" );
			reconheceRegra( "comandos" );
		}
		reconheceRegra( "Aqui ele parou de encontrar comandos" );
		reconheceRegra( "DsToken: " + lexico.getDsToken() );
		reconheceRegra( "Lexema: " + lexico.getLexema() );
		reconheceRegra( "ULexema: " + lexico.getUltimoLexema() );
	}

	/** 
	 * Metodo que implementa as regras [085] a [099]: 
	 * <comando> :- <cmd_leitura>
	 *           |  <cmd_escrita>
	 *           |  <cmd_atribuicao>
	 *           |  <cmd_se>
	 *           |  <cmd_enquanto>
	 *           |  <cmd_para_inteiro>
	 *           |  <cmd_para>
	 *			 |	<cmd_limpavisor>	
	 *			 |	<cmd_retorno>
	 *			 |	<cmd_repita>	
	 *			 |	<cmd_para_caracter>
	 *			 |	<cmd_casos>
	 *			 |	<bloco>
	 */
	private void comando() {

		Verto.getInstance().setUltimaAcaoSintatica( "comando()" );

		boolean isBloco;
		
		reconheceRegra( "Vou analizar comando: " + lexico.getLexema() );
		
		isBloco = false;
		
		switch ( lexico.getToken() ) {
		    case Lexico.T_LEIA		 	: comandoLeitura(); semantico.acaoSemantica( 85 ); break; 			
		    case Lexico.T_ESCREVA	 	: comandoEscrita(); semantico.acaoSemantica( 86 ); break; 			
			case Lexico.T_ID		 	: comandoAtribuicao(); semantico.acaoSemantica( 87 ); break;
			case Lexico.T_SE		 	: comandoSe(); semantico.acaoSemantica( 88 ); break;
			case Lexico.T_ENQUANTO	 	: comandoEnquanto(); semantico.acaoSemantica( 89 ); break;
			case Lexico.T_APAGATELA  	: comandoApagaTela(); semantico.acaoSemantica( 90 ); break;
			case Lexico.T_RETORNE    	: comandoRetornoDeFuncao(); semantico.acaoSemantica( 91 ); break;
			case Lexico.T_PARAINTEIRO	: comandoParaInteiro(); semantico.acaoSemantica( 92 ); break;
			case Lexico.T_PARA       	: comandoPara(); semantico.acaoSemantica( 93 ); break;
			case Lexico.T_REPITA     	: comandoRepita(); semantico.acaoSemantica( 94 ); isBloco = true; break;
			case Lexico.T_PARACARACTER	: comandoParaCaracter(); semantico.acaoSemantica( 95 ); break;
			case Lexico.T_CASOS			: comandoCasos(); semantico.acaoSemantica( 96 ); break;
			case Lexico.T_ROTULO		: comandoRotulo(); semantico.acaoSemantica( 97 ); break;
			case Lexico.T_VA			: comandoVaPara(); semantico.acaoSemantica( 98 ); break;
			case Lexico.T_ABRE_CHAVE 	: blocoVazio = true; bloco(); semantico.acaoSemantica( 99 ); isBloco = true; break;
			case Lexico.T_FECHA_CHAVE 	: 
				if ( blocoVazio ) { 
					isBloco = true;
					break; 
				} else {
					throw new ErroSintaticoException( "Fechamento de chaves em local impr�prio : " +
							  lexico.getLexema() + " na linha: " +
							  lexico.getLinha() );
				}
			default: 
				throw new ErroSintaticoException( "Comando desconhecido : " +
						  lexico.getLexema() + " na linha: " +
						  lexico.getLinha() );
		}
		if ( !isBloco && lexico.getUltimoToken() != Lexico.T_FECHA_CHAVE ) {
			if ( lexico.getToken() == Lexico.T_PONTO_VIRGULA ) {
				lexico.proximoToken();
				blocoVazio = false;	
			} else {
				throw new ErroSintaticoException( "Comando n�o foi encerrado com ';' : " +
						  lexico.getLexema() + " na linha: " +
						  lexico.getLinha() );
			}
		}
	}

	/** 
	 * Metodo que implementa a regra [100]: 
	 * <cmd_leitura> :- leia ( (<inteiro>|<caracter>), <referencia_id> )
	 */
	private void comandoLeitura() {

		Verto.getInstance().setUltimaAcaoSintatica( "comandoLeitura()" );

		if ( lexico.getToken() == Lexico.T_LEIA ) {
			lexico.proximoToken();
			if ( lexico.getToken() == Lexico.T_ABRE_PAR ) {
				lexico.proximoToken();
				if( lexico.getToken() == Lexico.T_NUMERO_INTEIRO ) {
					lexico.proximoToken();
					semantico.acaoSemantica( 100 ); 
					if( lexico.getToken() == Lexico.T_VIRGULA ) {
						lexico.proximoToken();
						referenciaId();
						semantico.acaoSemantica( 101 ); 
						if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
							lexico.proximoToken();
							reconheceRegra( "comandoLeitura" ); 
						} else {
							throw new ErroSintaticoException( "Esperava um ')', mas encontrei: " +
															  lexico.getLexema() + " na linha: " +
															  lexico.getLinha() );
						}	
					} else {
						throw new ErroSintaticoException( "Esperava uma virgula, mas encontrei: " +
								  lexico.getLexema() + " na linha: " +
								  lexico.getLinha() );
					}
				} else {
					if( lexico.getToken() == Lexico.T_TEXTO ) {
						fator();
						semantico.acaoSemantica( 105 ); 
						semantico.acaoSemantica( 106 ); 
						if( lexico.getToken() == Lexico.T_VIRGULA ) {
							lexico.proximoToken();
							referenciaId();
							semantico.acaoSemantica( 101 ); 
							if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
								lexico.proximoToken();
								reconheceRegra( "comandoLeitura" ); 
							} else {
								throw new ErroSintaticoException( "Esperava um ')', mas encontrei: " +
																  lexico.getLexema() + " na linha: " +
																  lexico.getLinha() );
							}	
						} else {
							throw new ErroSintaticoException( "Esperava uma virgula, mas encontrei: " +
									  lexico.getLexema() + " na linha: " +
									  lexico.getLinha() );
						}
					} else {
						throw new ErroSintaticoException( "Esperava um numero inteiro, mas encontrei: " +
								  lexico.getLexema() + " na linha: " +
								  lexico.getLinha() );
					}
				}
			} else {
				throw new ErroSintaticoException( "Esperava um '(', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui a palavra 'leia', mas encontrei: " +
					  lexico.getLexema() + " na linha: " +
					  lexico.getLinha() );
		}
	}

	/** 
	 * Metodo que implementa a regra [102]: 
	 * <cmd_escrita> :-	escreva ( <inteiro>, <expressao> )
	 */
	
	private void comandoEscrita() {

		Verto.getInstance().setUltimaAcaoSintatica( "comandoEscrita()" );

		if ( lexico.getToken() == Lexico.T_ESCREVA ) {
			lexico.proximoToken();
			if ( lexico.getToken() == Lexico.T_ABRE_PAR ) {
				lexico.proximoToken();
				if( lexico.getToken() == Lexico.T_NUMERO_INTEIRO || lexico.getToken() == Lexico.T_ID ) {
					if ( lexico.getToken() == Lexico.T_NUMERO_INTEIRO ) {
						lexico.proximoToken();
						semantico.acaoSemantica( 102 ); 
					} else {
						referenciaId();
						semantico.acaoSemantica( 103 ); 
					}
					if( lexico.getToken() == Lexico.T_VIRGULA ) {
						lexico.proximoToken();
						expressaoSimples();
						semantico.acaoSemantica( 104 ); 
						if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
							lexico.proximoToken();
							reconheceRegra( "comandoEscrita" ); 
						} else {
							throw new ErroSintaticoException( "Esperava um ')', mas encontrei: " +
															  lexico.getLexema() + " na linha: " +
															  lexico.getLinha() );
						}	
					} else {
						semantico.acaoSemantica( 105 ); 
						if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
							lexico.proximoToken();
							reconheceRegra( "comandoEscrita" ); 
						} else {
							throw new ErroSintaticoException( "Esperava um ')', mas encontrei: " +
															  lexico.getLexema() + " na linha: " +
															  lexico.getLinha() );
						}	
					}
				} else {
					fator();
					semantico.acaoSemantica( 103 ); 
					semantico.acaoSemantica( 105 ); 
					if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
						lexico.proximoToken();
						reconheceRegra( "comandoEscrita" ); 
					} else {
						throw new ErroSintaticoException( "Esperava um ')', mas encontrei: " +
														  lexico.getLexema() + " na linha: " +
														  lexico.getLinha() );
					}	
				}
			} else {
				throw new ErroSintaticoException( "Esperava um '(', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui a palavra 'escreva', mas encontrei: " +
					  lexico.getLexema() + " na linha: " +
					  lexico.getLinha() );
		}
	}
	
	/** 
	 * Metodo que implementa a regra [107]: 
	 * <cmd_para_caracter> :- paraCaracter ( <inteiro> )	
	 */
	private void comandoParaCaracter() {

		Verto.getInstance().setUltimaAcaoSintatica( "comandoParaCaracter()" );

		lexico.proximoToken();
		if ( lexico.getToken() == Lexico.T_ABRE_PAR ) {
			lexico.proximoToken();
			expressao();
			if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
				lexico.proximoToken();
				semantico.acaoSemantica( 107 ); 
				reconheceRegra( "funcaoEmbutidaParaCaracter" ); 
			} else {
				throw new ErroSintaticoException( "Esperava um ')', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Esperava um '(', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}
	
	/** 
	 * Metodo que implementa a regra [110]: 
	 * <cmd_para_inteiro> :- paraInteiro ( <caracter> )
	 */
	private void comandoParaInteiro() {

		Verto.getInstance().setUltimaAcaoSintatica( "comandoParaInteiro()" );

		lexico.proximoToken();
		if ( lexico.getToken() == Lexico.T_ABRE_PAR ) {
			lexico.proximoToken();
			expressao();
			if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
				lexico.proximoToken();
				semantico.acaoSemantica( 110 ); 
				reconheceRegra( "funcaoEmbutidaParaInteiro" ); 
			} else {
				throw new ErroSintaticoException( "Esperava um ')', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Esperava um '(', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}
	
	/** 
	 * Metodo que implementa a regra [111]: 
	 * <cmd_atribuicao>	:- <referencia_id> = <expressao>
	 */
	private void comandoAtribuicao() {

		int acaoSemantica = 0;
		
		Verto.getInstance().setUltimaAcaoSintatica( "comandoAtribuicao()" );

		acaoSemantica = referenciaIdAtribuicao();

		if ( lexico.getToken() == Lexico.T_ATRIBUICAO ) {
			lexico.proximoToken();
			expressao();
			reconheceRegra( "comandoAtribuicao" );
			semantico.acaoSemantica( acaoSemantica );
		} else {
				throw new ErroSintaticoException( "Esperava um '=', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
		}
	}

	/** 
	 * Metodo que implementa a regra [115]: 
	 * para ( <pre_para>, <cond_para>, <fim_para> ) <comando>
	 */
	private void comandoPara() {
		
		Verto.getInstance().setUltimaAcaoSintatica( "comandoPara()" );

		lexico.proximoToken();
	    referenciaId();
		if ( lexico.getToken() == Lexico.T_ATRIBUICAO ) {
			lexico.proximoToken();
			expressaoSimples();
			semantico.acaoSemantica( 130 );
			if ( lexico.getToken() == Lexico.T_ATE ) {
				lexico.proximoToken();
				semantico.acaoSemantica( 131 );
				expressaoSimples();
				semantico.acaoSemantica( 223 ); // Para gerar a condicao <=
				semantico.acaoSemantica( 132 );
				comando();
				semantico.acaoSemantica( 133 ); // Para gerar a atribui��o de incremento da vari�vel de controle
				semantico.acaoSemantica( 134 );
			} else {
				throw new ErroSintaticoException( "Esperava encontrar a palavra reservada: 'ATE', mas encontrei: " +
						  lexico.getLexema() + " na linha: " +
						  lexico.getLinha() );
			}
			reconheceRegra( "comandoPara" ); 
		} else {
				throw new ErroSintaticoException( "Esperava um '=', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
		}
	}
	
	/** 
	 * Metodo que implementa a regra [120]: 
	 * <cmd_se>	:- <condicao_se> <bloco_entao> [ <bloco_senao> ]
	 */
	private void comandoSe() {

		Verto.getInstance().setUltimaAcaoSintatica( "comandoSe()" );

		condicaoSe();
		blocoEntao();
		if ( lexico.getToken() == Lexico.T_SENAO ) {
			semantico.acaoSemantica( 119 ); // cria um jmp para o final do se
			blocoSenao();
		}
		reconheceRegra( "comandoSe" ); 
		semantico.acaoSemantica( 120 );
	}
	
	/** 
	 * Metodo que implementa a regra [121]: 
	 * <condicao_se> :-	se ( <expressao> )
	 */
	private void condicaoSe() {

		Verto.getInstance().setUltimaAcaoSintatica( "condicaoSe()" );
		
		if ( lexico.getToken() == Lexico.T_SE ) {
			lexico.proximoToken();
			if ( lexico.getToken() == Lexico.T_ABRE_PAR ) {
				lexico.proximoToken();
				expressao();
				if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
					lexico.proximoToken();
					reconheceRegra( "condicaoSe" ); 
					semantico.acaoSemantica( 121 ); 
				} else {
					throw new ErroSintaticoException( "Esperava um ')', mas encontrei: " +
													  lexico.getLexema() + " na linha: " +
													  lexico.getLinha() );
				}
			} else {
				throw new ErroSintaticoException( "Esperava um '(', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}
		} else {
				throw new ErroSintaticoException( "Esperava encontrar a palavra reservada: 'SE', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
		}
	}

	/** 
	 * Metodo que implementa a regra [122]: 
	 * <bloco_entao> :- entao <comando> 
	 */
	private void blocoEntao() {

		Verto.getInstance().setUltimaAcaoSintatica( "blocoEntao()" );

		if ( lexico.getToken() == Lexico.T_ENTAO ) {
			lexico.proximoToken();
			comando();
			reconheceRegra( "blocoEntao" ); 
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar a palavra reservada: 'entao', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}
	
	/** 
	 * Metodo que implementa a regra [123]: 
	 * <bloco_entao> :- entao <comando> 
	 */
	private void blocoSenao() {

		Verto.getInstance().setUltimaAcaoSintatica( "blocoSenao()" );

		if ( lexico.getToken() == Lexico.T_SENAO ) {
			lexico.proximoToken();
			comando();
			reconheceRegra( "blocoSenao" ); 
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar a palavra reservada: 'SENAO', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}

	/** 
	 * Metodo que implementa a regra [125]: 
	 * <cmd_enquanto> :- <condicao_enquanto> <comando>
	 */
	private void comandoEnquanto() {

		Verto.getInstance().setUltimaAcaoSintatica( "comandoEnquanto()" );

		semantico.acaoSemantica( 123 ); // Estabele�o label para retorno.
		condicaoEnquanto();
		semantico.acaoSemantica( 124 ); // Estabeleco a��o devida a condi��o
		comando();
		semantico.acaoSemantica( 125 ); // Encerro estrutura enquanto
		reconheceRegra( "comandoEnquanto" ); 
	}
	
	/** 
	 * Metodo que implementa a regra [126]: 
	 * <condicao_enquanto> :- enquanto ( <expressao> )
	 */
	private void condicaoEnquanto() {

		Verto.getInstance().setUltimaAcaoSintatica( "condicaoEnquanto()" );

		if ( lexico.getToken() == Lexico.T_ENQUANTO ) {
			lexico.proximoToken();
			if ( lexico.getToken() == Lexico.T_ABRE_PAR ) {
				lexico.proximoToken();
				expressao();
				if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
					lexico.proximoToken();
					reconheceRegra( "condicaoEnquanto" ); 
					semantico.acaoSemantica( 126 ); 
				} else {
					throw new ErroSintaticoException( "Esperava um ')', mas encontrei: " +
													  lexico.getLexema() + " na linha: " +
													  lexico.getLinha() );
				}
			} else {
				throw new ErroSintaticoException( "Esperava um '(', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}
		} else {
				throw new ErroSintaticoException( "Esperava encontrar a palavra reservada: 'ENQUANTO', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
		}
	}

	/** 
	 * Metodo que implementa a regra [127]: 
	 * <cmd_repita>	:- repita <comando> ate <condicao_repita>
	 */
	private void comandoRepita() {
		
		Verto.getInstance().setUltimaAcaoSintatica( "comandoRepita()" );

		if ( lexico.getToken() == Lexico.T_REPITA ) {
			lexico.proximoToken();
			semantico.acaoSemantica( 135 ); // Estabele�o label para retorno.
			comando();
			if ( lexico.getToken() == Lexico.T_ATE ) {
				condicaoRepita();
				semantico.acaoSemantica( 136 ); // Testo condi��o do repita-ate.
			} else {
				if ( lexico.getToken() == Lexico.T_ENQUANTO ) {
					condicaoRepita();
					semantico.acaoSemantica( 137 ); // Testo condi��o do repita-enquanto.
				} else {
					throw new ErroSintaticoException( "Esperava encontrar ou palavra reservada: 'ATE' ou a palavra reservada 'ENQUANTO', mas encontrei: " +
							  lexico.getLexema() + " na linha: " +
							  lexico.getLinha() );
				}
			}

//				lexico.proximoToken();
//
//				semantico.acaoSemantica( 130 );
//				semantico.acaoSemantica( 131 );
//				expressaoSimples();
//				semantico.acaoSemantica( 223 ); // Para gerar a condicao <=
//				semantico.acaoSemantica( 132 );
//				comando();
//				semantico.acaoSemantica( 133 ); // Para gerar a atribui��o de incremento da vari�vel de controle
//				semantico.acaoSemantica( 134 );
//			} else {
//				throw new ErroSintaticoException( "Esperava encontrar a palavra reservada: 'ATE', mas encontrei: " +
//						  lexico.getLexema() + " na linha: " +
//						  lexico.getLinha() );
//			}
			reconheceRegra( "comandoRepita" ); 
		} else {
				throw new ErroSintaticoException( "Esperava encontrar a palavra reservada: 'REPITA', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
		}
	}

	/** 
	 * Metodo que implementa as regras [128] e [129]: 
	 * <condicao_repita> :-	ate ( <expressao> )
	 * 					 |	enquanto ( <expressao> )
	 */
	private void condicaoRepita() {

		Verto.getInstance().setUltimaAcaoSintatica( "condicaoRepita()" );

			lexico.proximoToken();
			if ( lexico.getToken() == Lexico.T_ABRE_PAR ) {
				lexico.proximoToken();
				expressao();
				if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
					lexico.proximoToken();
					reconheceRegra( "condicaoRepita" ); 
					semantico.acaoSemantica( 126 ); 
				} else {
					throw new ErroSintaticoException( "Esperava um ')', mas encontrei: " +
													  lexico.getLexema() + " na linha: " +
													  lexico.getLinha() );
				}
			} else {
				throw new ErroSintaticoException( "Esperava um '(', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}
	}

	
	/** 
	 * Metodo que implementa a regra [130]: 
	 * <cmd_casos>	:- 	casos { <casos> }
	 */
	private void comandoCasos() {

		Verto.getInstance().setUltimaAcaoSintatica( "comandoCasos()" );

		if ( lexico.getToken() == Lexico.T_CASOS ) {
			lexico.proximoToken();
			if ( lexico.getToken() == Lexico.T_ABRE_CHAVE ) {
				lexico.proximoToken();
				casos();
				if ( lexico.getToken() == Lexico.T_FECHA_CHAVE ) {
					lexico.proximoToken();
				} else {
					throw new ErroSintaticoException( "Esperava um '}', mas encontrei: " +
													  lexico.getLexema() + " na linha: " +
													  lexico.getLinha() );
				}	
			} else {
				throw new ErroSintaticoException( "Esperava um '{', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Esperava encontrar a palavra reservada: 'CASOS', mas encontrei: " +
					  lexico.getLexema() + " na linha: " +
					  lexico.getLinha() );
		}

		reconheceRegra( "comandoCasos" ); 
	}
	
	/** 
	 * Metodo que implementa as regras [131] e [132]: 
	 * <casos>	:-  <caso> <casos>												
	 *			|   <caso> 														
	 */
	private void casos() {

		Verto.getInstance().setUltimaAcaoSintatica( "casos()" );

		caso1();
		while ( lexico.getToken() == Lexico.T_CASO ) {
			caso2();
			reconheceRegra( "casos" );
		}
		if ( lexico.getToken() == Lexico.T_SENAO  ) {
			senaoCaso();
		}
		semantico.acaoSemantica( 142 );
	}

	/** 
	 * Metodo que implementa a regra [133]: 
	 * <caso> :-  caso <expressao> : <comando> 
	 */
	private void caso1() {

		Verto.getInstance().setUltimaAcaoSintatica( "caso1()" );

		if ( lexico.getToken() == Lexico.T_CASO ) {
			lexico.proximoToken();
			expressao();
			if ( lexico.getToken() == Lexico.T_DOIS_PONTOS ) {
				lexico.proximoToken();
				semantico.acaoSemantica( 140 );
				comando();
				semantico.acaoSemantica( 143 );
			} else {
				throw new ErroSintaticoException( "Eu esperava encontrar aqui: ':', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui a palavra reservada: 'CASO', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}

	/** 
	 * Metodo que implementa a regra [133]: 
	 * <caso> :-  caso <expressao> : <comando> 
	 */
	private void caso2() {

		Verto.getInstance().setUltimaAcaoSintatica( "caso2()" );

		if ( lexico.getToken() == Lexico.T_CASO ) {
			lexico.proximoToken();
			expressao();
			if ( lexico.getToken() == Lexico.T_DOIS_PONTOS ) {
				lexico.proximoToken();
				semantico.acaoSemantica( 141 );
				comando();
				semantico.acaoSemantica( 143 );
			} else {
				throw new ErroSintaticoException( "Eu esperava encontrar aqui: ':', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui a palavra reservada: 'CASO', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}

	/** 
	 * Metodo que implementa a regra [134]: 
	 * <senao_caso>	:- senao : <comando> 
	 */
	private void senaoCaso() {
		
		if ( lexico.getToken() == Lexico.T_SENAO ) {
			lexico.proximoToken();
			if ( lexico.getToken() == Lexico.T_DOIS_PONTOS ) {
				lexico.proximoToken();
				semantico.acaoSemantica( 144 );
				comando();
			} else {
				throw new ErroSintaticoException( "Eu esperava encontrar aqui: ':', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui a palavra reservada: 'CASO', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}				
	}
	
	/** 
	 * Metodo que implementa a regra [155]: 
	 * <cmd_rotulo>	:- 	<rotulo>  
	 */
	private void comandoRotulo() {
		if ( lexico.getToken() == Lexico.T_ROTULO ) {
			lexico.proximoToken();
			semantico.acaoSemantica( 155 ); 
			reconheceRegra( "comandoRotulo" ); 
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui um 'rotulo', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}
	
	/** 
	 * Metodo que implementa a regra [160]: 
	 * <cmd_va_para> :-	va para <rotulo>  
	 */
	private void comandoVaPara() {
		if ( lexico.getToken() == Lexico.T_VA ) {
			lexico.proximoToken();
			if ( lexico.getToken() == Lexico.T_PARA ) {
				lexico.proximoToken();
				if ( lexico.getToken() == Lexico.T_ROTULO ) {
					lexico.proximoToken();
					semantico.acaoSemantica( 160 ); 
					reconheceRegra( "comandoVaPara" ); 
				} else {
					throw new ErroSintaticoException( "Eu esperava encontrar aqui um 'r[otulo', mas encontrei: " +
													  lexico.getLexema() + " na linha: " +
													  lexico.getLinha() );
				}	
			} else {
				throw new ErroSintaticoException( "Eu esperava encontrar aqui um 'para', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui um 'va', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
		
	}
	
	
	
	
	
	
	
	// TODO TOAQUI
	
	
	
	
	
	
	
	/** 
	 * Metodo que implementa a regra [180]: 
	 * <cmd_apagatela> :- ApagaTela
	 */
	private void comandoApagaTela() {

		Verto.getInstance().setUltimaAcaoSintatica( "comandoApagaTela()" );

		lexico.proximoToken();
		reconheceRegra( "comandoLimpaVisor" ); 
		semantico.acaoSemantica( 180 );
	}
	
	/** 
	 * Metodo que implementa a regra [190]: 
	 * <cmd_retorno> :-	retorne <expressao>	
	 */
	private void comandoRetornoDeFuncao() {

		Verto.getInstance().setUltimaAcaoSintatica( "comandoRetornoDeFuncao()" );

		lexico.proximoToken();
		expressao();
		reconheceRegra( "comandoRetornoDeFuncao" ); 
		semantico.acaoSemantica( 190 );
	}
	
	/** 
	 * Metodo que implementa a regra [195]: 
	 * <bloco> :- { <comandos> }
	 */
	private void bloco() {

		Verto.getInstance().setUltimaAcaoSintatica( "bloco()" );

		if ( lexico.getToken() == Lexico.T_ABRE_CHAVE ) {
			lexico.proximoToken();
			comandos();
			if ( lexico.getToken() == Lexico.T_FECHA_CHAVE ) {
				lexico.proximoToken();
				reconheceRegra( "bloco" );
			} else {
				throw new ErroSintaticoException( "Eu esperava encontrar aqui um '}', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui um '{', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}

	/** 
	 * Metodo que implementa a regra [205]: 
	 * <expressao> :- <termo_logico> { ou <termo_logico> }	
	 */
	private void expressao() {

		Verto.getInstance().setUltimaAcaoSintatica( "expressao()" );

		reconheceRegra( "Entrei na Expressao: " + lexico.getLexema() );
		
		termoLogico();
		while ( lexico.getToken() == Lexico.T_OU ) {
			lexico.proximoToken();
			termoLogico();
			semantico.acaoSemantica( 205 );
		}
		reconheceRegra( "expressao" ); 
	}
	
	/** 
	 * Metodo que implementa a regra [210]: 
	 * <termo_logico> :- <fator_logico> { e <fator_logico> }	
	 */
	private void termoLogico() {

		Verto.getInstance().setUltimaAcaoSintatica( "termoLogico()" );

		reconheceRegra( "Entrei no Termo Logico: " + lexico.getLexema() );
		
		fatorLogico();
		while ( lexico.getToken() == Lexico.T_E ) {
			lexico.proximoToken();
			fatorLogico();
			semantico.acaoSemantica( 210 );
		}
		reconheceRegra( "termoLogico" ); 
	}
	
	/** 
	 * Metodo que implementa a regra [212]: 
	 * <fator_logico> :- <rel_igualdade> { (==|!=) <rel_igualdade> }	
	 */
	private void fatorLogico() {

		Verto.getInstance().setUltimaAcaoSintatica( "fatorLogico()" );

		reconheceRegra( "Entrei no Fator Logico: " + lexico.getLexema() );
		
		relacaoIgualdade();
		while ( ( lexico.getToken() == Lexico.T_IGUAL ) || ( lexico.getToken() == Lexico.T_DIFERENTE ) ) {
			if ( lexico.getToken() == Lexico.T_IGUAL ) {
				lexico.proximoToken();
				relacaoIgualdade();
				semantico.acaoSemantica( 212 );
			} else {
				lexico.proximoToken();
				relacaoIgualdade();
				semantico.acaoSemantica( 213 );
			}
		}
		reconheceRegra( "fatorLogico" ); 
	}
	
	/** 
	 * Metodo que implementa a regra [220]: 
	 * <rel_igualdade> :- <expr_simples> { (>|<|>=|<=) <expr_simples> }	
	 */
	private void relacaoIgualdade() {

		Verto.getInstance().setUltimaAcaoSintatica( "relacaoIgualdade()" );

		reconheceRegra( "Entrei na relacaoIgualdade: " + lexico.getLexema() );
		
		expressaoSimples();
		while ( lexico.isRelacaoTokenAtual() ) {
			switch ( lexico.getToken() ) {
			case Lexico.T_MAIOR: 		lexico.proximoToken();
										expressaoSimples();
										semantico.acaoSemantica( 220 );
										break;
			case Lexico.T_MENOR: 		lexico.proximoToken();
										expressaoSimples();
										semantico.acaoSemantica( 221 );
										break;
			case Lexico.T_MAIOR_IGUAL:	lexico.proximoToken();
										expressaoSimples();
										semantico.acaoSemantica( 222 );
										break;
			default:					lexico.proximoToken();
										expressaoSimples();
										semantico.acaoSemantica( 223 );
										break;
			}
		}
		reconheceRegra( "relacaoIgualdade" ); 
	}
	
	/** 
	 * Metodo que implementa a regra [225]: 
	 * <expr_simples> :- <termo> { (+|-) <termo> }	
	 */
	private void expressaoSimples() {

		Verto.getInstance().setUltimaAcaoSintatica( "expressaoSimples()" );

		reconheceRegra( "Entrei na Expressao Simples: " + lexico.getLexema() );
		
		termo();
		while ( ( lexico.getToken() == Lexico.T_MAIS ) || ( lexico.getToken() == Lexico.T_MENOS ) ) {
			if ( lexico.getToken() == Lexico.T_MAIS ) {
				lexico.proximoToken();
				termo();
				reconheceRegra( "+ termo" ); 
				semantico.acaoSemantica( 227 );
			} else {
				lexico.proximoToken();
				termo();
				reconheceRegra( "- termo" ); 
				semantico.acaoSemantica( 229 );
			}
		}
		reconheceRegra( "expressaoSimples" ); 
	}
	
	/** 
	 * Metodo que implementa a regra [230]: 
	 * <termo> :- <unario> { (*|/) <unario> }	
	 */
	private void termo() {

		Verto.getInstance().setUltimaAcaoSintatica( "termo()" );

		reconheceRegra( "Entrei no Termo: " + lexico.getLexema() );
		
		unario();
		while ( ( lexico.getToken() == Lexico.T_VEZES ) || ( lexico.getToken() == Lexico.T_SOBRE ) ) {

			reconheceRegra( "Estou no While de termo: " + lexico.getLexema() );
			
			if ( lexico.getToken() == Lexico.T_VEZES ) {
				lexico.proximoToken();
				unario();
				reconheceRegra( "* unario" ); 
				semantico.acaoSemantica( 232 );
			} else {
				lexico.proximoToken();
				unario();
				reconheceRegra( "/ unario" ); 
				semantico.acaoSemantica( 234 );
			}
		}
		reconheceRegra( "termo" ); 
	}
	
	/** 
	 * Metodo que implementa as regras [235] a [245]: 
	 * <unario>	:- - <fator>	
	 *          |  negue <fator>	
	 *          |  <fator>	
	 */
	private void unario() {

		Verto.getInstance().setUltimaAcaoSintatica( "unario()" );

		reconheceRegra( "Entrei no Unario: " + lexico.getLexema() );

		switch( lexico.getToken() ) {
		case Lexico.T_MENOS: lexico.proximoToken(); fator(); semantico.acaoSemantica( 240 ); break;
		case Lexico.T_NEGUE: lexico.proximoToken(); fator(); semantico.acaoSemantica( 245 ); break;
		default: fator();	
		}
		reconheceRegra( "unario" ); 
	}
	
	/** 
	 * Metodo que implementa as regras [250] a [280]: 
	 * <fator> :- <selecionaReferenciaId>
	 * 		   |  <inteiro>
	 * 		   |  <caracter>
	 *		   |  <logico>
	 *		   |  ( <expressao> )
	 *		   |  <chamada_funcao>
	 */
	private void fator() {
	
		Verto.getInstance().setUltimaAcaoSintatica( "fator()" );

		reconheceRegra( "Entrei no Fator: " + lexico.getLexema() );
		
		switch ( lexico.getToken() ) {
			case Lexico.T_ID:       		selecionaReferenciaId();
											if ( semantico.isIdNomeFuncao( lexico.getLexema() ) ) {
												chamadaFuncao();
												reconheceRegra( "fator(chamadaFuncao)" );
											} else {
												semantico.acaoSemantica( 250 ); 
												reconheceRegra( "fator(referenciaId)" );
											}
											break;
			case Lexico.T_PARAINTEIRO:		this.comandoParaInteiro();
											break;	
			case Lexico.T_PARACARACTER:		this.comandoParaCaracter();
											break;	
			case Lexico.T_NUMERO_INTEIRO:	lexico.proximoToken();
 											semantico.acaoSemantica( 255 ); 
 								    		reconheceRegra( "fator(inteiro)" ); 
 								    		break;
			case Lexico.T_TEXTO:    		lexico.proximoToken();
								    		semantico.acaoSemantica( 265 ); 
								    		reconheceRegra( "fator(texto)" ); 
								    		break;
			case Lexico.T_FALSO:    	
			case Lexico.T_VERDADEIRO:    	lexico.proximoToken();
    										semantico.acaoSemantica( 270 ); 
    										reconheceRegra( "fator(logico)" ); 
    										break;
			case Lexico.T_ABRE_PAR:			lexico.proximoToken();
											expressao();
											if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
												lexico.proximoToken();
												semantico.acaoSemantica( 275 ); 
												reconheceRegra( "fator(expressao)" ); 
											} else {	
												throw new ErroSintaticoException( "Eu esperava encontrar aqui um fecha parentesis, mas encontrei: " +
														lexico.getLexema() + " na linha: " +
														lexico.getLinha() );
											}
											break;
			default: throw new ErroSintaticoException( "Eu esperava encontrar aqui um fator, mas encontrei: " +
							   lexico.getLexema() + "token : " + lexico.getToken() + " na linha: " +
							   lexico.getLinha() );
		}
	} 

	/** 
	 * Metodo que implementa as regras [281] a [284]: 
	 * <fator> :- <selecionaReferenciaId>
	 * 		   |  <inteiro>
	 * 		   |  <caracter>
	 *		   |  <logico>
	 *		   |  ( <expressao> )
	 *		   |  <chamada_funcao>
	 */
	private void fatorSimples() {
	
		Verto.getInstance().setUltimaAcaoSintatica( "fatorSimples()" );

		reconheceRegra( "Entrei no Fator Simples: " + lexico.getLexema() );
		
		switch ( lexico.getToken() ) {
			case Lexico.T_NUMERO_INTEIRO:	lexico.proximoToken();
 											semantico.acaoSemantica( 255 ); 
 								    		reconheceRegra( "fator(inteiro)" ); 
 								    		break;
			case Lexico.T_TEXTO:    		lexico.proximoToken();
								    		semantico.acaoSemantica( 265 ); 
								    		reconheceRegra( "fator(texto)" ); 
								    		break;
			case Lexico.T_FALSO:    	
			case Lexico.T_VERDADEIRO:    	lexico.proximoToken();
    										semantico.acaoSemantica( 270 ); 
    										reconheceRegra( "fator(logico)" ); 
    										break;
			default: throw new ErroSintaticoException( "Eu esperava encontrar aqui um fator simples, mas encontrei: " +
							   lexico.getLexema() + "token : " + lexico.getToken() + " na linha: " +
							   lexico.getLinha() );
		}
	} 


	/** 
	 * Metodo que implementa a regra [297]: 
	 * <numero> :- <inteiro>
	 */
	private void numero() {
	
		Verto.getInstance().setUltimaAcaoSintatica( "fatorSimples()" );

		reconheceRegra( "Entrei na regra numero: " + lexico.getLexema() );
		if ( lexico.getToken() == Lexico.T_NUMERO_INTEIRO ) {
			lexico.proximoToken();
 			semantico.acaoSemantica( 255 ); 
 			reconheceRegra( "numero" ); 
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui um numero inteiro, mas encontrei: " +
							   lexico.getLexema() + "token : " + lexico.getToken() + " na linha: " +
							   lexico.getLinha() );
		}
	}
	/** 
	 * Metodo que implementa a regra [300]: 
	 * <chamada_funcao>	:- <referencia_id> ( <argumentos> )
	 */
	private void chamadaFuncao() {

		Verto.getInstance().setUltimaAcaoSintatica( "chamadaFuncao()" );

		if ( lexico.getToken() == Lexico.T_ABRE_PAR ) {
			lexico.proximoToken();
			semantico.acaoSemantica( 300 );
			argumentos();
			if ( lexico.getToken() == Lexico.T_FECHA_PAR ) {
				lexico.proximoToken();
				reconheceRegra( "chamadaFuncao" ); 
				semantico.acaoSemantica( 301 );
			} else {
				throw new ErroSintaticoException( "Eu esperava encontrar aqui um ')', mas encontrei: " +
												  lexico.getLexema() + " na linha: " +
												  lexico.getLinha() );
			}	
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui um '(', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}
	
	/** 
	 * Metodo que implementa as regras [305] a [310]: 
	 * <argumentos>	:- <argumento> , <argumentos>
	 * 				|  <argumento>
	 */
	private void argumentos() {

		Verto.getInstance().setUltimaAcaoSintatica( "argumentos()" );

		argumento();
		while ( lexico.getToken() == Lexico.T_VIRGULA ) {
			lexico.proximoToken();
			argumento();
			reconheceRegra( "argumentos" ); 
		}
	}
	
	/** 
	 * Metodo que implementa a regra [315]: 
	 * <argumento> :- <expressao>
	 */
	private void argumento() {

		Verto.getInstance().setUltimaAcaoSintatica( "argumento()" );

		expressao();
		reconheceRegra( "expressao" ); 
	}

	/** 
	 * Metodo que implementa a regra [380]: 
	 * <referencia_id> :- <identificador> 
	 */
	private int referenciaIdAtribuicao() {

		//Eskeff
		Verto.getInstance().setUltimaAcaoSintatica( "referenciaIdAtribuicao()" );

		identificador();
		if (  lexico.getToken() == Lexico.T_ABRE_COLCHETES  ) {
			lexico.proximoToken();
			expressao();
			if (  lexico.getToken() == Lexico.T_FECHA_COLCHETES  ) {
				lexico.proximoToken();
				semantico.acaoSemantica( 382 ); 
			}
			reconheceRegra( "referenciaIdAtribuicao (vetor)" ); 
			return 112;
		} else {
			semantico.acaoSemantica( 380 ); 
			reconheceRegra( "referenciaIdAtribuicao" );
			return 111;
		}
	}
	
	/** 
	 * Metodo que implementa a regra [400]: 
	 * <referencia_id> :- <identificador> 
	 */
	private void referenciaId() {

		Verto.getInstance().setUltimaAcaoSintatica( "referenciaId()" );

		identificador();
		if (  lexico.getToken() == Lexico.T_ABRE_COLCHETES  ) {
			lexico.proximoToken();
			expressao();
			if (  lexico.getToken() == Lexico.T_FECHA_COLCHETES  ) {
				lexico.proximoToken();
				semantico.acaoSemantica( 404 ); 
			}
			reconheceRegra( "referenciaIdAtribuicao (vetor)" ); 
		} else {
			semantico.acaoSemantica( 400 ); 
			reconheceRegra( "referenciaId" ); 
		}
	}
	
	/** 
	 * Metodo que implementa a regra [406]: 
	 * <selecionaReferencia_id> :- <identificador> 
	 */
	private void selecionaReferenciaId() {

		Verto.getInstance().setUltimaAcaoSintatica( "selecionaReferenciaId()" );

		identificador();
		if ( lexico.getToken() == Lexico.T_ABRE_PAR ) {
			semantico.acaoSemantica( 406 ); 
		} else {
			if (  lexico.getToken() == Lexico.T_ABRE_COLCHETES  ) {
				lexico.proximoToken();
				expressao();
				if (  lexico.getToken() == Lexico.T_FECHA_COLCHETES  ) {
					lexico.proximoToken();
					semantico.acaoSemantica( 404 ); 
				}
				reconheceRegra( "referenciaIdAtribuicao (vetor)" ); 
			} else {
				semantico.acaoSemantica( 400 ); 
			}
		}
		reconheceRegra( "selecionaReferenciaId" ); 
	}
	
	/** 
	 * Metodo que implementa as regras [410] a [414]: 
	 * <tipo> :- inteiro
	 *        |  caracter 
	 *        |  logico 
	 */
	private void tipo() {

		Verto.getInstance().setUltimaAcaoSintatica( "tipo()" );

		switch( lexico.getToken() ) {
		
	//	case Lexico.T_CONSTANTE: lexico.proximoToken(); semantico.acaoSemantica( 410 ); reconheceRegra( "tipo constante #" ); break;
		case Lexico.T_INTEIRO: lexico.proximoToken(); semantico.acaoSemantica( 410 ); reconheceRegra( "tipo inteiro #" ); break;
		case Lexico.T_CARACTER: lexico.proximoToken(); semantico.acaoSemantica( 413 ); reconheceRegra( "tipo caracter #" ); break;
		case Lexico.T_LOGICO: lexico.proximoToken(); semantico.acaoSemantica( 414 ); reconheceRegra( "tipo logico #" ); break;
		default: throw new ErroSintaticoException( "Eu esperava encontrar aqui um tipo (inteiro, caracter ou logico), mas encontrei: " +
						   lexico.getLexema() + " na linha: " +
						   lexico.getLinha() );
		}
	}

	/** 
	 * Metodo que implementa a regra [416]: 
	 * <stipo> :- vazio
	 *         |  <tipo>
	 */
	private void superTipo() {

		Verto.getInstance().setUltimaAcaoSintatica( "superTipo()" );

		if ( lexico.getToken() == Lexico.T_VAZIO ) {
			lexico.proximoToken(); 
			semantico.acaoSemantica( 416 ); 
			reconheceRegra( "superTipo" ); 
		} else {
			tipo();
		}
	}

	/** 
	 * Metodo que implementa a regra [465]: 
	 * <identificador> :- (a..z|A..Z)(a..z|A..Z|0..9|_)* 
	 */
	private void identificador() {

		Verto.getInstance().setUltimaAcaoSintatica( "identificador()" );

		reconheceRegra( "Entrei no identificador: " + lexico.getLexema() );
		if ( lexico.getToken() == Lexico.T_ID ) {
			lexico.proximoToken();
			semantico.acaoSemantica( 465 ); 
			reconheceRegra( "identificador" ); 
		} else {
			throw new ErroSintaticoException( "Eu esperava encontrar aqui um 'identificador', mas encontrei: " +
											  lexico.getLexema() + " na linha: " +
											  lexico.getLinha() );
		}	
	}

	public String getFonte() {
		return semantico.getFonte();
	}
	
	public void setNomeFonte( String n ) {
		semantico.setNomeFonte( n );
	}
	
	public String getNomeFonte() {
		return semantico.getNomeFonte();
	}
	
	public void saltaLinhasEmBranco() {
		while ( lexico.getToken() == Lexico.T_FIM_COMANDO ) {
			lexico.proximoToken();
		}
	}
	public String getSaidaSintatico(){
		return saidaSintatico.toString();
	}

	private void reconheceRegra( String mensagem ) {
		exibeMensagemSintatico( "Reconhecida Regra: <" + mensagem + ">" );
	}
	
	private void exibeMensagemSintatico( String mensagem ) {
		
		saidaSintatico.append( mensagem );
		saidaSintatico.append( "\n" );
		Verto.getInstance().setMensagemSintatico( saidaSintatico.toString() );
	}

	public Lexico getLexico() {
		return lexico;
	}
	
}
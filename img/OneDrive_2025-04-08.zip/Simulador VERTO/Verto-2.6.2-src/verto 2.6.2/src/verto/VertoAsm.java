package verto;
/*
 * $Id: VertoAsm.java,v 1.3 2008/04/09 18:50:55 ricardo Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2010 Lucas Eskeff Freitas
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import verto.exception.ErroGeracaoCodigoException;

/**
 * 
 * TODO VertoAsm.java - Descricao da classe
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * 
 * @version 2.6.2
 * 
 */
public class VertoAsm {
	
	/* NOP */
	private static final byte NOP = (byte) 0x00;

	/* Instru��es sobre os c�digos de condi��o */
	private static final byte CCC = (byte) 0x10;
	private static final byte SCC = (byte) 0x20;
	
	/* Instru��es de desvio condicional */
	private static final byte BR  = (byte) 0x30;
	private static final byte BNE = (byte) 0x31;
	private static final byte BEQ = (byte) 0x32;
	private static final byte BPL = (byte) 0x33;
	private static final byte BMI = (byte) 0x34;
	private static final byte BVC = (byte) 0x35;
	private static final byte BVS = (byte) 0x36;
	private static final byte BCC = (byte) 0x37;
	private static final byte BCS = (byte) 0x38;
	private static final byte BGE = (byte) 0x39;
	private static final byte BLT = (byte) 0x3A;
	private static final byte BGT = (byte) 0x3B;
	private static final byte BLE = (byte) 0x3C;
	private static final byte BHI = (byte) 0x3D;
	private static final byte BLS = (byte) 0x3E;
	
	/* Instru��o de desvio incondicional */
	private static final byte JMP = (byte) 0x40;

	/* Instru��o de controle de la�o */
	private static final byte SOB = (byte) 0x50;

	/* Instru��o de desvio para subrotina */
	private static final byte JSR = (byte) 0x60;

	/* Instru��o de retorno de subrotina */
	private static final byte RTS = (byte) 0x70;

	/* Instru��es com um operando */
	private static final byte CLR = (byte) 0x80;
	private static final byte NOT = (byte) 0x81;
	private static final byte INC = (byte) 0x82;
	private static final byte DEC = (byte) 0x83;
	private static final byte NEG = (byte) 0x84;
	private static final byte TST = (byte) 0x85;
	private static final byte ROR = (byte) 0x86;
	private static final byte ROL = (byte) 0x87;
	private static final byte ASR = (byte) 0x88;
	private static final byte ASL = (byte) 0x89;
	private static final byte ADC = (byte) 0x8A;
	private static final byte SBC = (byte) 0x8B;
	
	/* Instru��es com dois operandos */
	private static final byte MOV = (byte) 0x90;
	private static final byte ADD = (byte) 0xA0;
	private static final byte SUB = (byte) 0xB0;
	private static final byte CMP = (byte) 0xC0;
	private static final byte AND = (byte) 0xD0;
	private static final byte OR  = (byte) 0xE0;

	/* Instru��o de parada */
	private static final byte HLT = (byte) 0xF0;
	
	int nrLinha;
	int ptrInstrucao = 0;
	private byte[] codigoMem = null;
	private StringBuffer codigoAsm = null;
	private Hashtable tblLabels = null;
	private Vector desviosPendentes = null;
	private Vector jumpsPendentes = null;
	private Vector enderecosPendentes = null;
	private Vector modulosCarregados = null;
	private Hashtable tblRotinasBiblioteca = null;
	
	public static void main( String[] args ) throws ErroGeracaoCodigoException {
		
		if( args.length > 0 && args.length < 3 ) {

			for( int i = 0; i < args.length; i++ ) {
				System.out.println( args[ i ] );
			}
			
			if( args.length == 1 ) {
				new VertoAsm( args[ 0 ] );
			} else if( args.length == 2 ) {
				new VertoAsm( args[ 0 ], args[ 1 ] );
			}
			
			return;
		}
			
		System.out.println( "VertoASM: Montador Verto assembler" );
		System.out.println( "Utiliza��o: java VertoAsm <nomeFonteAssembler> [<nomeArquivoSaida>]\n" );
		System.out.println( "Aprecie com modera��o." );
	}
	
	public VertoAsm( String nmArquivoAsm ) throws ErroGeracaoCodigoException {
		
		montaArquivo( nmArquivoAsm, nmArquivoAsm );
	}
	
	public VertoAsm( String nmArquivoAsm, String nmArquivoSaida ) throws ErroGeracaoCodigoException {
		
		montaArquivo( nmArquivoAsm, nmArquivoSaida );
	}
	
	public VertoAsm( StringBuffer fonteAsm ) throws ErroGeracaoCodigoException {
		
		monta( fonteAsm );
	}

	public VertoAsm( StringBuffer fonteAsm, String nmArquivoSaida ) throws ErroGeracaoCodigoException {
		
		monta( fonteAsm );
		gravaArquivoMem( nmArquivoSaida );
	}

	private void montaArquivo( String nmArquivoAsm, String nmArquivoSaida ) throws ErroGeracaoCodigoException {
		
		File f = new File( nmArquivoAsm );
		StringBuffer fonteAsm = null;
		
		if( !f.exists() ) {
			throw new ErroGeracaoCodigoException( "Arquivo fonte inexistente (" + nmArquivoAsm + ")." );
		}
		
		try {
			InputStreamReader isr = new InputStreamReader( new FileInputStream( f ), "LATIN1" );
			
			try {
				
				fonteAsm = new StringBuffer( (int) f.length() );
				int ch;
				
				while( ( ch = isr.read() ) != -1 ) {
					fonteAsm.append( (char) ch );
				}
			} finally {
				isr.close();
			}
			
		} catch( Exception e ) {
			e.printStackTrace();
			throw new ErroGeracaoCodigoException( "Erro ao carregar arquivo asm: " + e.getMessage() );
		}
		
		monta( fonteAsm ); 
		gravaArquivoMem( nmArquivoSaida );
	}

	public void gravaArquivoMem( String nmArquivoSaida ) throws ErroGeracaoCodigoException {

		int f = nmArquivoSaida.lastIndexOf( File.separatorChar );
		if( f < 0 ) f = nmArquivoSaida.lastIndexOf( '/' );
		if( f < 0 ) f = 0; else f++;
		exibeMensagem( "** Verto - " + nmArquivoSaida.substring( f ) + " ** " );

		f = nmArquivoSaida.lastIndexOf( '.' );
		if( f > 0 ) nmArquivoSaida = nmArquivoSaida.substring( 0, f );

		nmArquivoSaida = nmArquivoSaida + ".mem";
		
		try {
			File s = new File( nmArquivoSaida );
			if( s.exists() ) {
				s.delete();
			}
			
			s.createNewFile();
			FileOutputStream fos = new FileOutputStream( s );

			try {
				fos.write( codigoMem );
			} finally {
				fos.close();
				System.out.println( "Arquivo bin�rio gerado: " + nmArquivoSaida );
			}
		} catch (Exception e) {
			throw new ErroGeracaoCodigoException( "Erro gerando arquivo .mem: " + e.getMessage() );
		}
	}
	
	public byte[] getCodigoMem() {
		return codigoMem;
	}

	private void exibeMensagem( String mensagem ) {

		int pos = 65504;
		
		if( mensagem.length() < 36 ) {
			int dif = ( 36 - mensagem.length() ) / 2;
			
			while( dif-- > 0 ) {
				mensagem = " ".concat( mensagem );
			}
		}
		
		for( int i = 0; i < mensagem.length() && i < 36; i++ ) {
			codigoMem[ pos++ ] = (byte) mensagem.charAt( i );
		}
	}

	private void monta( StringBuffer fonteAsm ) throws ErroGeracaoCodigoException {
		
		codigoAsm = new StringBuffer( fonteAsm.toString() );
		codigoMem = new byte[ 65540 ];
		
		/* Inicializa��o do c�digo */
		codigoMem[ 0 ] = (byte) 3;
		codigoMem[ 1 ] = (byte) 67;
		codigoMem[ 2 ] = (byte) 49;
		codigoMem[ 3 ] = (byte) 54;
		
		/* Aponta para o primeiro byte dispon�vel para c�digo */
		ptrInstrucao = 4;
		
		int i = 0, f;
		nrLinha = 1;
		
		do {
			f = codigoAsm.indexOf( "\n", i );
			String linha = null;

			if( f > 0 ) {
				linha = codigoAsm.substring( i, f );
			} else {
				linha = codigoAsm.substring( i );
			}
			
			processaLinha( linha );

			i = f + 1; 
			nrLinha++;
		} while( f > 0 );

		resolveEnderecos();
		resolveDesvios();
		resolveJumps();
	}

	private void processaLinha( String linha ) throws ErroGeracaoCodigoException {
		
		linha = linha.trim();
		
		int f = linha.indexOf( ';' );
		if( f >= 0 ) {
			linha = linha.substring( 0, f ).trim();
		}

		String linhaOrg = linha;
		linha = linha.toUpperCase();

		if( linha.length() > 0 ) {

			int sp = posSeparador( linha );

			String comando = linha.substring( 0, sp );
			String resto   = linha.substring( sp ).trim();
			
			if( linha.charAt( 0 ) == '"' || linha.charAt( 0 ) == '\'' ) {

				resto = "";
				char marcador = linha.charAt( 0 );
				
				int pFnl = linha.indexOf( marcador, 1 );
				if( pFnl > 0 ) {
					
					for( int i = 1; i < pFnl; i++ ) {
						insereComando( (byte) linhaOrg.charAt( i ) );
					}
					insereComando( (byte) 0 );
				} else {
					geraErro( "String n�o terminada: " + linha );
				}
				
			} else if( comando.charAt( comando.length() - 1 ) == ':' ) {
				registraLabel( comando );
			} else {

				f = resto.indexOf( ',' );
				String p1 = null;
				String p2 = null;
				
				if( f > 0 ) {
					
					p1 = resto.substring( 0, f );
					resto = resto.substring( f + 1 ).trim();
					int s = posSeparador( resto );
					p2 = resto.substring( 0, s );
					resto = resto.substring( s );
				} else {
					int s = posSeparador( resto );
					p1 = resto.substring( 0, s ).trim();
					resto = resto.substring( s );
					if( p1.length() == 0 ) p1 = null;
				}
				
				montaComando( comando, p1, p2 );
			}
			
			if( resto.trim().length() > 0 ) {
				System.out.println( "AVISO: Linha " + nrLinha + ", conte�do ignorado:" + resto );
			}
		}
	}

	private void montaComando( String comando, String p1, String p2 ) throws ErroGeracaoCodigoException {

		if( comando.equals( "NOP" ) ) {
			insereComando( NOP );
		} else if( comando.equals( "HLT" ) ) {
			insereComando( HLT );
		} else if( comando.equals( "CCC" ) ) {
			insereComandoCodigoCondicao( CCC, p1 );
		} else if( comando.equals( "SCC" ) ) {
			insereComandoCodigoCondicao( SCC, p1 );
		} else if( comando.equals( "BR" ) ) {
			insereDesvioCondicional( BR, p1 );
		} else if( comando.equals( "BNE" ) ) {
			insereDesvioCondicional( BNE, p1 );
		} else if( comando.equals( "BEQ" ) ) {
			insereDesvioCondicional( BEQ, p1 );
		} else if( comando.equals( "BPL" ) ) {
			insereDesvioCondicional( BPL, p1 );
		} else if( comando.equals( "BMI" ) ) {
			insereDesvioCondicional( BMI, p1 );
		} else if( comando.equals( "BVC" ) ) {
			insereDesvioCondicional( BVC, p1 );
		} else if( comando.equals( "BVS" ) ) {
			insereDesvioCondicional( BVS, p1 );
		} else if( comando.equals( "BCC" ) ) {
			insereDesvioCondicional( BCC, p1 );
		} else if( comando.equals( "BCS" ) ) {
			insereDesvioCondicional( BCS, p1 );
		} else if( comando.equals( "BGE" ) ) {
			insereDesvioCondicional( BGE, p1 );
		} else if( comando.equals( "BLT" ) ) {
			insereDesvioCondicional( BLT, p1 );
		} else if( comando.equals( "BGT" ) ) {
			insereDesvioCondicional( BGT, p1 );
		} else if( comando.equals( "BLE" ) ) {
			insereDesvioCondicional( BLE, p1 );
		} else if( comando.equals( "BHI" ) ) {
			insereDesvioCondicional( BHI, p1 );
		} else if( comando.equals( "BLS" ) ) {
			insereDesvioCondicional( BLS, p1 );
		} else if( comando.equals( "JMP" ) ) {
			insereDesvioIncondicional( p1 );
		} else if( comando.equals( "CLR" ) ) {
			insereInstrucaoUmOperando( CLR, p1 );
		} else if( comando.equals( "NOT" ) ) {
			insereInstrucaoUmOperando( NOT, p1 );
		} else if( comando.equals( "INC" ) ) {
			insereInstrucaoUmOperando( INC, p1 );
		} else if( comando.equals( "DEC" ) ) {
			insereInstrucaoUmOperando( DEC, p1 );
		} else if( comando.equals( "NEG" ) ) {
			insereInstrucaoUmOperando( NEG, p1 );
		} else if( comando.equals( "TST" ) ) {
			insereInstrucaoUmOperando( TST, p1 );
		} else if( comando.equals( "ROR" ) ) {
			insereInstrucaoUmOperando( ROR, p1 );
		} else if( comando.equals( "ROL" ) ) {
			insereInstrucaoUmOperando( ROL, p1 );
		} else if( comando.equals( "ASR" ) ) {
			insereInstrucaoUmOperando( ASR, p1 );
		} else if( comando.equals( "ASL" ) ) {
			insereInstrucaoUmOperando( ASL, p1 );
		} else if( comando.equals( "ADC" ) ) {
			insereInstrucaoUmOperando( ADC, p1 );
		} else if( comando.equals( "SBC" ) ) {
			insereInstrucaoUmOperando( SBC, p1 );
		} else if( comando.equals( "MOV" ) ) {
			insereInstrucaoDoisOperandos( MOV, p1, p2 );
		} else if( comando.equals( "ADD" ) ) {
			insereInstrucaoDoisOperandos( ADD, p1, p2 );
		} else if( comando.equals( "SUB" ) ) {
			insereInstrucaoDoisOperandos( SUB, p1, p2 );
		} else if( comando.equals( "CMP" ) ) {
			insereInstrucaoDoisOperandos( CMP, p1, p2 );
		} else if( comando.equals( "AND" ) ) {
			insereInstrucaoDoisOperandos( AND, p1, p2 );
		} else if( comando.equals( "OR" ) ) {
			insereInstrucaoDoisOperandos( OR, p1, p2 );
		} else if( comando.equals( "SOB" ) ) {
			insereComandoSOB( p1, p2 );
		} else if( comando.equals( "JSR" ) ) {
			insereComandoJSR( p1 );
		} else if( comando.equals( "RTS" ) ) {
			insereComandoRTS();
		} else if( comando.equals( "PUSH" ) ) {
			criaComandoPush( p1 );
		} else if( comando.equals( "POP" ) ) {
			criaComandoPop( p1 );
		}
	}
	

	private void insereDesvioIncondicional( String endereco ) throws ErroGeracaoCodigoException {

		Operando end = new Operando( endereco );
		
		if( end.isOperadorValido() ) {
			
			if( end.getTpOperando() == Operando.REGISTRADOR ) {
				geraErro( "Imposs�vel efetuar um Jump para um registrador." );
			} else if ( end.getTpOperando() == Operando.VALOR_CONTIDO_NO_ENDERECO ) {
				geraErro( "Imposs�vel efetuar um Jump local apontado por um endere�o de mem�ria." );
			} else if( end.getTpOperando() == Operando.ENDERECO_LABEL ) {
				/* N�o troque a ordem */
				insereComando( JMP );
				registraJumpPendente( end );
				insereComando( (byte) 0 );
				insereComando( (byte) 0 );
				insereComando( (byte) 0 );
			} else {
				insereComando( JMP );
				insereComando( end.getComando() );
			}
		} else {
			geraErro( "Endere�o inv�lido - " + endereco );
		}
	}

	private void insereInstrucaoUmOperando( byte comando, String operando ) throws ErroGeracaoCodigoException {
		
		Operando oper = new Operando( operando );
		
		if( oper.isOperadorValido() ) {
			
			if( oper.getTpOperando() == Operando.VALOR_ABSOLUTO ) {
				geraErro( "Imposs�vel efetuar um comando sobre um valor absoluto." );
			} else if( oper.getTpOperando() == Operando.ENDERECO_LABEL ) {
				geraErro( "Imposs�vel efetuar um comando em um label." );
			} else {
				insereComando( comando );
				insereComando( oper.getComando() );
			}
		} else {
			geraErro( "Operando inv�lido - " + operando );
		}
	}
	
	private void insereInstrucaoDoisOperandos( byte comando, String p1, String p2 ) throws ErroGeracaoCodigoException {

		Operando op1 = new Operando( p1 );
		Operando op2 = new Operando( p2 );
		
		if( op1.isOperadorValido() && op2.isOperadorValido() ) {

			if( op2.getTpOperando() == Operando.ENDERECO_LABEL ) {
				geraErro( "Imposs�vel fazer uma opera��o sobre um label: " + p1 + "/" + p2 );
			} else if( op2.getTpOperando() == Operando.VALOR_ABSOLUTO ) {
				geraErro( "Imposs�vel fazer uma opera��o sobre valor absoluto: " + p2 );
			} else {
				byte[] cmd1 = op1.getComando();
				byte[] cmd2 = op2.getComando();
				
				byte cmd = (byte) ( cmd1[ 0 ] >> 2 );
				comando = (byte) ( (byte) comando | (byte) cmd );

				cmd = (byte) ( cmd1[ 0 ] << 6 );
				cmd = (byte) ( cmd | cmd2[ 0 ] );
				
				insereComando( comando );
				insereComando( cmd );
				
				if( op1.getTpOperando() == Operando.ENDERECO_LABEL ) {
					registraEnderecoPendente( op1 );
				}
				
				for( int i = 1; i < cmd1.length; i++ ) {
					insereComando( cmd1[ i ] );
				}

				for( int i = 1; i < cmd2.length; i++ ) {
					insereComando( cmd2[ i ] );
				}
			}
		} else {
			geraErro( "Operando inv�lido - " + p1 + "/" + p2 );
		}
	}

	private void criaComandoPush( String p1 ) throws ErroGeracaoCodigoException {

		Operando op1 = new Operando( p1 );
		
		if( op1.isOperadorValido() ) {

			byte[] cmd1 = op1.getComando();
			byte[] cmd2 = Operando.geraEnderecoPush();
			byte comando = MOV;
			
			byte cmd = (byte) ( cmd1[ 0 ] >> 2 );
			comando = (byte) ( (byte) comando | (byte) cmd );
			
			cmd = (byte) ( cmd1[ 0 ] << 6 );
			cmd = (byte) ( cmd | cmd2[ 0 ] );
			
			insereComando( comando );
			insereComando( cmd );
			
			if( op1.getTpOperando() == Operando.ENDERECO_LABEL ) {
				registraEnderecoPendente( op1 );
			}

			for( int i = 1; i < cmd1.length; i++ ) {
				insereComando( cmd1[ i ] );
			}

			for( int i = 1; i < cmd2.length; i++ ) {
				insereComando( cmd2[ i ] );
			}
		} else {
			geraErro( "Operando inv�lido - " + p1 );
		}
	}

	private void criaComandoPop( String p1 ) throws ErroGeracaoCodigoException {

		Operando op2 = new Operando( p1 );
		
		if( op2.isOperadorValido() ) {

			if( op2.getTpOperando() == Operando.ENDERECO_LABEL ) {
				geraErro( "Imposs�vel fazer um push de um label: " + p1 );
			} else {
				byte[] cmd1 = Operando.geraEnderecoPop();
				byte[] cmd2 = op2.getComando();
				byte comando = MOV;
				
				byte cmd = (byte) ( cmd1[ 0 ] >> 2 );
				comando = (byte) ( (byte) comando | (byte) cmd );
				
				cmd = (byte) ( cmd1[ 0 ] << 6 );
				cmd = (byte) ( cmd | cmd2[ 0 ] );
				
				insereComando( comando );
				insereComando( cmd );
				
				for( int i = 1; i < cmd1.length; i++ ) {
					insereComando( cmd1[ i ] );
				}

				for( int i = 1; i < cmd2.length; i++ ) {
					insereComando( cmd2[ i ] );
				}
			}
		} else {
			geraErro( "Operando inv�lido - " + p1 );
		}
	}

	private void insereDesvioCondicional( byte cmdDesvio, String nmLabel ) throws ErroGeracaoCodigoException {

		Operando lbl = new Operando( nmLabel );
		
		if( lbl.isOperadorValido() ) {
			
			if( lbl.getTpOperando() == Operando.ENDERECO_LABEL ) {

				insereComando( cmdDesvio );
				registraDesvioPendente( nmLabel );
				insereComando( NOP );
			} else {
				geraErro( "Um desvio condicional necessita um label para o desvio." );
			}
		} else {
			geraErro( "Operando inv�lido - " + nmLabel );
		}
	}

	private void insereComandoSOB( String p1, String p2 ) throws ErroGeracaoCodigoException {

		Operando op1 = new Operando( p1 );
		Operando op2 = new Operando( p2 );

		if( op1.isOperadorValido() && op2.isOperadorValido() ) {
			
			if( op1.getTpOperando() != Operando.REGISTRADOR ) {
				geraErro( "Opera��o SOB necessita de um Registrador no primeiro operando." );
			} else {
				
				if( op2.getTpOperando() != Operando.ENDERECO_LABEL ) {
					geraErro( "Opera��o SOB necessita de um Label no segundo operando." );
				} else {
					
					byte comando = (byte) ( SOB | op1.getNrRegistrador() );

					insereComando( comando );
					registraDesvioPendente( op2.getDsEndereco() );
					insereComando( (byte) -1 );
				}
			}
		} else {
			geraErro( "Operando inv�lido - " + p1 + "/" + p2 );
		}
	}

	private void insereComandoJSR( String p1 ) throws ErroGeracaoCodigoException {
		
		Operando op1 = new Operando( p1 );

		if( op1.isOperadorValido() ) {
			
			if( op1.getTpOperando() != Operando.ENDERECO_LABEL ) {
				geraErro( "Opera��o JSR necessita de um Label como operando." );
			} else {
				byte comando = (byte) ( JSR | 7 );
				insereComando( comando );
				registraJumpPendente( op1 );
				insereComando( (byte) 0 );
				insereComando( (byte) 0 );
				insereComando( (byte) 0 );
			}
		} else {
			geraErro( "Operando inv�lido - " + p1 );
		}
	}

	private void insereComandoRTS() {
		
		insereComando( (byte) ( RTS | 7 ) );
	}

	private void insereComandoCodigoCondicao( byte comando, String p1 ) throws ErroGeracaoCodigoException {
		
		if( p1 == null ) {
			geraErro( "Uma instru��o sobre os c�digos de condi��o (CCC/SCC) necessita um indicador de flag." );
		}
		
		if( p1.indexOf( "C" ) >= 0 ) comando |= (byte) 0x01;
		if( p1.indexOf( "V" ) >= 0 ) comando |= (byte) 0x02;
		if( p1.indexOf( "Z" ) >= 0 ) comando |= (byte) 0x04;
		if( p1.indexOf( "N" ) >= 0 ) comando |= (byte) 0x08;
		
		insereComando( comando );
	}

	private void geraErro( String msgErro ) throws ErroGeracaoCodigoException {
		System.out.println( "Erro linha " + nrLinha + ": " + msgErro );
		throw new ErroGeracaoCodigoException( "Erro linha " + nrLinha + ": " + msgErro );
	}

	private void insereComando( byte cmd ) {
		codigoMem[ ptrInstrucao++ ] = cmd;
	}

	private void insereComando( byte[] cmds ) {
		
		for( int i = 0; i < cmds.length; i++ ) {
			insereComando( cmds[ i ] );
		}
	}

	private void registraLabel( String nmLabel ) throws ErroGeracaoCodigoException {

		if( tblLabels == null ) {
			tblLabels = new Hashtable();
		}
		
		if( tblLabels.containsKey( nmLabel ) ) {
			geraErro( "Label duplicado - '" + nmLabel + "'" );
		}
		
		Integer nrLinha = new Integer( ptrInstrucao - 4 );
		tblLabels.put( nmLabel, nrLinha );
	}

	private void registraDesvioPendente( String nmLabel ) {

		if( desviosPendentes == null ) {
			desviosPendentes = new Vector();
		}

		Integer nrLinha = new Integer( ptrInstrucao - 4 );
		
		Vector dadosDesvio = new Vector( 2 );
		dadosDesvio.add( nmLabel );
		dadosDesvio.add( nrLinha );
		
		desviosPendentes.add( dadosDesvio );
	}

	private void registraJumpPendente( Operando endJump ) throws ErroGeracaoCodigoException {
		
		if( jumpsPendentes == null ) {
			jumpsPendentes = new Vector();
		}

		Integer nrLinha = new Integer( ptrInstrucao - 4 );
		
		Vector dadosJump = new Vector( 2 );
		dadosJump.add( endJump );
		dadosJump.add( nrLinha );
		
		jumpsPendentes.add( dadosJump );
		
		if( ehRotinaDeBiblioteca( endJump.getDsEndereco() ) ) {

			String modulo = (String) getTblRotinasBiblioteca().get( endJump.getDsEndereco() );

			if( !getModulosCarregados().contains( modulo ) ) {
				carregaModulo( modulo );
			}
		}
	}

	private void registraEnderecoPendente( Operando endereco ) {
		
		if( enderecosPendentes == null ) {
			enderecosPendentes = new Vector();
		}

		Integer nrLinha = new Integer( ptrInstrucao - 4 );
		
		Vector dadosEndereco = new Vector( 2 );
		dadosEndereco.add( endereco );
		dadosEndereco.add( nrLinha );
		
		enderecosPendentes.add( dadosEndereco );
	}
	
	private boolean ehRotinaDeBiblioteca( String dsEndereco ) throws ErroGeracaoCodigoException {

		return getTblRotinasBiblioteca().containsKey( dsEndereco );
	}

	private void carregaModulo( String modulo ) throws ErroGeracaoCodigoException {

		try {
			BufferedReader in = new BufferedReader( new InputStreamReader( getClass().getClassLoader().getResourceAsStream( (String) ( "asm/" + modulo ) ) ) );

			try {
				String s;
				codigoAsm.append( "\n" );

				while( ( s = in.readLine() ) != null ) {
					codigoAsm.append( (String) s + "\n" );
				}
			} finally {
				in.close();
			}
		} catch( Exception e ) {
			e.printStackTrace();
			throw new ErroGeracaoCodigoException( "Erro ao carregar biblioteca: " + e.getMessage() );				
		}
		getModulosCarregados().add( modulo );
	}

	private Vector getModulosCarregados() {
		
		if( modulosCarregados == null ) {
			modulosCarregados = new Vector();
		}

		return modulosCarregados;
	}

	private Hashtable getTblRotinasBiblioteca() throws ErroGeracaoCodigoException {

		if( tblRotinasBiblioteca == null ) {
			tblRotinasBiblioteca = new Hashtable();
			carregaIndiceDaBiblioteca();
		}
		
		return tblRotinasBiblioteca;
	}

	private void carregaIndiceDaBiblioteca() throws ErroGeracaoCodigoException {

		try {
			BufferedReader in = new BufferedReader( new InputStreamReader( getClass().getClassLoader().getResourceAsStream( "asm/lib.index" ) ) );
			
			try {
				
				int ch;
				int estado = 0;
				
				StringBuffer funcao =  new StringBuffer();
				StringBuffer modulo =  new StringBuffer();
				
				while( ( ch = in.read() ) != -1 ) {

					switch( ch ) {
						case '=': 
							estado++;
							break;
						case '\n':
							registraFuncaoDeBiblioteca( funcao, modulo );

							funcao.delete( 0, funcao.length() );
							modulo.delete( 0, modulo.length() );
							estado = 0;

							break;
						default:
							if( estado == 0 ) {
								funcao.append( (char) ch );
							} else {
								modulo.append( (char) ch );
							}
					}
				}
				registraFuncaoDeBiblioteca( funcao, modulo );
				
			} finally {
				in.close();
			}
		} catch( Exception e ) {
			e.printStackTrace();
			throw new ErroGeracaoCodigoException( "Erro ao carregar biblioteca: " + e.getMessage() );				
		}
	}

	private void registraFuncaoDeBiblioteca( StringBuffer funcao, StringBuffer modulo ) {
		tblRotinasBiblioteca.put( funcao.toString(), modulo.toString() );
	}
	
	private void resolveEnderecos() throws ErroGeracaoCodigoException {
		
		if( enderecosPendentes != null ) {
			
			Iterator enderecos = enderecosPendentes.iterator();
			
			while( enderecos.hasNext() ) {
				
				Vector umEndereco = (Vector) enderecos.next(); 
				
				String  chave = ((Operando) umEndereco.get( 0 )).getDsEndereco() + ":";
				Integer local = (Integer) umEndereco.get( 1 );
				Integer localDesvio = (Integer) tblLabels.get( chave ); 
				
				if( localDesvio == null ) geraErro( "Label n�o encontrado - '" + chave + "' (resolveEnderecos)" );

				int endereco = localDesvio.intValue() - 1;
				
				codigoMem[ local.intValue() + 4 ] = (byte) (endereco >> 8);
				codigoMem[ local.intValue() + 5 ] = (byte) endereco;
			}
		}
	}

	private void resolveDesvios() throws ErroGeracaoCodigoException {
		
		if( desviosPendentes != null ) {
			
			Iterator desvios = desviosPendentes.iterator();
			
			while( desvios.hasNext() ) {
				
				Vector umDesvio = (Vector) desvios.next(); 
				
				String  chave = (String) umDesvio.get( 0 ) + ":";
				Integer local = (Integer) umDesvio.get( 1 );
				Integer localDesvio = (Integer) tblLabels.get( chave ); 
				
				if( localDesvio == null ) geraErro( "Label n�o encontrado - '" + chave + "' (resolveDesvios)" );

				byte dif = (byte) ( localDesvio.intValue() - local.intValue() - 1 );
				
				if( codigoMem[ local.intValue() + 4 ] == -1 ) dif *= -1;
				codigoMem[ local.intValue() + 4 ] = dif;
			}
		}
	}

	private void resolveJumps() throws ErroGeracaoCodigoException {
		
		if( jumpsPendentes != null ) {
			
			Iterator jumps = jumpsPendentes.iterator();
			
			while( jumps.hasNext() ) {
				
				Vector umJump = (Vector) jumps.next();
				
				Operando endJump = (Operando) umJump.get( 0 );
				Integer local = (Integer) umJump.get( 1 );

				Integer localDesvio = (Integer) tblLabels.get( endJump.getDsEndereco()  + ":" ); 
				
				if( localDesvio == null ) geraErro( "Label n�o encontrado - '" + endJump.getDsEndereco() + "' (resolveJumps)" );

				endJump.registraValorAbsoluto( localDesvio.shortValue() );
				
				byte[] comdDesvio = endJump.getComando();
				
				codigoMem[ local.intValue() + 4 ] = comdDesvio[ 0 ];
				codigoMem[ local.intValue() + 5 ] = comdDesvio[ 1 ];
				codigoMem[ local.intValue() + 6 ] = comdDesvio[ 2 ];
			}
		}
	}

	private int posSeparador( String linha ) {
		int sp = 0;

		while( sp < linha.length() ) {
			
			if( linha.charAt( sp ) == ' '  || 
				linha.charAt( sp ) == '\t' ||
				linha.charAt( sp ) == '\r' || 
				linha.charAt( sp ) == '\n' ) {

				return sp;
			}
			sp++;
		}

		return linha.length();
	}
}
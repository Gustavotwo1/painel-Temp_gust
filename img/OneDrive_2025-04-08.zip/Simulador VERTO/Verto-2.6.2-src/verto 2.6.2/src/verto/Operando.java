package verto;
import verto.exception.ErroGeracaoCodigoException;

/*
 * $Id: Operando.java,v 1.2 2008/04/07 17:36:50 mariana Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2010 Lucas Eskeff Freitas
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**
 * TODO Operando.java - Descricao do arquivo
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * 
 * @version 2.6.2
 * 
 */
public class Operando {
	
	public static final int VALOR_ABSOLUTO = 0; 
	public static final int VALOR_CONTIDO_NO_ENDERECO = 1; 
	public static final int REGISTRADOR = 2; 
	public static final int ENDERECO_APONTADO_REGISTRADOR = 3;
	public static final int ENDERECO_APONTADO_REGISTRADOR_INDEXADO = 4; 
	public static final int ENDERECO_LABEL = 5;
	
	private static final byte CMD_REGISTRADOR = (byte) 0x00;
	private static final byte CMD_REGISTRADOR_POS = (byte) 0x08;
	private static final byte CMD_REGISTRADOR_PRE = (byte) 0x10;
	private static final byte CMD_INDEXADO = (byte) 0x18;
	private static final byte CMD_REGISTRADOR_IND = (byte) 0x20;
	private static final byte CMD_REGISTRADOR_IND_POS = (byte) 0x28;
	private static final byte CMD_REGISTRADOR_IND_PRE = (byte) 0x30;
	private static final byte CMD_INDEXADO_INDIRETO = (byte) 0x38;
	
	private String dsEndereco;
	
	private String dsLabel;
	private int nrRegistrador = -1;
	private int tpOperando = -1;
	private int vlAbsoluto;
	private short vlIndice;
	
	private boolean enderecoValido = false;
	
	private byte comando = 0;
	
	public Operando( String endereco ) {
		
		dsEndereco = endereco.trim();
		analisaEndereco();
	}
	
	private void analisaEndereco() {
		
		enderecoValido = false;
		String endereco = dsEndereco;
		
		boolean indireto = false;
		boolean indexado = false;
		boolean valorAbsoluto = false;
		boolean valorReal = false;
		boolean enderecoLabel = false;
		
		nrRegistrador = -1;
		vlIndice = 0;
		
		if( endereco.charAt( 0 ) == '[' ) {

			indireto = true;
			
			int ultimo = endereco.length() - 1;
			
			if( endereco.charAt( ultimo ) != ']' ) {
				return;
			}
			
			endereco = endereco.substring( 1, ultimo ).trim(); 
		} 

		if( endereco.charAt( 0 ) == 'R' && ( endereco.substring( 1, 2 ).matches( "0|1|2|3|4|5|6|7" ) ) ) {
			
			nrRegistrador = Integer.parseInt( endereco.substring( 1, 2 ) );
			
			endereco = endereco.substring( 2 ).trim();
			
			if( endereco.length() > 0 && ( endereco.charAt( 0 ) == '+' || endereco.charAt( 0 ) == '-' ) ) {

				indexado = true;
				char oper = endereco.charAt( 0 );
				
				endereco = endereco.substring( 1 ).trim();
				
				try {
					vlIndice = Short.parseShort( endereco );
					
					if( oper == '-' ) {
						vlIndice *= -1;
					}
				} catch( Exception e ) {
					return;
				}
			}
		} else {
			
			String sVl = endereco;
			int base = 10;

			if( endereco.startsWith( "0X" ) ) {
				sVl = endereco.substring( 2 );
				base = 16;
			}
			
			try {
				vlAbsoluto = Integer.parseInt( sVl, base );
				valorAbsoluto = true;
			} catch( Exception e ) {

				if( indireto ) return;
				dsLabel = endereco;
				enderecoLabel = true;
			}
		}
		
		if( indireto ) {
			if( valorAbsoluto ) {
				tpOperando = VALOR_CONTIDO_NO_ENDERECO;
				nrRegistrador = 7;
			} else if( nrRegistrador >= 0 ) {
				if( indexado ) {
					tpOperando = ENDERECO_APONTADO_REGISTRADOR_INDEXADO;
				} else {
					tpOperando = ENDERECO_APONTADO_REGISTRADOR;
				}
			} else {
				return;
			}
		} else {
			if( nrRegistrador >= 0 ) {
				tpOperando = REGISTRADOR;
			} else if( valorAbsoluto ){
				tpOperando = VALOR_ABSOLUTO;
				valorReal = false;
				nrRegistrador = 7;
			} else if( valorReal ) {
				tpOperando = VALOR_ABSOLUTO;
				valorReal = true;
				nrRegistrador = 7;
			} else if( enderecoLabel ) {
				tpOperando = ENDERECO_LABEL;
			} else {
				return;
			}
		}

		enderecoValido = true;
	}
	
	public int getNrRegistrador() {
		return nrRegistrador;
	}

	public int getTpOperando() {
		return tpOperando;
	}

	public boolean isOperadorValido() {
		return enderecoValido;
	}
	
	public byte[] getComando() throws ErroGeracaoCodigoException {
		
		byte[] result = null;
		
		switch( tpOperando ) {
			case ENDERECO_LABEL:
				vlAbsoluto = 0;
				nrRegistrador = 7;
				// sem break, continua em valor absoluto.
			case VALOR_ABSOLUTO:
				result = new byte[ 3 ];
				result[ 0 ] = (byte) ( CMD_REGISTRADOR_POS | nrRegistrador );
				result[ 1 ] = (byte) ( ( vlAbsoluto & 0xFF00 ) >> 8 );
				result[ 2 ] = (byte) ( vlAbsoluto & 0x00FF );
				break;

			case VALOR_CONTIDO_NO_ENDERECO:
				result = new byte[ 3 ];
				result[ 0 ] = (byte) ( CMD_REGISTRADOR_IND_POS | nrRegistrador );
				result[ 1 ] = (byte) ( ( vlAbsoluto & 0xFF00 ) >> 8 );
				result[ 2 ] = (byte) ( vlAbsoluto & 0x00FF );
				break;
			
			case REGISTRADOR:
				result = new byte[ 1 ];
				result[ 0 ] = (byte) nrRegistrador;
				break;

			case ENDERECO_APONTADO_REGISTRADOR:
				result = new byte[ 1 ];
				result[ 0 ] = (byte) ( CMD_REGISTRADOR_IND | nrRegistrador );
				break;
				
			case ENDERECO_APONTADO_REGISTRADOR_INDEXADO:
				result = new byte[ 3 ];
				result[ 0 ] = (byte) ( CMD_INDEXADO | nrRegistrador );
				result[ 1 ] = (byte) ( ( vlIndice & 0xFF00 ) >> 8 );
				result[ 2 ] = (byte) ( vlIndice & 0x00FF );
				break;
				
			default: 
				throw new ErroGeracaoCodigoException( "Modo de endere�amento n�o suportado"  );
		}
		
		return result;
	}
	
	public static byte[] geraEnderecoPush() {
		
		int nrReg = 6;
		byte[] result = new byte[ 1 ];
		result[ 0 ]= (byte) ( CMD_REGISTRADOR_PRE | nrReg );
		return result;
	}
	
	public static byte[] geraEnderecoPop() {

		int nrReg = 6;
		byte[] result = new byte[ 1 ];
		result[ 0 ]= (byte) ( CMD_REGISTRADOR_POS | nrReg );
		return result;
	}

	public String getDsEndereco() {
		return dsEndereco;
	}
	
	public void registraValorAbsoluto( short vlEndereco ) {
		
		vlAbsoluto = vlEndereco;
		nrRegistrador = 7;
		tpOperando = VALOR_CONTIDO_NO_ENDERECO;
	}

}
package verto.lexico;
import java.awt.Color;

import javax.swing.JTextArea;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;

import verto.Verto;
import verto.exception.ErroLexicoException;
import verto.sintatico.Sintatico;

/*
 * $Id: Lexico.java,v 1.5 2008/04/24 12:01:25 ricardo Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2010 Lucas Eskeff Freitas
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
 

/**
 * Classe: Analisador L�xico
 * 
 * Este Analisador L�xico cont�m os tipos dos tokens bem como os m�todos para
 * classifica��o e obten��o de lexemas.
 *  
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * @author Vandersilvio da Silva
 *  
 * @see Lexico
 * @see Sintatico
 * @see ErroLexicoException
 * 
 * @version 2.6.2
 */
public class Lexico {

	public static final int T_FALSO				= 0;
	public static final int T_VERDADEIRO		= 1;
	public static final int T_ESCREVA			= 2;
	public static final int T_SE				= 3;
	public static final int T_ENTAO				= 4;
	public static final int T_SENAO				= 5;
	public static final int T_ENQUANTO 			= 6;
	public static final int T_FUNCAO			= 7;
	public static final int T_OU				= 8;
	public static final int T_E					= 9;
	public static final int T_NEGUE				= 10;
	public static final int T_INTEIRO			= 11;
	public static final int T_CARACTER			= 12;
	public static final int T_LOGICO			= 13;
	public static final int T_VAZIO 			= 14;
	public static final int T_LEIA				= 15;
	public static final int T_APAGATELA			= 16;
	public static final int T_RETORNE			= 17;
	public static final int T_PROTOTIPO			= 18;
	public static final int T_PARAINTEIRO		= 19;
	public static final int T_PARA				= 20;
	public static final int T_REPITA			= 21;
	public static final int T_ATE				= 22;
	public static final int T_PARACARACTER		= 23;
	public static final int T_CASOS				= 24;
	public static final int T_CASO				= 25;
	
	public static final int T_ATRIBUICAO		= 30; 
	
	public static final int T_MAIS				= 40;
	public static final int T_MENOS				= 41;
	public static final int T_VEZES				= 42;
	public static final int T_SOBRE				= 43;

	public static final int T_MAIOR				= 50;
	public static final int T_MENOR				= 51;
	public static final int T_MAIOR_IGUAL		= 52;
	public static final int T_MENOR_IGUAL		= 53;
	public static final int T_IGUAL				= 54;
	public static final int T_DIFERENTE			= 55;
	public static final int T_CONSTANTE			= 56;

	public static final int T_VIRGULA			= 60;
	public static final int T_DOIS_PONTOS		= 61;
	public static final int T_ABRE_PAR			= 62;
	public static final int	T_FECHA_PAR			= 63;
	public static final int T_PONTO				= 64;
	public static final int T_PONTO_VIRGULA		= 65;
	public static final int T_ABRE_CHAVE		= 66;
	public static final int	T_FECHA_CHAVE		= 67;
	public static final int T_ABRE_COLCHETES	= 68;
	public static final int	T_FECHA_COLCHETES	= 69;

	public static final int T_TEXTO				= 80;
	public static final int T_NUMERO_INTEIRO	= 81;
	public static final int T_NUMERO_REAL		= 82;
	public static final int T_ID				= 83;  
	public static final int T_ROTULO			= 84;
	public static final int T_VA   				= 85; 

	public static final int	T_COMENTARIO		= 70;

	public static final int T_FIM_COMANDO		= 90;
	public static final int T_DESCONHECIDO		= 91;
	public static final int T_FIM_FONTE			= 92;
	public static final int T_NULO				= 93;

	private String  lexema;
	private String  ultimoLexema;
	private int 	token;
	private int 	ultimoToken;
	private char	lookahead;
	private String	textoInteiro;
	private int		posicaoNoTexto;
	private int     posicaoInicial;
	private int     posicaoFinal;
	private	int		linha;
	private int		coluna;	
	private String  brancos;	
	private String  brancosplus;	
	//private boolean isDentroDeString;
	
	private JTextArea   areaDoEditor = null; 
	private Highlighter h = null;
	
    private StringBuffer saidaLexico;
	
    public Lexico( JTextArea areaTexto ) {
    	this( areaTexto.getText() );
    	
		textoInteiro 	 	= areaTexto.getText();
		linha 			 	= 0;
		coluna 			 	= 0;
		posicaoNoTexto	 	= 0;
		token  			 	= T_NULO;
        //isDentroDeString 	= false;

		saidaLexico = new StringBuffer();
        
		StringBuffer whites = new StringBuffer();
		whites.append( ' ' );
		whites.append( (char) 9 );
		whites.append( (char) 10 );
		whites.append( (char) 12 );
		whites.append( (char) 13 );
		
		brancos = whites.toString();

		whites.append( (char) 13 );
		brancosplus = whites.toString();
		
		Verto.getInstance().setFimBarraProgresso( textoInteiro.length() );
    	
    	areaDoEditor = areaTexto;
		h = areaDoEditor.getHighlighter();
		h.removeAllHighlights();
		
		buscaProximaPalavraReservada();
    }
    
	/** Construtor que recebe o texto fonte */
	public Lexico ( String texto ) {
		
		textoInteiro 	 	= texto;
		linha 			 	= 0;
		coluna 			 	= 0;
		posicaoNoTexto	 	= 0;
		token  			 	= T_NULO;
   //     isDentroDeString 	= false;

		saidaLexico = new StringBuffer();
        
		StringBuffer whites = new StringBuffer();
		whites.append( ' ' );
		whites.append( (char) 9 );
		whites.append( (char) 10 );
		whites.append( (char) 12 );
		whites.append( (char) 13 );
		
		brancos = whites.toString();

		whites.append( (char) 13 );
		brancosplus = whites.toString();
		
		Verto.getInstance().setFimBarraProgresso( textoInteiro.length() );
		
		proximoToken( false );
		proximoToken( true ); 
	}

	private void moveLookahead() {
		if ( posicaoNoTexto >= textoInteiro.length() ) {
			lookahead = (char) 26;
		} else {	
			lookahead = textoInteiro.charAt( posicaoNoTexto );
			switch( lookahead ) {
			case 13: break;
			case 10: linha++;
					 coluna = 0;
					 Verto.getInstance().setLinhaErro( linha+1 );
					 break;
			default: coluna++;				
			}
			posicaoNoTexto++;
			Verto.getInstance().atualizaBarraProgresso( posicaoNoTexto );
		}
	}

	public boolean proximoToken() {

		return proximoToken( true );
	}	

	public boolean proximoToken( boolean exibe ) {
		return  buscaProximoToken( exibe );
	}	

	public boolean ressaltaProximoToken() {
		
		while ( buscaProximaPalavraReservada() ) {
		}
		
		return true;
	}

	private boolean buscaProximaPalavraReservada() {
		
		lexema = "";
		StringBuffer esteToken = new StringBuffer();

		if( !isAlpha( lookahead ) ) {
			while( brancos.toString().indexOf( lookahead ) >= 0 || !isAlpha( lookahead ) ) {

				moveLookahead();
				if ( lookahead == (char) 26 ) {
					return false;
				}
			}
		}
		
		if( isAlpha( lookahead ) ) {
			
			posicaoInicial = posicaoNoTexto;
			
			while( isAlpha( lookahead ) ||
				   isDigit( lookahead ) ||
				   isPonteiro( lookahead ) ) {

					esteToken.append( lookahead );
					moveLookahead();
			}
			
			posicaoFinal = posicaoNoTexto;
			
			lexema = esteToken.toString().toUpperCase();

			if( lexema.equals( "LEIA" ) ||
			    lexema.equals( "ESCREVA" ) ||
			    lexema.equals( "IMPRIMA" ) ||
			    lexema.equals( "SE" ) ||
			    lexema.equals( "ENTAO" ) ||
			    lexema.equals( "SENAO" ) ||
			    lexema.equals( "IMPRIMA" ) ||
			    lexema.equals( "ENQUANTO" ) ||
			    lexema.equals( "OU" ) ||
			    lexema.equals( "E" ) ||
			    lexema.equals( "NEGUE" ) ||
			    lexema.equals( "INTEIRO" ) ||
			    lexema.equals( "CARACTER" ) ||
			    lexema.equals( "LOGICO" ) ||
			    lexema.equals( "VAZIO" ) ||
			    lexema.equals( "VERDADEIRO" ) ||
			    lexema.equals( "FALSO" ) ||
			    lexema.equals( "FUNCAO" ) ||
			    lexema.equals( "INTEIRO" ) ||
			    lexema.equals( "PRINCIPAL" ) ||
			    lexema.equals( "APAGATELA" ) ||
			    lexema.equals( "RETORNE" ) ||
			    lexema.equals( "PROTOTIPO" ) ||
			    lexema.equals( "PARAINTEIRO" ) ||
			    lexema.equals( "PARA" ) ||
			    lexema.equals( "REPITA" ) ||
			    lexema.equals( "CASOS" ) ||
			    lexema.equals( "CASO" ) ||
			    lexema.equals( "ATE" ) ) {
				
				try {
//					h.addHighlight(posicaoInicial-1, posicaoFinal-1, new DefaultHighlighter.DefaultHighlightPainter(Color.yellow ) );
					h.addHighlight(posicaoInicial-1, posicaoFinal-1, new DefaultHighlighter.DefaultHighlightPainter( new Color( 180, 220, 250 ) ) );
				} catch (BadLocationException e) {
					e.printStackTrace();
				}
				
			} 
			
			lexema = esteToken.toString();
		} 
		return true;
	}
	
	private boolean buscaProximoToken( boolean exibe ) {

		ultimoToken  = token;
		ultimoLexema = lexema;

		lexema = "";
		
		StringBuffer esteToken = new StringBuffer();

		while( brancos.toString().indexOf( lookahead ) >= 0 ) {
			moveLookahead();
		}
		

		
		if( isAlpha( lookahead ) ) {
			
			while( isAlpha( lookahead ) ||
				   isDigit( lookahead ) ||
				   isPonteiro( lookahead ) ) {

					esteToken.append( lookahead );
					moveLookahead();
			}
			
			lexema = esteToken.toString().toUpperCase();

			if( lexema.equals( "LEIA" ) ) {
				token = T_LEIA;
			} else if( lexema.equals( "ESCREVA" ) ) {
				token = T_ESCREVA;
			} else if( lexema.equals( "IMPRIMA" ) ) {
				token = T_ESCREVA;
			} else if( lexema.equals( "SE" ) ) {
				token = T_SE;
			} else if( lexema.equals( "ENTAO" ) ) {
				token = T_ENTAO;
			} else if( lexema.equals( "SENAO" ) ) {
				token = T_SENAO;
			} else if( lexema.equals( "ENQUANTO" ) ) {
				token = T_ENQUANTO;
			} else if( lexema.equals( "OU" ) ) {
				token = T_OU;
			} else if( lexema.equals( "E" ) ) {
				token = T_E;
			} else if( lexema.equals( "NEGUE" ) ) {
				token = T_NEGUE;
			} else if( lexema.equals( "INTEIRO" ) ) {
				token = T_INTEIRO;
			} else if( lexema.equals( "CONSTANTE" ) ) {
				token = T_CONSTANTE;
			} else if( lexema.equals( "CARACTER" ) ) {
				token = T_CARACTER;
			} else if( lexema.equals( "LOGICO" ) ) {
				token = T_LOGICO;
			} else if( lexema.equals( "VAZIO" ) ) {
				token = T_VAZIO;
			} else if( lexema.equals( "VERDADEIRO" ) ) {
				token = T_VERDADEIRO;
			} else if( lexema.equals( "FALSO" ) ) {
				token = T_FALSO;
			} else if( lexema.equals( "FUNCAO" ) ) {
				token = T_FUNCAO;
			} else if( lexema.equals( "APAGATELA" ) ) {
				token = T_APAGATELA;
			} else if( lexema.equals( "RETORNE" ) ) {
				token = T_RETORNE;
			} else if( lexema.equals( "PROTOTIPO" ) ) {
				token = T_PROTOTIPO;
			} else if( lexema.equals( "PARAINTEIRO" ) ) {
				token = T_PARAINTEIRO;
			} else if( lexema.equals( "PARACARACTER" ) ) {
				token = T_PARACARACTER;
			} else if( lexema.equals( "PARA" ) ) {
				token = T_PARA;
			} else if( lexema.equals( "REPITA" ) ) {
				token = T_REPITA;
			} else if( lexema.equals( "ATE" ) ) {
				token = T_ATE;
			}else if( lexema.equals( "VA" ) ) {
				token = T_VA;
			} else if( lexema.equals( "CASOS" ) ) {
				token = T_CASOS;
			} else if( lexema.equals( "CASO" ) ) {
				token = T_CASO;
			} else {
				token = T_ID;
			}
			
			lexema = esteToken.toString();

		} else if( isDigit( lookahead ) ) { 

			StringBuffer sb = new StringBuffer();
			
			while ( lookahead != '.' && isDigit( lookahead ) ) {
				sb.append( lookahead );				
				moveLookahead();
				token = T_NUMERO_INTEIRO;			
			}
			
			if ( lookahead == '.' ) {
				sb.append( lookahead );				
				moveLookahead();
				while ( isDigit( lookahead ) ) {
					sb.append( lookahead );				
					moveLookahead();
				}
				token = T_NUMERO_REAL;			
			}
			lexema = sb.toString();

		} else if( lookahead == '#' ) {

			StringBuffer sb = new StringBuffer();

			sb.append( '#' );
			moveLookahead();
			
			while( isAlpha( lookahead ) ||
				   isDigit( lookahead ) ||
				   isPonteiro( lookahead ) ) 
			{
				sb.append( lookahead );
				moveLookahead();
			}
			
			token = T_ROTULO;
			lexema = sb.toString();

		} else if( lookahead == '.' ) {
			
			token = T_PONTO;
			lexema = ".";			
			moveLookahead();

		} else if( lookahead == ';' ) {

			token = T_PONTO_VIRGULA;
			lexema = ";";			
			moveLookahead();

		} else if( lookahead == '"' || lookahead == '\'' ) {

			char fechador = lookahead;
			
			StringBuffer sb = new StringBuffer();
			
			moveLookahead();
			while ( lookahead != fechador ) {
				sb.append( lookahead );				
				moveLookahead();
			}
			lexema = sb.toString();
			token = T_TEXTO;		
			moveLookahead();

		} else if( lookahead == '*' ) {
			
			token = T_VEZES;			
			lexema = "*";
			moveLookahead();
			
		} else if( lookahead == '/' ) {

			token = T_SOBRE;			
			lexema = "/";
			moveLookahead();

		} else if( lookahead == '+' ) {
			
			token = T_MAIS;
			lexema = "+";
			moveLookahead();

		} else if( lookahead == '-' ) {

			token = T_MENOS;
			lexema = "-";			
			moveLookahead();
			
		} else if( lookahead == '=' ) {
			
			moveLookahead();

			switch( lookahead ) {
			case '=': lexema = "==";
					  token = T_IGUAL;
			          moveLookahead();
					  break;
			default:  lexema = "=";			
					  token = T_ATRIBUICAO;
			}
			
		} else if( lookahead == '!' ) {
			
			moveLookahead();

			switch( lookahead ) {
			case '=': lexema = "!=";
					  token = T_DIFERENTE;
			          moveLookahead();
					  break;
			default:  lexema = "!";			
					  token = T_NEGUE;
			}
			
		} else if( lookahead == '<' ) {
			
			moveLookahead();
			
			switch( lookahead ) {
				case '=': lexema = "<=";
						  token = T_MENOR_IGUAL;
				          moveLookahead();
						  break;
				default:  lexema = "<";			
						  token = T_MENOR;
			}

		} else if( lookahead == '>' ) {
			
			moveLookahead();
			
			switch( lookahead ) {
				case '=': lexema = ">=";
						  token = T_MAIOR_IGUAL;
				          moveLookahead();
						  break;
				default:  lexema = ">";			
						  token = T_MAIOR;
			}

		} else if( lookahead == ':' ) {
			
			lexema = ":";
			token = T_DOIS_PONTOS;
	        moveLookahead();

		} else if( lookahead == '(' ) {

			token = T_ABRE_PAR;
			lexema = "(";			
			moveLookahead();

		} else if( lookahead == '{' ) {

			token = T_ABRE_CHAVE;
			lexema = "{";			
			moveLookahead();

		} else if( lookahead == '[' ) {

			token = T_ABRE_COLCHETES;
			lexema = "[";			
			moveLookahead();

		} else if( lookahead == 13 ) {

			token = T_FIM_COMANDO;			
			lexema = "\n";			
			moveLookahead();
			while( brancosplus.toString().indexOf( lookahead ) >= 0 ) {
				moveLookahead();
			}

		} else if( lookahead == ')' ) {

			token = T_FECHA_PAR;			
			lexema = ")";			
			moveLookahead();

		} else if( lookahead == '}' ) {

			token = T_FECHA_CHAVE;			
			lexema = "}";			
			moveLookahead();

		} else if( lookahead == ']' ) {

			token = T_FECHA_COLCHETES;			
			lexema = "]";			
			moveLookahead();

		} else if( lookahead == ',' ) {

			token = T_VIRGULA;			
			lexema = ",";			
			moveLookahead();

		} else {
			
			if( lookahead == 26 ) {
				lexema = "";
				token = T_FIM_FONTE;
				return false;
			} else {
				StringBuffer sb = new StringBuffer();
				sb.append( lookahead );
			
				token = T_DESCONHECIDO;
				lexema = sb.toString();			

				moveLookahead();
			}
		}
		
		if ( exibe ) {
			exibeMensagemLexico( "Token Identificado: " + getDsToken() + " \t\tLexema correspondente: " + lexema );
		}
		
		return true;
	}

	private boolean isDigit( char chr ) {
		return ( chr >= '0' && chr <= '9' );
	}

	private boolean isAlpha( char chr ) {
		return ( ( chr >= 'A' && chr <= 'Z' ) || ( chr >= 'a' && chr <= 'z' ) || ( chr == '_' ) );
	} 

	private boolean isPonteiro( char chr ) {
		return ( ( chr == '^' ) );
	} 

	public int getColuna() {
		return coluna;
	}

	public String getLexema() {
		return lexema;
	}

	public int getLinha() {
		return linha + 1;
	}

	public int getToken() {
		return token;
	}

	public String getUltimoLexema() {
		return ultimoLexema;
	}

	public int getUltimoToken() {
		return ultimoToken;
	}

	public String getDsToken() {
		
		String result = "TOKEN INDEFINIDO";
		
		switch( token ) {
			case T_LEIA:	 				result = "T_LEIA          "; break;
			case T_ESCREVA:	 				result = "T_ESCREVA       "; break;
			case T_SE:		 				result = "T_SE            "; break;
			case T_ENTAO:	 				result = "T_ENTAO         "; break;
			case T_SENAO:	 				result = "T_SENAO         "; break;
			case T_ENQUANTO:	 			result = "T_ENQUANTO      "; break;
			case T_APAGATELA: 				result = "T_APAGATELA     "; break;
			case T_RETORNE: 				result = "T_RETORNE       "; break;
			case T_PROTOTIPO: 				result = "T_PROTOTIPO     "; break;
			case T_PARA:					result = "T_PARA          "; break;
			case T_REPITA:					result = "T_REPITA        "; break;
			case T_ATE:						result = "T_ATE   		  "; break;
			case T_CASOS:					result = "T_CASOS         "; break;
			case T_CASO:					result = "T_CASO          "; break;
			case T_PARAINTEIRO:				result = "T_PARAINTEIRO   "; break;
			case T_PARACARACTER:			result = "T_PARACARACTER  "; break;
			case T_INTEIRO: 				result = "T_INTEIRO       "; break; 
			case T_CARACTER: 				result = "T_CARACTER      "; break; 
			case T_LOGICO: 					result = "T_LOGICO        "; break; 
			case T_VAZIO: 				    result = "T_VAZIO         "; break; 
			case T_VERDADEIRO:			    result = "T_VERDADEIRO    "; break; 
			case T_FALSO: 				    result = "T_FALSO         "; break; 
			case T_FUNCAO: 				    result = "T_FUNCAO        "; break; 
			case T_ATRIBUICAO: 				result = "T_ATRIBUICAO    "; break; 
			case T_MAIS: 					result = "T_MAIS          "; break;
			case T_MENOS: 					result = "T_MENOS         "; break;
			case T_VEZES: 					result = "T_VEZES         "; break;
			case T_SOBRE: 					result = "T_SOBRE         "; break;
			case T_MAIOR: 					result = "T_MAIOR         "; break;
			case T_MENOR: 					result = "T_MENOR         "; break;
			case T_MAIOR_IGUAL: 			result = "T_MAIOR_IGUAL   "; break;
			case T_MENOR_IGUAL: 			result = "T_MENOR_IGUAL   "; break;
			case T_IGUAL:	 				result = "T_IGUAL         "; break;
			case T_DIFERENTE: 				result = "T_DIFERENTE     "; break;
			case T_CONSTANTE: 				result = "T_CONSTANTE     "; break;
			case T_VIRGULA: 				result = "T_VIRGULA       "; break;
			case T_DOIS_PONTOS: 			result = "T_DOIS_PONTOS   "; break; 
			case T_ABRE_PAR: 				result = "T_ABRE_PAR      "; break;
			case T_FECHA_PAR: 				result = "T_FECHA_PAR     "; break;
			case T_PONTO: 					result = "T_PONTO         "; break;	
			case T_PONTO_VIRGULA: 			result = "T_PONTO_VIRGULA "; break;	
			case T_ABRE_CHAVE: 				result = "T_ABRE_CHAVE    "; break;
			case T_FECHA_CHAVE:				result = "T_FECHA_CHAVE   "; break;
			case T_ABRE_COLCHETES:			result = "T_ABRE_COLCHETES"; break;
			case T_FECHA_COLCHETES:			result = "T_FECHA_COLCHETES"; break;
			case T_TEXTO: 					result = "T_TEXTO         "; break;
			case T_NUMERO_INTEIRO:			result = "T_NUMERO_INTEIRO"; break;
			case T_NUMERO_REAL:				result = "T_NUMERO_REAL   "; break;
			case T_ID:						result = "T_ID            "; break;
			case T_ROTULO:					result = "T_ROTULO        "; break;
			case T_VA:   					result = "T_VA            "; break;
			case T_COMENTARIO:				result = "T_COMENTARIO    "; break;
			case T_FIM_COMANDO:				result = "T_FIM_COMANDO   "; break;
			case T_DESCONHECIDO:			result = "T_DESCONHECIDO  "; break;
			case T_NULO:			        result = "T_NULO          "; break;
			case T_FIM_FONTE:				result = "T_FIM_FONTE     "; break;
			
		}
		return result;
	}

	public boolean isTipoTokenAtual() {
		
		switch ( token ) {
		case T_INTEIRO: 				 
		case T_CARACTER: 				 
		case T_LOGICO:
		case T_CONSTANTE: return true; 
		default: return false;
		}
	}
	
	public boolean isRelacaoTokenAtual() {
		
		switch ( token ) {
		case T_MAIOR: 				 
		case T_MENOR:	 				 
		case T_MAIOR_IGUAL: 				 
		case T_MENOR_IGUAL: return true; 
		default: return false;
		}
	}
	
	public static String getDsTipoDeclarado( int tipo ) {
		switch ( tipo ) {
		case T_INTEIRO: return "T_INTEIRO"; 
		case T_CARACTER: return "T_CARACTER"; 
		case T_LOGICO: return "T_LOGICO"; 
		case T_CONSTANTE: return "T_CONSTANTE"; 
		default: return "T_DESCONHECIDO";
		}
	}
	
	public String getSaidaLexico(){
		return saidaLexico.toString();
	}

	private void exibeMensagemLexico( String mensagem ) {
		
		saidaLexico.append( mensagem );
		saidaLexico.append( "\n" );
		Verto.getInstance().setMensagemLexico( saidaLexico.toString() );
	}

}

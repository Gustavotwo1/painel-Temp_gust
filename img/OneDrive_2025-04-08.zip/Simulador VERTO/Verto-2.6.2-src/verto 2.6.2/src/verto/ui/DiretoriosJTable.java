package verto.ui;
/*
 * $Id: DiretoriosJTable.java,v 1.4 2008/04/08 14:46:39 ricardo Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */


import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import verto.Verto;
import verto.exception.ErroDeCompilacaoException;
import verto.lexico.Lexico;
import verto.semantico.PilhaSemantica;
import verto.semantico.Semantico;
import verto.sintatico.Sintatico;
import verto.utils.Diretorios;

/**
 * Classe: DiretorioJTable
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * 
 * @see Lexico
 * @see Sintatico
 * @see Semantico
 * @see PilhaSemantica
 * @see ErroDeCompilacaoException
 * 
 * @version 2.6.2
 */
public class DiretoriosJTable {
	
	private DiretoriosJTable mySelf;
	
	// Campos da Busca
	private Color 	     corCabecalho;
	private JScrollPane  scroller;

	private JTable 	     tableDiretorio;
	
	private String  prmExtensao;
	private String  prmCaminho; 

	private JTableHeader jth;

	private boolean prmCarregou;
	
    Properties queries = null;

	private String trilha;
	
	public DiretoriosJTable( String trilha, Verto pg ) {
	
		mySelf = this;
		this.trilha = trilha;
		criaBrowse();
	}
	
	private void criaBrowse() {

		JTable tt = (JTable) createTable();
		scroller = new JScrollPane( tt );
		alimentaGrade();
	}
	
	private Component createTable() {

		tableDiretorio = new JTable(new DefaultTableModel(new String[][]{}, new String[] { "Extens�o", "Local do Diretorio" })
				{
				public boolean isCellEditable(int row, int column) {
					return false;
				}
			}
		);

		CellRenderer renderer = new CellRenderer();

		TableColumnModel columnModel = tableDiretorio.getColumnModel();
		for (int i = 0; i < columnModel.getColumnCount(); i++) {
			columnModel.getColumn(i).setCellRenderer(renderer);

		}

		TableColumn column = null;
		for (int i = 0; i < columnModel.getColumnCount(); i++) {
		    column = tableDiretorio.getColumnModel().getColumn(i);
		    switch ( i ) {
		    case 0: column.setPreferredWidth(80);
		    		column.setMinWidth(125);
		    break;
		    case 1: column.setPreferredWidth(500); break;
		    }
		}		
		
		// tableDiretorio.setEnabled( false );
		jth = tableDiretorio.getTableHeader();
 		corCabecalho = new Color( 165, 183, 160 );
		jth.setForeground( Color.BLACK );
		jth.setBackground( corCabecalho );			
		
		// Listener de duplo clique em uma linha
		tableDiretorio.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {

				if (e.getClickCount() >= 1) {
					//Pode ser usado o table.getSelectedRow() para escolher a linha selecionada
					int row = tableDiretorio.rowAtPoint(e.getPoint());
					
					prmExtensao = (String) tableDiretorio.getModel().getValueAt(row, 0);
					prmCaminho  = (String) tableDiretorio.getModel().getValueAt(row, 1);
					Diretorios.getInstance().setExtensao( prmExtensao );
					Diretorios.getInstance().setCaminho( prmCaminho );
				}
			}
		});
		
		tableDiretorio.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				int row = tableDiretorio.getSelectedRow();
				if ( row >= 0 ) {
					prmExtensao = (String) tableDiretorio.getModel().getValueAt(row, 0);
					prmCaminho  = (String) tableDiretorio.getModel().getValueAt(row, 1);
				}
			}
		});
		return tableDiretorio;
	}

	private class CellRenderer extends DefaultTableCellRenderer {

	   	public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
	   		Component comp = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

	   		if ( column >= 10 ) {
		   		((JLabel) comp ).setHorizontalAlignment( JLabel.RIGHT );
            } else {
		   		((JLabel) comp ).setHorizontalAlignment( JLabel.LEFT );
            }
	   		
	   		jth.setBackground( new Color(124, 198, 255) );
	   		
	   		if ( isSelected ) {
		   		if (row % 2 == 0) {
		   			comp.setBackground( new Color(167, 208, 255) );
		   		} else {
		   			comp.setBackground( new Color(167, 208, 255) );
		   		}
	   		} else {
		   		if (row % 2 == 0) {
		   			comp.setBackground( new Color(238, 244, 247) );
		   		} else {
		   			comp.setBackground( new Color(196, 217, 225) );
		   		}
	   		}
	   		return comp;
	   	}
	}	
	
	private void alimentaGrade() {
		
		DefaultTableModel modelo = (DefaultTableModel) tableDiretorio.getModel();
		modelo.addRow(  new String [] { " "," " } );
	}

	public void carregaDiretorios() {

		DefaultTableModel modelo = (DefaultTableModel) tableDiretorio.getModel();

		int qtd = modelo.getRowCount();
		for ( int y=0; y < qtd; y++ ) {
			modelo.removeRow(0);
		}	

	    queries = new Properties();

		try {
			try {
				queries.load(new FileInputStream( trilha ) );
			} catch (FileNotFoundException e) {
				queries.store( new FileOutputStream( trilha ), "criando tabela" );
				queries.load(new FileInputStream( trilha ) );
			}
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog( null, "Diretorios", "Arquivo n�o encontrado!", JOptionPane.ERROR_MESSAGE );
		} catch (IOException e) {
			JOptionPane.showMessageDialog( null, "Diretorios", "Problemas no acesso ao arquivo: Diretorios.txt!", JOptionPane.ERROR_MESSAGE );
		}
		
		Enumeration e = queries.propertyNames();
		
		while ( e.hasMoreElements() ) {
			String extensao = (String) e.nextElement();
			String caminho = queries.getProperty( extensao );
			
			modelo.addRow(  new String [] { extensao, caminho } );
		}
		
	}

	// Gets de Retorno

	public boolean isPrmCarregou() {
		return prmCarregou;
	}

	public String getprmExtensao() {
		return prmExtensao;
	}

	public void setprmExtensao(String prmExtensao) {
		this.prmExtensao = prmExtensao;
	}

	public String getprmCaminho() {
		return prmCaminho;
	}

	public void setprmCaminho(String prmCaminho) {
		this.prmCaminho = prmCaminho;
	}

	public JScrollPane getScroller() {
		return scroller;
	}	
}
package verto.utils;

import verto.Verto;

/** 
 * Classe Exemplos
 * 
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * 
 * @version 2.6.2
 */
public class Exemplos {

	public static void insereSoma() {

		Verto.getInstance().insereSintaxe( "inteiro x, y;\n" );
		Verto.getInstance().insereSintaxe( "\nfuncao inteiro principal() {\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tleia( \"informe o 1 numero: \", x );\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tleia( \"informe o 2 numero: \", y );\n\n" );
		Verto.getInstance().insereSintaxe( "\tx = x + y;\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tescreva( \"Soma = \" );\n\n" );
		Verto.getInstance().insereSintaxe( "\tescreva( 8, x );\n" );
		Verto.getInstance().insereSintaxe( "\n}\n" );
		
		Verto.getInstance().atualizaTextFonte();
		
	}
	
	public static void insereQuadrado() {

		Verto.getInstance().insereSintaxe( "inteiro x;\n" );
		Verto.getInstance().insereSintaxe( "\nfuncao inteiro principal() {\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tleia( \"Numero entre 1 e 10: \", x );\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tcasos {\n" );
		Verto.getInstance().insereSintaxe( "\tcaso x < 1: escreva( \"Numero menor que 1\" );\n" );
		Verto.getInstance().insereSintaxe( "\tcaso x > 10: escreva( \"Numero maior que 10\" );\n" );
		Verto.getInstance().insereSintaxe( "\tsenao: { escreva( \"Quadrado = \" ); escreva( 13, x*x ); }\n" );
		Verto.getInstance().insereSintaxe( "\t}\n\n" );
		Verto.getInstance().insereSintaxe( "\n}\n" );
		
		Verto.getInstance().atualizaTextFonte();
		
	}
	
	public static void insereDivisaoInteira() {

		Verto.getInstance().insereSintaxe( "inteiro x, y, d;\n" );
		Verto.getInstance().insereSintaxe( "\nfuncao inteiro principal() {\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tleia( \"informe o dividendo: \", x );\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tleia( \"informe o divisor: \", y );\n\n" );
		Verto.getInstance().insereSintaxe( "\td = 0;\n" );
		Verto.getInstance().insereSintaxe( "\tenquanto( x >= y ) {\n" );
		Verto.getInstance().insereSintaxe( "\t\tx = x - y;\n" );
		Verto.getInstance().insereSintaxe( "\t\td = d + 1;\n" );
		Verto.getInstance().insereSintaxe( "\t}\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tescreva( \"Resultado = \" );\n" );
		Verto.getInstance().insereSintaxe( "\tescreva( 12, d );\n" );
		Verto.getInstance().insereSintaxe( "\tescreva( 19, \"Resto = \" );\n" );
		Verto.getInstance().insereSintaxe( "\tescreva( 27, x );\n" );
		Verto.getInstance().insereSintaxe( "\n}\n" );
		
		Verto.getInstance().atualizaTextFonte();
		
	}

	
	public static void insereRaizInteira() {

		Verto.getInstance().insereSintaxe( "inteiro i, r, n;\n" );
		Verto.getInstance().insereSintaxe( "\nfuncao inteiro principal() {\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tleia( \"informe o numero: \", n );\n\n" );
		Verto.getInstance().insereSintaxe( "\ti = 1;\n" );
		Verto.getInstance().insereSintaxe( "\tr = 0;\n\n" );
		Verto.getInstance().insereSintaxe( "\tenquanto( n > 0 ) {\n" );
		Verto.getInstance().insereSintaxe( "\t\tn = n - i;\n" );
		Verto.getInstance().insereSintaxe( "\t\ti = i + 2;\n" );
		Verto.getInstance().insereSintaxe( "\t\tr = r + 1;\n" );
		Verto.getInstance().insereSintaxe( "\t}\n\n" );
		Verto.getInstance().insereSintaxe( "\tse ( n < 0 ) entao {\n" );
		Verto.getInstance().insereSintaxe( "\t\tr = 0;\n" );
		Verto.getInstance().insereSintaxe( "\t}\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tescreva( \"Raiz = \" );\n" );
		Verto.getInstance().insereSintaxe( "\tescreva( 8, r );\n" );
		Verto.getInstance().insereSintaxe( "\n}\n" );
		
		Verto.getInstance().atualizaTextFonte();
		
	}	
	
	public static void insereQuadruplo() {

		Verto.getInstance().insereSintaxe( "inteiro n, q;\n" );
		Verto.getInstance().insereSintaxe( "\nprototipo inteiro quadruplo( inteiro x );\n" );
		Verto.getInstance().insereSintaxe( "\nfuncao inteiro principal() {\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tleia( \"informe um numero: \", n );\n\n" );
		Verto.getInstance().insereSintaxe( "\tq = quadruplo( n );\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tescreva( \"Quadruplo = \" );\n" );
		Verto.getInstance().insereSintaxe( "\tescreva( 13, q );\n" );
		Verto.getInstance().insereSintaxe( "\n}\n\nfuncao inteiro quadruplo( inteiro x ) {\n" );
		Verto.getInstance().insereSintaxe( "\tretorne( x * 4 );" );
		Verto.getInstance().insereSintaxe( "\n}\n" );
		
		Verto.getInstance().atualizaTextFonte();
		
	}

	
	public static void insereFatorial() {

		Verto.getInstance().insereSintaxe( "inteiro n, q;\n" );
		Verto.getInstance().insereSintaxe( "\nprototipo inteiro fatorial( inteiro x );\n" );
		Verto.getInstance().insereSintaxe( "\nfuncao inteiro principal() {\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tleia( \"informe um numero: \", n );\n\n" );
		Verto.getInstance().insereSintaxe( "\tq = fatorial( n );\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tse( q > 0 ) entao {\n" );
		Verto.getInstance().insereSintaxe( "\t\tescreva( \"Fatorial = \" );\n" );
		Verto.getInstance().insereSintaxe( "\t\tescreva( 13, q );\n" );
		Verto.getInstance().insereSintaxe( "\t} senao {\n" );
		Verto.getInstance().insereSintaxe( "\t\tescreva( \"Numero nao pode ser negativo\" );\n" );
		Verto.getInstance().insereSintaxe( "\t}\n" );
		Verto.getInstance().insereSintaxe( "\n}\n\nfuncao inteiro fatorial( inteiro x ) {\n\n" );
		Verto.getInstance().insereSintaxe( "\tse( x < 0 ) entao {\n" );
		Verto.getInstance().insereSintaxe( "\t\tretorne( 0 );\n" );
		Verto.getInstance().insereSintaxe( "\t} senao {\n" );
		Verto.getInstance().insereSintaxe( "\t\tse( x <= 1 ) entao {\n" );
		Verto.getInstance().insereSintaxe( "\t\t\tretorne( 1 );\n" );
		Verto.getInstance().insereSintaxe( "\t\t} senao {\n" );
		Verto.getInstance().insereSintaxe( "\t\t\tretorne( x * fatorial( x-1 ) );\n" );
		Verto.getInstance().insereSintaxe( "\t\t}\n" );
		Verto.getInstance().insereSintaxe( "\t}\n" );
		Verto.getInstance().insereSintaxe( "}\n" );
		
		Verto.getInstance().atualizaTextFonte();
		
	}

	public static void insereOrdenaVetor() {
		Verto.getInstance().insereSintaxe( "inteiro vetor[3];\n" );
    	Verto.getInstance().insereSintaxe( "constante inteiro tamanho = 2;\n" );
    	Verto.getInstance().insereSintaxe( "inteiro i,j,troca;\n" );
		Verto.getInstance().insereSintaxe( "\nfuncao inteiro principal() {\n\n" );
		Verto.getInstance().insereSintaxe( "\tApagaTela;\n\n" );
		Verto.getInstance().insereSintaxe( "\tvetor[0] = 2;\n" );
		Verto.getInstance().insereSintaxe( "\tvetor[1] = 0;\n" );
		Verto.getInstance().insereSintaxe( "\tvetor[2] = 1;\n\n" );
		Verto.getInstance().insereSintaxe( "\tpara i = 0 ate tamanho {\n" );
		Verto.getInstance().insereSintaxe( "\t\tpara j=i ate tamanho {\n" );
		Verto.getInstance().insereSintaxe( "\t\t\tse( vetor[i] < vetor[j] ) entao {\n" );
		Verto.getInstance().insereSintaxe( "\t\t\t\ttroca = vetor[i];\n" );
		Verto.getInstance().insereSintaxe( "\t\t\t\tvetor[i] = vetor[j];\n" );
		Verto.getInstance().insereSintaxe( "\t\t\t\tvetor[j] = troca;\n" );
		Verto.getInstance().insereSintaxe( "\t\t\t}\n" );
		Verto.getInstance().insereSintaxe( "\t\t}\n" );
		Verto.getInstance().insereSintaxe( "\t}\n\n" );
		Verto.getInstance().insereSintaxe( "\tpara i = 0 ate tamanho{\n" );
		Verto.getInstance().insereSintaxe( "\t\tescreva (vetor[i] );\n" );
		Verto.getInstance().insereSintaxe( "\t}\n" );
		Verto.getInstance().insereSintaxe( "}\n" );
		
		Verto.getInstance().atualizaTextFonte();
		
	}
	
}


				
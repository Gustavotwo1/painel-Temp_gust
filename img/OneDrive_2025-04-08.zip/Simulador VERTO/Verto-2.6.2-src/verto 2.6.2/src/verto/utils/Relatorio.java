package verto.utils;
/*
 * $Id: Relatorio.java,v 1.5 2008/04/20 19:27:56 ricardo Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */
import java.io.FileOutputStream;
import java.io.StringWriter;
import java.util.Calendar;

/** 
 * Classe Relatorio
 * 
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas 
 * @author Vandersilvio da Silva
 * 
 * @version 2.0
 */
public class Relatorio {
	
	private StringBuilder codigo ;
	
	public void geraArquivo( String diretorio ) {
		try {
			FileOutputStream fosAvisos = null;

			try{
				fosAvisos = new FileOutputStream( diretorio + getNomeArquivo() + "." + getExtensao() );
				
				preencheArquivo( fosAvisos );
				
			} finally {
				if( fosAvisos != null )
					fosAvisos.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println( e.getMessage() );
		}

	}
	
	private void preencheArquivo( FileOutputStream fos ){
		try {
			
			StringWriter text = new StringWriter();
			Calendar c = Calendar.getInstance();
			text.append( " +--------------------------------------------------------------------------------------------------------+\n" );
			text.append( " |  Compilador Verto - vers�o 2.6.2                                                                       |\n" );
			text.append( " |  Listagem da Compila��o para Mneum�nico                                                                |\n" );
			text.append( " +--------------------------------------------------------------------------------------------------------+\n\n\n\n" );
			text.append(getCodigo());
			text.append("\n\n\n");
			text.append( " +--------------------------------------------------------------------------------------------------------+\n" );
			text.append( " |                                                                                                        |\n" );
			text.append( " |                                    "+ c.getTime() +"                                  |\n" );
			text.append( " +--------------------------------------------------------------------------------------------------------+\n\n\n\n" );
			fos.write( text.toString().getBytes() );
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println( e.getMessage() );
		}
	}

	
	public String getNomeArquivo() {
		return "relatorio";
	}

	private String getExtensao(){
		return "txt";
	}

	public StringBuilder getCodigo() {
		return codigo;
	}

	public void setCodigo(StringBuilder codigo) {
		this.codigo = codigo;
	}
}
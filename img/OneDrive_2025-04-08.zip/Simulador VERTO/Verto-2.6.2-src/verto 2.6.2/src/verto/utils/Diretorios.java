package verto.utils;
/*
 * $Id: Diretorios.java,v 1.5 2008/04/18 20:42:46 ricardo Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import verto.Verto;
import verto.exception.ErroDeCompilacaoException;
import verto.lexico.Lexico;
import verto.semantico.PilhaSemantica;
import verto.semantico.Semantico;
import verto.sintatico.Sintatico;
import verto.ui.DiretoriosJTable;


/**
 * Classe: Diretorios
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * 
 * @see Lexico
 * @see Sintatico
 * @see Semantico
 * @see PilhaSemantica
 * @see ErroDeCompilacaoException
 * 
 * @version 2.6.2
 */
public class Diretorios extends JDialog implements ActionListener {

	public static final int INATIVO 						 = 0;
	public static final int CONSULTANDO						 = 1;
	public static final int INCLUINDO						 = 2;
	public static final int EXCLUINDO						 = 3;
	
	private static Diretorios mySelf;
	
	private int estadoDiretorio;
	
	final 	Component 	c = this;
	private File 		fileName;
	
	private JButton btnBusca;
	private JButton btnIncluir;
	private JButton btnExcluir;
	private JButton btnConfirmar;
	private JButton btnCancelar;

	private JTextField edtCaminho;
	private JComboBox cbExtensao;
	
    Properties queries = null;
    private String trilhaDiretorio = null;
    private String diretorioDefault = null;

	public static Properties propriedades = null;
    public static String caminho = null;
    public static File arquivo = null;
    
    private Verto programaPrincipal;
	
	private DiretoriosJTable tabela;
	
	public Diretorios( Verto pg ) {

		super( pg, "Diretorios", true );

		File diretorioHome = new File(System.getProperty("user.home"));
		trilhaDiretorio = diretorioHome.getAbsolutePath() + "/vertoParametros.txt";
		diretorioDefault = diretorioHome.getAbsolutePath();
		
		estadoDiretorio = CONSULTANDO;
		programaPrincipal = pg;
		
		mySelf = this;

		Container container = getContentPane();
		container.setLayout( new BorderLayout() );
		
		container.add( getPainelCentral(), BorderLayout.CENTER );
		container.add( getPainelSul(), BorderLayout.SOUTH );
		
		setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );	
		setDefaultLookAndFeelDecorated( true );
		
		container.setBackground( new Color ( 235, 245, 255 ) ); 
		
		this.setLocation( 100, 50 );
		setSize(700,500); 
		setVisible(true); 
	}

	private JComponent getPainelSul() {
		
		JPanel painelSul = new JPanel( null );
		
		JLabel lblExtensao = new JLabel( "Extens�o" );
		lblExtensao.setBounds( 20, 5, 70, 20 );
		painelSul.add( lblExtensao );
		cbExtensao = new JComboBox( new String[] { "Mneum�nicos", "Assembler Cesar", "Relatorios" } );
		cbExtensao.setBounds( 20, 25, 150, 20 );
		cbExtensao.setName( "cbExtensao" );
	    // edtExtensao.addFocusListener( textoListener );
	    painelSul.add( cbExtensao );
		
		JLabel lblCaminho = new JLabel( "Local do Par�metro" );
		lblCaminho.setBounds( 180, 5, 450, 20 );
		painelSul.add( lblCaminho );
	    edtCaminho = new JTextField();
	    edtCaminho.setBounds( 180, 25, 450, 20 );
	    edtCaminho.setName( "edtCaminho" );
	    // cbExtensao.addFocusListener( textoListener );
	    painelSul.add( edtCaminho );	    
	    
	    btnBusca = new JButton();
	    btnBusca.setBounds( 640, 25, 20, 20 );
	    btnBusca.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/busca.png" ) ) );
	    // btnBusca.setText( "Procurar" );
	    btnBusca.setActionCommand( "Buscar" );
	    btnBusca.addActionListener( this );
		painelSul.add( btnBusca );		

	    btnIncluir = new JButton();
	    btnIncluir.setBounds( 220, 55, 25, 25 );
	    btnIncluir.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/inserir.png" ) ) );
	    btnIncluir.setToolTipText( "Incluir" );
	    btnIncluir.setActionCommand( "Incluir" );
	    btnIncluir.addActionListener( this );
		painelSul.add( btnIncluir );		

	    btnExcluir = new JButton();
	    btnExcluir.setBounds( 250, 55, 25, 25 );
	    btnExcluir.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/excluir.png" ) ) );
	    btnExcluir.setToolTipText( "Excluir" );
	    btnExcluir.setActionCommand( "Excluir" );
	    btnExcluir.addActionListener( this );
		painelSul.add( btnExcluir );		

	    btnConfirmar = new JButton();
	    btnConfirmar.setBounds( 290, 55, 25, 25 );
	    btnConfirmar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/confirmar.png" ) ) );
	    btnConfirmar.setToolTipText( "Confirma" );
	    btnConfirmar.setActionCommand( "Confirmar" );
	    btnConfirmar.addActionListener( this );
		painelSul.add( btnConfirmar );		

	    btnCancelar = new JButton();
	    btnCancelar.setBounds( 320, 55, 25, 25 );
	    btnCancelar.setIcon( new ImageIcon( getClass().getClassLoader().getResource( "imagens/cancelar.png" ) ) );
	    btnCancelar.setToolTipText( "Cancela" );
	    btnCancelar.setActionCommand( "Cancelar" );
	    btnCancelar.addActionListener( this );
		painelSul.add( btnCancelar );		

		habilitaBotoes();

		painelSul.setPreferredSize( new Dimension( 90, 90 ) );
		return painelSul;	
	}


	private Component getPainelCentral() {

	    tabela = new DiretoriosJTable( trilhaDiretorio, programaPrincipal );
		
	    tabela.carregaDiretorios();

	    JComponent panel = tabela.getScroller();
	    panel.setPreferredSize( new Dimension( 800, 350 ) );
	    
		return panel;
	}

	public static void abreTelaDiretorios( Verto pg ) {
		new Diretorios( pg );
	}	
	
	public void actionPerformed(ActionEvent arg0) {

		if ( arg0.getActionCommand().equals( "Incluir" ) ) {
			incluiDiretorio();
		} else if ( arg0.getActionCommand().equals( "Excluir" ) ) {
			excluiDiretorio();
		} else if ( arg0.getActionCommand().equals( "Cancelar" ) ) {
			cancelaOperacao();
		} else if ( arg0.getActionCommand().equals( "Confirmar" ) ) {
			confirmaOperacao();
		} else if ( arg0.getActionCommand().equals( "Buscar" ) ) {
			buscaArquivo();
		} else if( arg0.getActionCommand().equals( "Finalizar" ) ) {
			System.exit( 0 );
		}
	}
	
	private void incluiDiretorio() {

		cbExtensao.setEditable( false );
		estadoDiretorio = INCLUINDO;
		habilitaBotoes();
		limpaCampos();
		cbExtensao.grabFocus();
	}
	
	private void excluiDiretorio() {
		
		boolean confirmaExclusao = 
			JOptionPane.showConfirmDialog( null, "Confirma a exclus�o do elo para este aplicativo " + cbExtensao.getSelectedItem().toString() + "?", "Exclus�o", JOptionPane.YES_OPTION ) == 0 ? true : false;

		if( confirmaExclusao ) {
			estadoDiretorio = EXCLUINDO;
			habilitaBotoes();
			removeDiretorio();
		}
	}	

	private void confirmaOperacao() {

		if ( estadoDiretorio == INCLUINDO ) {
			insereDiretorio();
		}
		estadoDiretorio = CONSULTANDO;
		habilitaBotoes();
	}
	
	private void cancelaOperacao() {

		limpaCampos();
		estadoDiretorio = CONSULTANDO;
		habilitaBotoes();
	}
		
	
	public void habilitaBotoes() {
		
		if ( estadoDiretorio == INCLUINDO ) {
			btnIncluir.setEnabled( false ); 
			btnExcluir.setEnabled( false );
			btnConfirmar.setEnabled( true );
			btnCancelar.setEnabled( true );
			btnBusca.setEnabled( true );
			edtCaminho.setEnabled( true );
			if ( estadoDiretorio == INCLUINDO ) {
				cbExtensao.setEnabled( true );
			} else {
				cbExtensao.setEnabled( false );
			}
		} else {
			btnIncluir.setEnabled( true ); 
			btnExcluir.setEnabled( true );
			btnConfirmar.setEnabled( false );
			btnCancelar.setEnabled( false );
			btnBusca.setEnabled( false );
			cbExtensao.setEnabled( false );
			edtCaminho.setEnabled( false );
		}		
		
	}
	
	public void limpaCampos() {
		
		edtCaminho.setText( "" );
		cbExtensao.setSelectedIndex( 1 );
	}
	
	public static Diretorios getInstance() {
		return mySelf;
	}
	
	public void setCaminho( String caminho ) {
		edtCaminho.setText( caminho );
	}
 
	public void setExtensao( String item ) {
		cbExtensao.setSelectedItem( item );
	}
	
	private void insereDiretorio() {

		queries = new Properties();
		
		try {
			try {
				queries.load(new FileInputStream( trilhaDiretorio ) );
			} catch (FileNotFoundException e) {
				queries.store( new FileOutputStream( trilhaDiretorio ), "criando tabela" );
				queries.load(new FileInputStream( trilhaDiretorio ) );
			}
			
			if ( queries.getProperty( cbExtensao.getSelectedItem().toString() ) != null ) {
				JOptionPane.showMessageDialog( c, "Chave Duplicada!", "Na tabela j� existe esta chave. Procure alterar ent�o ou entrar com uma nova chave!", JOptionPane.WARNING_MESSAGE );
			} else {
				queries.setProperty( cbExtensao.getSelectedItem().toString(), edtCaminho.getText() );
				queries.store(new FileOutputStream( trilhaDiretorio ), "inserido normalmente" );
				tabela.carregaDiretorios();
			}
			
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog( c, "Diretorios", "Arquivo n�o encontrado!", JOptionPane.ERROR_MESSAGE );
		} catch (IOException e) {
			JOptionPane.showMessageDialog( c, "Diretorios", "Problemas no acesso ao arquivo: Diretorios.txt!", JOptionPane.ERROR_MESSAGE );
		}
	}

	private void removeDiretorio() {

		queries = new Properties();
		
		try {
			try {
				queries.load(new FileInputStream( trilhaDiretorio ) );
			} catch (FileNotFoundException e) {
				queries.store( new FileOutputStream( trilhaDiretorio ), "criando tabela" );
				queries.load(new FileInputStream( trilhaDiretorio ) );
			}
			
			if ( queries.getProperty( cbExtensao.getSelectedItem().toString() ) == null ) {
				JOptionPane.showMessageDialog( c, "Chave Inexistente!", "Na tabela n�o existe esta chave!", JOptionPane.WARNING_MESSAGE );
			} else {
				queries.remove( cbExtensao.getSelectedItem() );
				queries.store(new FileOutputStream( trilhaDiretorio ), "removendo normalmente" );
				tabela.carregaDiretorios();
			}
			
		} catch (FileNotFoundException e) {
			JOptionPane.showMessageDialog( c, "Diretorios", "Arquivo n�o encontrado!", JOptionPane.ERROR_MESSAGE );
		} catch (IOException e) {
			JOptionPane.showMessageDialog( c, "Diretorios", "Problemas no acesso ao arquivo: Diretorios.txt!", JOptionPane.ERROR_MESSAGE );
		}
	}

	private void buscaArquivo() {

		JFileChooser fileChooser = new JFileChooser();
		
		fileChooser.setFileSelectionMode( JFileChooser.DIRECTORIES_ONLY );
		
		int result = fileChooser.showOpenDialog( c );
		
		if( result == JFileChooser.CANCEL_OPTION ) {
			return;
		}
		
		fileName = fileChooser.getSelectedFile();
		
		if ( fileName != null ) {
			edtCaminho.setText( fileName.getAbsolutePath() );
		}
	}
	
	
}
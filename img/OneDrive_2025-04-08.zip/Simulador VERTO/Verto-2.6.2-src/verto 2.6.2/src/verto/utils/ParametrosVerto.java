package verto.utils;
/*
 * $Id: ParametrosVerto.java,v 1.2 2008/04/07 17:36:50 mariana Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Vector;

/**
 * Classe ParametrosVerto: Manipula as op��es do Verto e faz a persistencia em disco
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 *
 * @see Parametros
 * 
 * @version 2.6.2
 *
 */
public class ParametrosVerto {

	private Parametros parametros;
	
	/**
	 * Numero maximo de arquivos listados
	 */
	private static final int NUM_ARQ_LISTA = 4;

	/**
	 * Nome do arquivo de parametros
	 */
	private static final String NOME_ARQ = "parametrosVerto.txt";

	public ParametrosVerto(Parametros parametros) {
		this.parametros = parametros;
	}

	public ParametrosVerto() {
		this.parametros = new Parametros();
	}

	public void carregaParametros() throws IOException, ClassNotFoundException {
		
        FileInputStream fis = new FileInputStream(NOME_ARQ);
        ObjectInputStream ois = new ObjectInputStream(fis);		

        parametros = (Parametros) ois.readObject();
        ois.close();
	}
	
	public void salvaParametros() throws IOException {
	    FileOutputStream fos = new FileOutputStream(NOME_ARQ);
        ObjectOutputStream oos = new ObjectOutputStream(fos);

        oos.writeObject(this.parametros);
        oos.flush();
        oos.close();
    }

	/**
	 * Mant�m a lista com no m�ximo NUM_ARQ_LISTA itens:
	 */
	public void adicionaArquivo(String nome) {
		if( parametros.listaArquivos.size() >= NUM_ARQ_LISTA ) {
			parametros.listaArquivos.remove(0);
		}
		parametros.listaArquivos.add(nome);
	}
	
	public String getAparencia() {
		return parametros.aparencia;
	}

	public void setAparencia(String aparencia) {
		this.parametros.aparencia = aparencia;
	}

	public Vector getListaArquivos() {
		return parametros.listaArquivos;
	}

	public void setListaArquivos(Vector listaArquivos) {
		this.parametros.listaArquivos = listaArquivos;
	}

	public boolean isUsaCores() {
		return parametros.usaCores;
	}

	public void setUsaCores(boolean usaCores) {
		this.parametros.usaCores = usaCores;
	}

	public boolean isComentaFonte() {
		return parametros.comentaFonte;
	}

	public void setComentaFonte( boolean comentaFonte ) {
		this.parametros.comentaFonte = comentaFonte;
	}
	
}

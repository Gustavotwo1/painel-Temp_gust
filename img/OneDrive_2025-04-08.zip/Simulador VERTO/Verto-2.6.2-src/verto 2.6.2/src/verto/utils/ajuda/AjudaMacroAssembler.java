package verto.utils.ajuda;
/*
 * $Id: AjudaMacroAssembler.java,v 1.6 2008/04/24 12:01:25 ricardo Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.BorderFactory;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.text.BadLocationException;

/**
 * Classe: AjudaMacroAssembler
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 *  
 * @version 2.6.2
 */
public class AjudaMacroAssembler extends JFrame {

	private static final long serialVersionUID = 7204110966094688955L;
	
	private JPanel painelAjuda;
	private JLabel lblTitulo;
	private JEditorPane textoAjuda;
	private JScrollPane scpAjuda;
	
	public AjudaMacroAssembler() {
	
		super( "Ajuda do Verto 2.6.2 - Macro Assembler" );
		
		StringBuilder sbTitulo = new StringBuilder();
		StringBuilder sbAjuda  = new StringBuilder();
		
		setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );	
		setDefaultLookAndFeelDecorated( true );
		
		sbTitulo.append( "<html>" );
		sbTitulo.append( "<font color=blue size=+2>Ajuda do Verto 2.6.2 - Macro Assembler</font>" );
		sbTitulo.append( "</html>" );
		
		lblTitulo = new JLabel( sbTitulo.toString() ); 
		
		lblTitulo.setBorder( BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(""),
                BorderFactory.createEmptyBorder(5,10,10,10)) );
		
		sbAjuda.append( "<html>" );
		sbAjuda.append( "<body bgcolor=\"#D6D9DF\">" );
		sbAjuda.append( "<font color=green size=+1>1 - Descri��o do Macro Assembler</font>" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "O Macro-Assembler do Verto � uma linguagem que se aproxima muito do<br>" );
		sbAjuda.append( "assembler da linguagem Cesar. Cont�m alguns mneum�nicos desenvolvidos<br>" );
		sbAjuda.append( "para tornar f�cil ao aluno acompanhar os c�digos gerados, como r�tulos<br>" );
		sbAjuda.append( "e desvios, opera��es de pilha como push e pop, chamadas de rotinas j�<br>" );
		sbAjuda.append( "montadas de v�deo, etc.<br>" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<font color=green size=+1>2 - Modos de Endere�amento</font>" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "Os modos de endere�amento do Verto s�o:<br />" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<table border=1 bordercolorlight = ffffff bordercolordark = ff00CC>" );

		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td width=100>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "n" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td width=600>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "O valor n" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "[n]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "O conte�do da posi��o de mem�ria endere�ada por n" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );

		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "rx" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "O conte�do do registrador r(x)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );

		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "[rx]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "O conte�do da posi��o de mem�ria endere�ada por r(x)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );

		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "[rx+n]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "O conte�do da posi��o de mem�ria endere�ada por r(x)+n" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );

		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "label" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "O valor do endere�o de Label" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );

		sbAjuda.append( "</table>" );
		
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<font color=green size=+1>3 - Registradores</<font>" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "A utiliza��o dos registradores no Verto se d� como na tabela:<br />" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<table border=1 bordercolorlight = ffffff bordercolordark = ff00CC>" );

		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td width=100>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "R0" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td width=300>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "Operando 1" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "R1" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "Operando 2" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "R2" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "Ponteiro Operando 1" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "R3" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "Ponteiro Operando 2" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "R4" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "-" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "R5" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "Base Pointer" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "R6" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "Stack Pointer" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "R7" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "Program Counter" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );

		sbAjuda.append( "</table>" );
		

		// Samuel come�a aqui
		
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<font color=green size=+1>4 - A Pilha</<font>" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "A pilha do Verto come�a na posi��o 65400. Exemplos de opera��o s�o:<br />" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<table border=1 bordercolorlight = ffffff bordercolordark = ff00CC>" );

		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td width=100>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "push v" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td width=180>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov (r7)+,-(r6)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td width=420>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "joga o valor v para a pilha" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );

		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "push rx" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov rx,-(r6)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "joga o registrador r(x) na pilha" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "push [n]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov ((r7)+),-(r6)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "joga o valor da posi��o n de mem�ria<br />para a pilha" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "push [rx]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov (rx),-(r6)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "joga o valor apontado pelo registrador<br />r(x) na pilha" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );

		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "push [rx+n]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov n(rx),-(r6)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "joga o valor apontado pelo registrador<br />r(x) indexado por n na pilha" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "pop  rx" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov (r6)+,rx" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "joga o valor da pilha para o registrador<br />r(x)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "pop  [n]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov (r6)+,((r7)+)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "joga o valor da pilha para a posi��o de<br />em�ria n" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "pop  [rx]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov (r6)+,((r7)+)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "joga o valor da pilha para o endere�o<br />pontado pelo registrador r(x)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "pop  [rx+n]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov (r6)+,n(rx)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "joga o valor da pilha para o endere�o<br />apontado pelo registrador r(x)<br />indexado por n" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "</table>" );
		
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<font color=green size=+1>5 - Utiliza��o dos Registradores</<font>" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "A utiliza��o dos registradores no Verto se d� como na tabela:<br />" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<table border=1 bordercolorlight = ffffff bordercolordark = ff00CC>" );

		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td width=100>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov v,rx" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td width=180>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov (r7)+,rx" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td width=420>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "move o valor v para o registrador<br />r(x)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov v,[n]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov (r7)+,((r7)+)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "move o valor v para a posi��o de<br />mem�ria n" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov v,[rx]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov (r7)+,(rx)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "move o valor v para o endere�o<br />apontado pelo registrador r(x)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov v,[rx+n]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov (r7)+,n(rx)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "move o valor v para o endere�o<br />apontado pelo registrador r(x) indexado<br /> por n" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov rx,ry" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov rx,ry" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "move o conteudo de r(x) para o<br />registrador r(y)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov rx,[n]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov rx,((r7)+)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "move o conteudo de r(x) para o endere�o<br />de mem�ria n" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );

		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov rx,[rx]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov rx,(rx)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "move o conteudo de r(x) para o endere�o<br />apontado pelo registrador r(x)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "<tr>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov rx,[rx+n]" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=blue size=+1>" );
		sbAjuda.append( "mov rx,n(rx)" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "<td>" );
		sbAjuda.append( "<font color=red size=+1>" );
		sbAjuda.append( "move o conteudo de r(x) para o endere�o<br />apontado pelo registrador r(x) indexado<br />por n" );
		sbAjuda.append( "</font>" );
		sbAjuda.append( "</td>" );
		sbAjuda.append( "</tr>" );
		
		sbAjuda.append( "</table>" );
		
		
		// Samuel termina aqui
		
		sbAjuda.append( "<br />" );
		sbAjuda.append( "<br />" );
		sbAjuda.append( "</html>" );
		
		textoAjuda = new JEditorPane();
		textoAjuda.setBorder(BorderFactory.createEmptyBorder());
		textoAjuda.setContentType("text/html");
		textoAjuda.setText(sbAjuda.toString());
		textoAjuda.setEditable(false);
		final WordSearcher searcher = new WordSearcher(textoAjuda);
		textoAjuda.addKeyListener(new KeyAdapter(){
			@Override
			public void keyReleased(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_F){
					String palavra  = JOptionPane.showInputDialog("Palavra desejada:");
					if(palavra !=null && palavra.length()>0){
						
			        int offset = searcher.search(palavra.trim());
			        if (offset != -1) {
			          try {
			        	  textoAjuda.scrollRectToVisible(textoAjuda
			                .modelToView(offset));
			          } catch (BadLocationException x) {
			          }
			        }
					}
				}
				
			}
		});
		
		scpAjuda = new JScrollPane(textoAjuda, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,  
				ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);  
		
		scpAjuda.setBorder( BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Ajuda Verto"),
                BorderFactory.createEmptyBorder(0,10,0,0)) );

		Container container = getContentPane();
		
		painelAjuda = new JPanel();
		
		painelAjuda.setLayout( new BorderLayout() );
		painelAjuda.add( lblTitulo, BorderLayout.NORTH );
		painelAjuda.add( scpAjuda, BorderLayout.CENTER );
		painelAjuda.setBorder( BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(),
                BorderFactory.createEmptyBorder(5,10,10,10) ) );
		
		container.add( painelAjuda );

		Image icone = Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource( "imagens/VertoIcone.png" )); 
		setIconImage(icone); 
		
		this.setLocation( 100, 50 );
		setSize(840,600);
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				textoAjuda.scrollRectToVisible(new Rectangle(0,0));
			}
		});
		setVisible(true);
	}	
}
package verto;
/*
 * $Id: Verto.java,v 1.23 2008/04/24 12:01:24 ricardo Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2010 Lucas Eskeff Freitas
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */



import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.JPopupMenu.Separator;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.CompoundBorder;
import javax.swing.event.MouseInputListener;
import javax.swing.table.JTableHeader;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.Highlighter;

import verto.exception.ErroDeCompilacaoException;
import verto.exception.ErroLexicoException;
import verto.exception.ErroSemanticoException;
import verto.exception.ErroSintaticoException;
import verto.lexico.Lexico;
import verto.semantico.PilhaSemantica;
import verto.semantico.Semantico;
import verto.sintatico.Sintatico;
import verto.ui.Cor;
import verto.ui.Cores;
import verto.ui.LineNumberedBorder;
import verto.ui.LookandFeelSuportados;
import verto.ui.SplashWindow;
import verto.ui.TelaSplash;
import verto.utils.Diretorios;
import verto.utils.Exemplos;
import verto.utils.LicencaGnu;
import verto.utils.LicencaNuvola;
import verto.utils.ParametrosVerto;
import verto.utils.Relatorio;
import verto.utils.TeclaListener;
import verto.utils.ajuda.AjudaMacroAssembler;
import verto.utils.ajuda.AjudaVerto;

/** 
 * Classe Principal: Compilador Verto
 * 
 * Este compilador, traduz um c�digo-fonte na linguagem Verto, um subconjunto da
 * linguagem C para a linguagem da M�quina Cesar, criada pelo professor do
 * Instituto de Inform�tica da UFRGS, Raul Weber.
 * 
 * Verto � um voc�bulo do latim que significa: interpretar
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * @author Vandersilvio da Silva
 * 
 * @see Lexico
 * @see Sintatico
 * @see Semantico
 * @see PilhaSemantica
 * @see ErroDeCompilacaoException
 * 
 * @version 2.6.2
 */


// TODO o que � classe vira escopo
//      cria classe contendo vetor, constante ou nada

public class Verto extends JFrame implements ActionListener {
	Action  selectLine;
	private static final long serialVersionUID = 1L;
	final 	Component 		c = this;
	private JTextArea 		textStatus;
	private JTextArea 		textLexico;
	private JTextArea 		textSintatico;
	private JTextArea 		textSemantico;
	private JTextArea 		textPilhaSemantica;
	private JTable 			tableTabelaSimbolos;
	private JTextArea 		textFonte;
	private JTextArea 		textEditor;
	private JTextArea 		textMacroAssembler;
	private JTextArea 		textRotinas;
	private JLabel    		htmlFonte;
	private JPanel    		htmlPanel;
	private JProgressBar 	barraProgresso;
	private JTabbedPane 	pastasFontes;
	private JTabbedPane 	pastasMensagens;
	private JMenu 			menuArquivo;
	private JPopupMenu     	popup;
	JMenu sintaxe = new JMenu("Aux�lio Sintaxe");
    private JCheckBoxMenuItem cbDestacaPalavras;
    private JCheckBoxMenuItem cbMostrarLinhas;
    private ButtonGroup bg = new ButtonGroup();
	private int 		linhaErro;
	private String look;
	private File 		fileName;
	
	private int 		linhaAtual = 1;
	private String 		linhas = "";
	private StringBuffer mensagensStatus;
	private Sintatico 	sin;
	
	private String 		ultimaAcaoSintatica;
	private String 		ultimaAcaoSemantica;
	
	private ParametrosVerto parametrosVerto;
	
//	AparenciaListener aparenciaListener = new AparenciaListener( this );
	EditorListener editorListener = new EditorListener();
	FonteListener fonteListener = new FonteListener();
	MouseInputListener fonteMouseListener = new FonteMouseListener();
	WindowListener janelaListner = new JanelaListner();
	
    private static String trilhaDiretorio = null;
//	private Properties parametros;
	private String diretorioParaAssembler = null;
	private String diretorioParaMneumonico = null;
	private String diretorioParaRelatorio = null;
	private static String TITULO = "Compilador Educativo Verto 2.6.2 - "; 
	FiltroVerto filtro = new FiltroVerto();
	private static DecimalFormat formatadorLinha = new DecimalFormat( "0000" );
	private static CompoundBorder LINE_BORDER= BorderFactory.createCompoundBorder(
			new LineNumberedBorder(LineNumberedBorder.LEFT_SIDE,LineNumberedBorder.LEFT_JUSTIFY),
            javax.swing.BorderFactory.createMatteBorder(0, 1, 0, 0, Color.LIGHT_GRAY)
            );
	private Clipboard clipBoard;
	
	private static Verto mySelf;
	
	@SuppressWarnings("unchecked")
	public Verto() {

		
		super( TITULO );
		
		Image icone = Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource( "imagens/VertoIcone.png" )); 
		setIconImage(icone); 
	
		mySelf = this;

		File diretorioHome = new File(System.getProperty("user.home"));
		trilhaDiretorio = diretorioHome.getAbsolutePath() + File.separatorChar + "vertoParametros.txt";
	//	parametros = new Properties();
		
		parametrosVerto = new ParametrosVerto();

		/**
		 * Tenta carregar parametros do disco;
		 * Se nao encontrar o arquivo, tenta
		 * criar um novo.
		 */
		try {
			parametrosVerto.carregaParametros();
		} catch (IOException e) {
			try {
				parametrosVerto.salvaParametros();
			} catch (IOException e1) {
				// N�o consegui criar um arquivo novo
				// TODO colocar mensagem de erro
				e1.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// N�o ache a classe Parametros
			// TODO colocar mensagem de erro
			e.printStackTrace();
		}

		diretorioParaRelatorio = buscaDiretorioRelatorio() + File.separatorChar;
		diretorioParaAssembler = buscaDiretorioAssemblerCesar() + File.separatorChar;
		diretorioParaMneumonico = buscaDiretorioMneumonico() + File.separatorChar;
		
		setJMenuBar( getMenuVerto() );

		mensagensStatus = new StringBuffer();
		
		Container container = getContentPane();
		container.setLayout( new BorderLayout() );
		
		this.addWindowListener( janelaListner );
		
		container.add( getPainelTopo(), BorderLayout.NORTH );
		pastasFontes = (JTabbedPane) getPainelCentral();
		container.add( pastasFontes, BorderLayout.CENTER );
		container.add( getPainelSul(), BorderLayout.SOUTH );
		
		setSize( 800, 600 );
		
		//aparenciaListener.setEstilo(true);
		setDefaultLookAndFeelDecorated( true );
		
		// SplashScreen
		Cor.carregaCores();
		setaCoresUIManager();
		inicializaPopup();
		inicializaListeners();
		setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
		selecionaLookAndDefault();
		//Abre ultimo arquivo salvo
		Vector<String> vt = parametrosVerto.getListaArquivos();
		if(vt!=null && vt.size()>0){
			String caminho =vt.get(vt.size() - 1);
			fileName = new File(caminho);
			if(abreArquivo(fileName)){
				setTitle(TITULO+caminho);
			};
			
		}
		selectLine = getAction(DefaultEditorKit.selectLineAction);
	}
	
	
	public void copiar (){
		  clipBoard = getToolkit().getSystemClipboard();
		  StringSelection ss = new StringSelection(textEditor.getSelectedText());
		  clipBoard.setContents(ss,ss);
		 }
		 
	private void colar() {
		  clipBoard = getToolkit().getSystemClipboard();
		  Transferable t = clipBoard.getContents(new Object());
		   try {
		    String texto = (String)t.getTransferData(DataFlavor.stringFlavor);
		    textEditor.replaceSelection(texto);
		    
		   }
		   catch (UnsupportedFlavorException ex) {
		    ex.printStackTrace();
		   }catch (IOException ex) {
		    ex.printStackTrace();
		   }
		 }
	
	private void inicializaPopup(){
		popup = new JPopupMenu();
		popup.add(sintaxe);
		popup.addSeparator();
		popup.add(criaItemMenu("Copiar", "Copiar"));
		popup.add(criaItemMenu("Colar", "Colar"));
	}
	
	
	private void inicializaListeners(){
		textEditor.addMouseListener(new MouseAdapter(){
			   public void mousePressed(MouseEvent e) {  
			         maybeShowPopup(e);  
			}  
			   
			     public void mouseReleased(MouseEvent e) {  
			        maybeShowPopup(e);  
			     }  
			   
			     private void maybeShowPopup(MouseEvent e) {  
			        if (e.isPopupTrigger()) {
			        	SwingUtilities.updateComponentTreeUI(popup);
			        	int index =popup.getComponentIndex(sintaxe);
			        	 if(index<0){
			        		 popup.add(sintaxe,0);
			        		 popup.add(new JPopupMenu.Separator(), 1);
			        	 }
			             popup.show(e.getComponent(),  
			                        e.getX(), e.getY());  
			         }  
			     }  
		});
		
		textMacroAssembler.addMouseListener(new MouseAdapter(){
			   public void mousePressed(MouseEvent e) {  
			         maybeShowPopup(e);  
			   }  
			   
			     public void mouseReleased(MouseEvent e) {  
			        maybeShowPopup(e);  
			     }  
			   
			     private void maybeShowPopup(MouseEvent e) {  
			        if (e.isPopupTrigger()) {
			        	SwingUtilities.updateComponentTreeUI(popup);
			        	int index =popup.getComponentIndex(sintaxe);
			        	 if(index>=0){
			        		 popup.remove(index);
			        		 popup.remove(index);
			        	 }
			             
			        	 popup.show(e.getComponent(),  
			                        e.getX(), e.getY());  
			         }  
			     }  
		});
		
		
	}
	
	private void selecionaLookAndDefault(){
	    //Parametro  verto aparencia
	    String lookSalvo = parametrosVerto.getAparencia();
	    if(lookSalvo!=null && lookSalvo.length()>0){
	    	look = lookSalvo;
	    }
	    	Enumeration<AbstractButton> i = bg.getElements();
	    	while(i.hasMoreElements()){
	    		JRadioButtonMenuItem menu = (JRadioButtonMenuItem) i.nextElement();
	    		if(look!=null){
	    			if(menu.getName().equals(look)){
	    				menu.setSelected(true);
	    				final String lookFinal = look;
						selecionaLookAndFeel(lookFinal);
	    			}else{
	    				if(UIManager.getLookAndFeel().getID().equals(menu.getName())){
		    				menu.setSelected(true);
		    			}	
	    			}
	    		}else{
	    			if(UIManager.getLookAndFeel().getID().equals(menu.getName())){
	    				menu.setSelected(true);
	    			}
	    		}
	    	}
	}
	
	
	private JMenuBar getMenuVerto() {

	    JMenuBar menubar = new JMenuBar();
	    menuArquivo = new JMenu("Arquivo");

	    carregaMenuArquivo( menubar );
	    
	    JMenu compilar = new JMenu("Compilar");
	    JMenu configuracoes = new JMenu("Configuracao");
	    JMenu tipos = new JMenu("Aux�lio Tipos");
	    JMenu aparencia = new JMenu("Apar�ncia");
	    JMenu ajuda = new JMenu("Ajuda");
	    JMenu rotinas = new JMenu("Aux�lio Rotinas");
	    JMenu exemplosProgramas = new JMenu("Exemplos de Programas");
	    
	    sintaxe.setIcon( new ImageIcon(getClass().getClassLoader()
				.getResource("imagens/auxilioSintaxeG.png")) );

	    rotinas.setIcon( new ImageIcon(getClass().getClassLoader()
				.getResource("imagens/auxilioRotinasG.png")) );

	    exemplosProgramas.setIcon( new ImageIcon(getClass().getClassLoader()
				.getResource("imagens/exemplosProgramasG.png")) );

	    
	    
	    menubar.add(compilar);
	    menubar.add(configuracoes);
	    menubar.add(aparencia);
	    menubar.add(ajuda);
	    
	    compilar.add( criaItemMenuTeclaChave( "Compilar", "Compilar",'K', new ImageIcon( getClass().getClassLoader().getResource( "imagens/compilarG.png" ) ) ) );
	    compilar.insertSeparator(1);
	    compilar.add(criaItemMenuTeclaChave("Emitir Listagem de Compila��o",
				"Relatorio", 'R', new ImageIcon(getClass().getClassLoader()
						.getResource("imagens/impressaoG.png"))));
	    
	    configuracoes.add(criaItemMenuTeclaChave("Cores",
				"TelaCores", 'P', new ImageIcon(getClass().getClassLoader()
						.getResource("imagens/coresG.png"))));
	    configuracoes.insertSeparator(3);
	    configuracoes.add(criaItemMenuTeclaChave("Diret�rios Default",
				"Diretorios", 'D', new ImageIcon(getClass().getClassLoader()
						.getResource("imagens/diretorios.png"))));
	    
	    UIManager.LookAndFeelInfo[] looks =    
			UIManager.getInstalledLookAndFeels();   
	    
	    for (LookAndFeelInfo lookAndFeelInfo : looks) {
	    	JRadioButtonMenuItem rb =criaVertoItemMenu(lookAndFeelInfo.getName(), "SelecionaLook");
	    	rb.setName(lookAndFeelInfo.getClassName());
			aparencia.add(rb);
			bg.add(rb);
			if ("Nimbus".equals(lookAndFeelInfo.getName())) {
				look = rb.getName();
			}else if("GTK+".contains(lookAndFeelInfo.getName())){
				look = rb.getName();
			}
		}
	    
	    
//	    JCheckBoxMenuItem cbMotif   = criaVertoItemMenu( "Motif", "Motif" ); 
//	    JCheckBoxMenuItem cbMetal   = criaVertoItemMenu( "Metal", "Metal" ); 
//	    JCheckBoxMenuItem cbWindows = criaVertoItemMenu( "Windows", "Windows" ); 
//		JCheckBoxMenuItem cbWindowsClassic = criaVertoItemMenu(	"Windows Classic", "WindowsClassic");
//		JCheckBoxMenuItem cbGTK = criaVertoItemMenu( "GTK+", "GTK" );
//		JCheckBoxMenuItem cbMac = criaVertoItemMenu( "Mac", "Mac" );
//		JCheckBoxMenuItem cbNimbus = criaVertoItemMenu( "Nimbus", "Nimbus" );
//
//	    aparenciaListener.setMnMotif( cbMotif );
//	    aparenciaListener.setMnMetal( cbMetal );
//	    aparenciaListener.setMnWindows( cbWindows );
//		aparenciaListener.setMnWindowsClassic(cbWindowsClassic);
//		aparenciaListener.setMnGTK(cbGTK);
//		aparenciaListener.setMnMac(cbMac);
//		aparenciaListener.setMnNimbus(cbNimbus);
//
//	    aparencia.add( cbMotif );
//	    aparencia.add( cbMetal );
//	    aparencia.add( cbWindows );
//		aparencia.add( cbWindowsClassic );
//		aparencia.add( cbGTK );
//		aparencia.add( cbMac );
//		aparencia.add( cbNimbus );
		aparencia.insertSeparator(looks.length);
		
		
		
		aparencia.add(criaItemMenuTeclaChave("Look and Feels Suportados",
				"LFSuportados", 'O', new ImageIcon(getClass().getClassLoader().getResource("imagens/looknfeelsuportados.png"))));
		aparencia.insertSeparator(9);
	    cbDestacaPalavras = criaOpcoesItemMenu( "Destaca Palavras", "DestacaPalavras" );
	    cbDestacaPalavras.setSelected( false );
	    aparencia.add( cbDestacaPalavras );

	    cbMostrarLinhas= criaOpcoesItemMenu( "Mostrar n�mero de linhas", "NumeroLinha" );
	    aparencia.add( cbMostrarLinhas );
	    cbMostrarLinhas.setSelected( true );		
	    
//   	cbMotif.setSelected( parametrosVerto.getAparencia() == AparenciaListener.ESTILO_MOTIF );
//		cbMetal.setSelected( parametrosVerto.getAparencia() == AparenciaListener.ESTILO_METAL );
//		cbWindows.setSelected( parametrosVerto.getAparencia() == AparenciaListener.ESTILO_WINDOWS );
//		cbWindowsClassic.setSelected( parametrosVerto.getAparencia() == AparenciaListener.ESTILO_WINDOWS_CLASSIC );
//		cbGTK.setSelected( parametrosVerto.getAparencia() == AparenciaListener.ESTILO_GTK );
//		cbMac.setSelected( parametrosVerto.getAparencia() == AparenciaListener.ESTILO_MAC );
//		cbNimbus.setSelected( parametrosVerto.getAparencia() == AparenciaListener.ESTILO_NIMBUS );
	    
	    tipos.add( criaItemMenu( "Inteiro", "Inteiro" ) ); 
	    tipos.add( criaItemMenu( "Caracter", "Caracter" ) ); 
	    tipos.add( criaItemMenu( "Booleano(Logico)", "Logico" ) ); 
	    tipos.add( criaItemMenu( "Constante Inteiro", "Constante Inteiro" ) ); 
	    tipos.add( criaItemMenu( "Constante Caracter", "Constante Caracter" ) ); 
	    tipos.add( criaItemMenu( "Constante Booleano(Logico)", "Constante Logico" ) ); 
	    
	    rotinas.add( criaItemMenu( "Indice de Rotinas", "Indice" ) );
	    rotinas.add( criaItemMenu( "Divis�o Inteira", "IDiv" ) );
	    rotinas.add( criaItemMenu( "Multiplica��o Inteira", "IMul" ) );
	    rotinas.add( criaItemMenu( "Ascii->Integer", "AToI" ) );
	    rotinas.add( criaItemMenu( "Integer->Ascii", "IToA" ) );
	    rotinas.add( criaItemMenu( "Rotinas de Leituras", "Leituras" ) );
	    rotinas.add( criaItemMenu( "Rotinas de String", "MemLib" ) );
	    rotinas.add( criaItemMenu( "Rotinas de Visor", "VisorLib" ) );
	    
	    sintaxe.add( criaItemMenu( "Programa Verto", "CorpoPrograma" ) );
	    sintaxe.add( criaItemMenu( "Fun��o", "Funcao" ) );
	    sintaxe.add( criaItemMenu( "Atribui��o", "Atribuicao" ) );
	    sintaxe.add( criaItemMenu( "Sele��o", "Selecao" ) );
	    sintaxe.add( criaItemMenu( "Sele��o n-direcional", "Caso" ) );
	    sintaxe.add( criaItemMenu( "La�o Enquanto", "Enquanto" ) );
	    sintaxe.add( criaItemMenu( "La�o Para", "Para" ) );
	    sintaxe.add( criaItemMenu( "La�o Repita-Ate", "RepitaAte" ) );
	    sintaxe.add( criaItemMenu( "La�o Repita-Enquanto", "RepitaEnquanto" ) );
	    sintaxe.add( criaItemMenu( "Apaga Tela", "ApagaTela" ) );
	    sintaxe.add( criaItemMenu( "Escrita", "Escrita" ) );
	    sintaxe.add( criaItemMenu( "Leitura", "Leitura" ) );
	    sintaxe.add( criaItemMenu( "ParaInteiro", "ParaInteiro" ) );
	    sintaxe.add( criaItemMenu( "ParaCaracter", "ParaCaracter" ) );
	    sintaxe.add( tipos );

	    exemplosProgramas.add( criaItemMenu( "Soma Simples", "SomaSimples", new ImageIcon( getClass().getClassLoader().getResource( "imagens/somaG.png" ) ) ) );
	    exemplosProgramas.add( criaItemMenu( "Quadrado", "Quadrado", new ImageIcon( getClass().getClassLoader().getResource( "imagens/quadradoG.png" ) ) ) );
	    exemplosProgramas.add( criaItemMenu( "Divis�o Inteira", "DivisaoInteira", new ImageIcon( getClass().getClassLoader().getResource( "imagens/divisaoInteiraG.png" ) ) ) );
	    exemplosProgramas.add( criaItemMenu( "Raiz Quadrada Inteira", "RaizInteira", new ImageIcon( getClass().getClassLoader().getResource( "imagens/raizInteiraG.png" ) ) ) );
	    exemplosProgramas.add( criaItemMenu( "Quadruplo de um Numero", "Quadruplo", new ImageIcon( getClass().getClassLoader().getResource( "imagens/quadruploG.png" ) ) ) );
	    exemplosProgramas.add( criaItemMenu( "Fatorial de um Numero", "Fatorial", new ImageIcon( getClass().getClassLoader().getResource( "imagens/fatorialG.png" ) ) ) );
	    exemplosProgramas.add( criaItemMenu( "Ordena��o de vetor", "OrdenaVetor", new ImageIcon( getClass().getClassLoader().getResource( "imagens/vetor.png" ) ) ) );
	    
	    ajuda.add( criaItemMenuTeclaChave( "Ajuda Verto", "Ajuda",'A', new ImageIcon( getClass().getClassLoader().getResource( "imagens/ajudaG.png" ) ) ) );
	    ajuda.add( criaItemMenuTeclaChave( "Ajuda Macro Assembler", "AjudaMacro",'M', new ImageIcon( getClass().getClassLoader().getResource( "imagens/ajudaMacroG.png" ) ) ) );
        ajuda.insertSeparator(2);
        ajuda.add( rotinas );
        ajuda.add( sintaxe );
        ajuda.insertSeparator(6);
        ajuda.add( exemplosProgramas );
        ajuda.insertSeparator(8);
	    ajuda.add( criaItemMenuTeclaChave( "Sobre Cesar", "SobreCesar",'S', new ImageIcon( getClass().getClassLoader().getResource( "imagens/scesarG.png" ) ) ) );
	    ajuda.add( criaItemMenuTeclaChave( "Sobre Verto", "SobreVerto",'V', new ImageIcon( getClass().getClassLoader().getResource( "imagens/svertoG.png" ) ) ) );
        ajuda.insertSeparator(11);
	    ajuda.add( criaItemMenuTeclaChave( "Tela Splash", "Splash",'H', new ImageIcon( getClass().getClassLoader().getResource( "imagens/telaSplashG.png" ) ) ) );
        ajuda.insertSeparator(13);
	    ajuda.add( criaItemMenuTeclaChave( "Licen�a GNU", "Gnu",'G', new ImageIcon( getClass().getClassLoader().getResource( "imagens/gnuG.png" ) ) ) );
	    ajuda.add(criaItemMenuTeclaChave("Licen�a Nuvola", "Nuvola", 'N',
				new ImageIcon(getClass().getClassLoader().getResource(
						"imagens/nuvollaG.png"))));    
	    return menubar;	
	}
	
	/**
	 * Carrega o menu "Arquivo".
	 * @param JMenuBar menubar
	 */
	private void carregaMenuArquivo( JMenuBar menubar ) {
		menuArquivo.removeAll();
		menuArquivo.add( criaItemMenu( "Novo", "Novo",'N', new ImageIcon( getClass().getClassLoader().getResource( "imagens/novo.png" ) ) ) );
		menuArquivo.add( criaItemMenu( "Abrir", "Abrir",'A', new ImageIcon( getClass().getClassLoader().getResource( "imagens/arquivoG.png" ) ) ) );
		menuArquivo.add( criaItemMenu( "Salvar", "Salvar",'S', new ImageIcon( getClass().getClassLoader().getResource( "imagens/salvarG.png" ) )  ) );
		menuArquivo.add( criaItemMenu( "Salvar Como", "SalvarComo",'C', new ImageIcon( getClass().getClassLoader().getResource( "imagens/salvarcomoG.png" ) ) ) );
	    
	    /**
	     * Cria menu a partira da lista de arquivos
	     */
	    Vector listaArquivos = parametrosVerto.getListaArquivos();
	    menuArquivo.insertSeparator(4);
	    if ( listaArquivos != null ) {
		    if ( listaArquivos.size() > 0 ) {
		    	for (int i = 0; i < listaArquivos.size(); i++) {
		    		menuArquivo.add( criaItemMenu( (String) listaArquivos.get(i), "AbrirDaLista" ) );
				}
			    menuArquivo.insertSeparator( listaArquivos.size() + 5 );
		    }
	    }

	    menuArquivo.add( criaItemMenu( "Finalizar", "Finalizar",'F', new ImageIcon( getClass().getClassLoader().getResource( "imagens/sairG.png" ) ) ) );
    	
	    menubar.add(menuArquivo, 0);
	}

	private Component criaItemMenu( String titulo, String acao ) {

		JMenuItem it = new JMenuItem( titulo );
		it.setActionCommand( acao );
		it.addActionListener( this );
		
		return it;
	}

	private Component criaItemMenu( String titulo, String acao, char teclaAtalho, ImageIcon icone  ) {

		JMenuItem it = new JMenuItem( titulo, teclaAtalho );
		it.setIcon( icone );
		it.setActionCommand( acao );
		it.addActionListener( this );
		
		return it;
	}

	private Component criaItemMenu( String titulo, String acao, ImageIcon icone  ) {

		JMenuItem it = new JMenuItem( titulo );
		it.setIcon( icone );
		it.setActionCommand( acao );
		it.addActionListener( this );
		
		return it;
	}
	
	private Component criaItemMenuTeclaChave( String titulo, String acao, char teclaAtalho ) {

		JMenuItem it = new JMenuItem( titulo );
		it.setAccelerator(KeyStroke.getKeyStroke(teclaAtalho,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(), false));		
		it.setActionCommand( acao );
		it.addActionListener( this );
		
		return it;
	}

	private Component criaItemMenuTeclaChave( String titulo, String acao, char teclaAtalho, ImageIcon icone  ) {

		JMenuItem it = new JMenuItem( titulo );
		it.setAccelerator(KeyStroke.getKeyStroke(teclaAtalho,
                Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(), false));		
		it.setIcon( icone );
		it.setActionCommand( acao );
		it.addActionListener( this );
		
		return it;
	}

	private JRadioButtonMenuItem criaVertoItemMenu( String titulo, String acao ) {

		JRadioButtonMenuItem it = new JRadioButtonMenuItem( titulo );
		it.setActionCommand( acao );
		it.addActionListener( this );
		
		return it;
	}

	private JCheckBoxMenuItem criaOpcoesItemMenu( String titulo, String acao ) {

		JCheckBoxMenuItem it = new JCheckBoxMenuItem( titulo );
		it.setActionCommand( acao );
		it.addActionListener( this );
		
		return it;
	}

	public static Verto getInstance() {
		return mySelf;
	}
	
	private Component getPainelTopo() {

		JToolBar painelTopo = new JToolBar();
		painelTopo.setFloatable( false );

		JButton btnNovo = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/novo_small.png" ) ) );
		btnNovo.setToolTipText( "Novo" );
		btnNovo.setActionCommand( "Novo" );
		
		btnNovo.addActionListener( this );
		painelTopo.add( btnNovo );
		
		JButton btn = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/arquivo.png" ) ) );
		btn.setToolTipText( "Abrir arquivo" );
		btn.setActionCommand( "Abrir" );
		
		btn.addActionListener( this );
		painelTopo.add( btn );
		
		JButton btn1 = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/salvar.png" ) ) );
		btn1.setToolTipText( "Salvar" );
		btn1.setActionCommand( "Salvar" );
		
		btn1.addActionListener( this );
		painelTopo.add( btn1 );

		JButton btn2 = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/salvarcomo.png" ) ) );
		btn2.setToolTipText( "Salvar Como" );
		btn2.setActionCommand( "SalvarComo" );
		
		btn2.addActionListener( this );
		painelTopo.add( btn2 );
		
		JButton btn3 = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/compilar.png" ) ) );
		btn3.setToolTipText( "Efetua Compila��o" );
		btn3.setActionCommand( "Compilar" );
		
		btn3.addActionListener( this );
		painelTopo.add( btn3 );

		JButton btn4 = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/lookfeelsuportados.png" ) ) );
		btn4.setToolTipText( "Altera Estilo do Ambiente" );
		btn4.setActionCommand( "Estilo" );
		
		btn4.addActionListener( this );
		painelTopo.add( btn4 );

		JButton btn5 = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/impressao.png" ) ) );
		btn5.setToolTipText( "Imprime Relat�rio" );
		btn5.setActionCommand( "Relatorio" );
		
		btn5.addActionListener( this );
		painelTopo.add( btn5 );

		JButton btn8 = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/ajuda.png" ) ) );
		btn8.setToolTipText( "Exibe Tela de Ajuda" );
		btn8.setActionCommand( "Ajuda" );
		
		btn8.addActionListener( this );
		painelTopo.add( btn8 );
		
		JButton btn11 = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/ajudaMacro.png" ) ) );
		btn11.setToolTipText( "Exibe Tela de Ajuda MacroAssembler" );
		btn11.setActionCommand( "AjudaMacro" );
		
		btn11.addActionListener( this );
		painelTopo.add( btn11 );
		
		JButton btn7 = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/scesar.png" ) ) );
		btn7.setToolTipText( "Exibe cr�ditos do Cesar" );
		btn7.setActionCommand( "SobreCesar" );
		
		btn7.addActionListener( this );
		painelTopo.add( btn7 );

		JButton btn9 = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/sverto.png" ) ) );
		btn9.setToolTipText( "Exibe cr�ditos do Verto" );
		btn9.setActionCommand( "SobreVerto" );
		
		btn9.addActionListener( this );
		painelTopo.add( btn9 );

		JButton btn10 = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/gnu.png" ) ) );
		btn10.setToolTipText( "Exibe Licen�a GNU" );
		btn10.setActionCommand( "Gnu" );
		
		btn10.addActionListener( this );
		painelTopo.add( btn10 );

		JButton btn20 = new JButton( new ImageIcon( getClass().getClassLoader().getResource( "imagens/sair.png" ) ) );
		btn20.setToolTipText( "Sair do Ambiente Verto" );
		btn20.setActionCommand( "Finalizar" );
		
		btn20.addActionListener( this );
		painelTopo.add( btn20 );

		return painelTopo;
	}

	public void actionPerformed( ActionEvent arg0 ) {

		if( arg0.getActionCommand().equals( "Abrir" ) ) {
			abreArquivo();
		} else if ( arg0.getActionCommand().equalsIgnoreCase( "Xonga" ) ) {
			salvaArquivo();
		} else if ( arg0.getActionCommand().equals( "Salvar" ) ) {
			salvaArquivo();
		} else if ( arg0.getActionCommand().equals( "Novo" ) ) {
			int resposta = JOptionPane.showConfirmDialog(this, "Deseja abrir um documento novo?", "Novo arquivo", JOptionPane.YES_NO_OPTION);
			if(resposta==JOptionPane.YES_OPTION){
				novo();
			}
		
		
		} else if ( arg0.getActionCommand().equals( "SalvarComo" ) ) {
			salvaArquivoComo();
		} else if ( arg0.getActionCommand().equals( "AbrirDaLista" ) ) {
			abreDaLista( arg0.getSource() );
		} else if ( arg0.getActionCommand().equals( "SelecionaLook" ) ) {
			JRadioButtonMenuItem rb = (JRadioButtonMenuItem) arg0.getSource();
			selecionaLookAndFeel( rb.getName() );
		} else if ( arg0.getActionCommand().equals( "Relatorio" ) ) {
			imprimeRelatorio();
		} else if ( arg0.getActionCommand().equals( "Compilar" ) ) {
			try {
				if  ( fileName == null ) {
					salvaArquivoComo();
				}
				compilaArquivo();
			} catch ( ErroDeCompilacaoException ec ) {
				destacaLinhaErro();
			}	
		} else if ( arg0.getActionCommand().equals( "Estilo" ) ) {
				alternaEstilo();
		} else if (arg0.getActionCommand().equals("Diretorios")) {
			Diretorios.abreTelaDiretorios( mySelf );			
		} else if (arg0.getActionCommand().equals("LFSuportados")) {
			lookAndFeelSuportados();			
		} else if ( arg0.getActionCommand().equals( "AjudaMacro" ) ) {
			abreAjudaMacro();
		} else if ( arg0.getActionCommand().equals( "Cesar" ) ) {
			mostraSobreCesar();
		} else if ( arg0.getActionCommand().equals( "SobreCesar" ) ) {
			mostraSobreCesar();
		} else if ( arg0.getActionCommand().equals( "Ajuda" ) ) {
			abreAjuda();
		} else if ( arg0.getActionCommand().equals( "SomaSimples" ) ) {
			Exemplos.insereSoma();
		} else if ( arg0.getActionCommand().equals( "Quadrado" ) ) {
			Exemplos.insereQuadrado();
		} else if ( arg0.getActionCommand().equals( "DivisaoInteira" ) ) {
			Exemplos.insereDivisaoInteira();
		} else if ( arg0.getActionCommand().equals( "RaizInteira" ) ) {
			Exemplos.insereRaizInteira();
		} else if ( arg0.getActionCommand().equals( "Quadruplo" ) ) {
			Exemplos.insereQuadruplo();
		} else if ( arg0.getActionCommand().equals( "Fatorial" ) ) {
			Exemplos.insereFatorial();
		} else if ( arg0.getActionCommand().equals( "OrdenaVetor" ) ) {
			Exemplos.insereOrdenaVetor();
		}else if ( arg0.getActionCommand().equals( "SobreVerto" ) ) {
			mostraSobre();
		} else if ( arg0.getActionCommand().equals( "Splash" ) ) {
			mostraSplash();
		} else if ( arg0.getActionCommand().equals( "Gnu" ) ) {
			licencaGnu(); 
		} else if (arg0.getActionCommand().equals("Nuvola")) {
			licencaNuvola();			
		} else if (arg0.getActionCommand().equals("DestacaPalavras")) {
			if ( cbDestacaPalavras.isSelected() ) {
				Lexico k = new Lexico( textEditor ); 
				k.ressaltaProximoToken();
			} else {
				Highlighter hh = textEditor.getHighlighter();
				hh.removeAllHighlights();
			}
		} else if (arg0.getActionCommand().equals("NumeroLinha")) {
			if ( cbMostrarLinhas.isSelected() ) {
				textMacroAssembler.setBorder(LINE_BORDER);
				textEditor.setBorder(LINE_BORDER);
				textRotinas.setBorder(LINE_BORDER);
			} else {
				textEditor.setBorder(null);
				textMacroAssembler.setBorder(null);
				textRotinas.setBorder(null);
			}
		}else if ( arg0.getActionCommand().equals( "TelaCores" ) ) {
			Cores.abreTelaCores(mySelf);
		} else if ( arg0.getActionCommand().equals( "Indice" ) ) {
			exibeRotina( "lib.index" ); 
		} else if ( arg0.getActionCommand().equals( "IDiv" ) ) {
			exibeRotina( "IDiv.asm" ); 
		} else if ( arg0.getActionCommand().equals( "IMul" ) ) {
			exibeRotina( "IMul.asm" ); 
		} else if ( arg0.getActionCommand().equals( "AToI" ) ) {
			exibeRotina( "AToI.asm" ); 
		} else if ( arg0.getActionCommand().equals( "IToA" ) ) {
			exibeRotina( "IToA.asm" ); 
		} else if ( arg0.getActionCommand().equals( "Leituras" ) ) {
			exibeRotina( "Leituras.asm" ); 
		} else if ( arg0.getActionCommand().equals( "MemLib" ) ) {
			exibeRotina( "MemLib.asm" ); 
		} else if ( arg0.getActionCommand().equals( "VisorLib" ) ) {
			exibeRotina( "VisorLib.asm" ); 
		} else if ( arg0.getActionCommand().equals( "CorpoPrograma" ) ) {
			insereSintaxe( "\nfuncao inteiro principal() {\n}\n" );
		} else if ( arg0.getActionCommand().equals( "Funcao" ) ) {
			insereSintaxe( "\nfuncao <tipo> <nome_funcao> ( <parametros> ) {\n}\n" );
		} else if ( arg0.getActionCommand().equals( "Atribuicao" ) ) {
			insereSintaxe( "\n\t<variavel> = <express�o>;\n" );
		} else if ( arg0.getActionCommand().equals( "Selecao" ) ) {
			insereSintaxe( "\n\tse ( <condicao> ) entao {\n\t} senao {\n\t}\n" );
		} else if ( arg0.getActionCommand().equals( "Caso" ) ) {
			insereSintaxe( "\ncasos {\ncaso <condicao> : <expressao> ;\ncaso <condicao> : <expressao> ;\nsenao: <expressao> ;\n}\n" );
		} else if ( arg0.getActionCommand().equals( "Enquanto" ) ) {
			insereSintaxe( "\n\tenquanto ( <condicao> ) {\n\t}\n" );
		} else if ( arg0.getActionCommand().equals( "Para" ) ) {
			insereSintaxe( "\n\tpara <variavel> = <express�o> ate <express�o> {\n\t}\n" );
		} else if ( arg0.getActionCommand().equals( "RepitaAte" ) ) {
			insereSintaxe( "\n\trepita {\n\t} ate ( <condicao> )\n" );
		} else if ( arg0.getActionCommand().equals( "RepitaEnquanto" ) ) {
			insereSintaxe( "\n\trepita {\n\t} enquanto ( <condicao> )\n" );
		} else if ( arg0.getActionCommand().equals( "ApagaTela" ) ) {
			insereSintaxe( "\n\tApagaTela;\n" );
		} else if ( arg0.getActionCommand().equals( "Escrita" ) ) {
			insereSintaxe( "\n\tescreva ( [<inteiro>,] <expressao> );\n" );
		} else if ( arg0.getActionCommand().equals( "Leitura" ) ) {
			insereSintaxe( "\n\tleia ( (<inteiro>|<texto>), <variavel> );\n" );
		} else if ( arg0.getActionCommand().equals( "ParaInteiro" ) ) {
			insereSintaxe( "\n\tparaInteiro ( <expressao_caracter> )\n" );
		} else if ( arg0.getActionCommand().equals( "ParaCaracter" ) ) {
			insereSintaxe( "\n\tparaCaracter ( <expressao_inteira> )\n" );
		} else if ( arg0.getActionCommand().equals( "Inteiro" ) ) {
			insereSintaxe( "inteiro " );
		} else if ( arg0.getActionCommand().equals( "Caracter" ) ) {
			insereSintaxe( "caracter " );
		} else if ( arg0.getActionCommand().equals( "Logico" ) ) {
			insereSintaxe( "logico " );
		} else if ( arg0.getActionCommand().equals( "Constante Inteiro" ) ) {
			insereSintaxe( "constante inteiro " );
		} else if ( arg0.getActionCommand().equals( "Constante Caracter" ) ) {
			insereSintaxe( "constante caracter " );
		} else if ( arg0.getActionCommand().equals( "Constante Logico" ) ) {
			insereSintaxe( "constante logico " );
		}else if(arg0.getActionCommand().equals( "Copiar" )){
			copiar();
		}else if(arg0.getActionCommand().equals( "Colar" )){
			colar();
		}else if( arg0.getActionCommand().equals( "Finalizar" ) ) {
			finaliza();
		}
	}
	
	private void alternaEstilo() {
		// TODO Auto-generated method stub
		
	}


	private void imprimeRelatorio() {
		StringBuilder s = new StringBuilder();
		System.out.println(System.getProperty("file.separator").charAt(0));
		Relatorio relatorio = new Relatorio();
		s.append( textFonte.getText() );
		s.append( "\n" );
		s.append( textMacroAssembler.getText() );
		relatorio.setCodigo( s );
		relatorio.geraArquivo( diretorioParaRelatorio );
		JOptionPane.showMessageDialog( c, "Arquivo de Listagem :" + diretorioParaRelatorio, "Salvando Arquivo", JOptionPane.INFORMATION_MESSAGE );
	}

	private void lookAndFeelSuportados() {
		LookandFeelSuportados lfSuportados = new LookandFeelSuportados();
		lfSuportados.setVisible(true);
	}	
	
	/**
	 * Salva parametros ao sair do Verto
	 */
	private void finaliza(){
		try {
			
	//		menuArquivo.getco
			
	    	Enumeration<AbstractButton> i = bg.getElements();
	    	while(i.hasMoreElements()){
	    		JRadioButtonMenuItem menu = (JRadioButtonMenuItem) i.nextElement();
	    		if(menu.isSelected()){
	    			parametrosVerto.setAparencia(menu.getName());
	    			break;
	    		}
	    	}
			
//			if ( aparenciaListener.isMotif() ) {
//				parametrosVerto.setAparencia(0);
//			} else if ( aparenciaListener.isMetal() ) {
//				parametrosVerto.setAparencia(1);
//			} else if ( aparenciaListener.isWindows() ) {
//				parametrosVerto.setAparencia(2);
//			}

			parametrosVerto.salvaParametros();
		} catch (IOException e) {
			// N�o consegui criar o arquivo de parametros.
			// TODO colocar mensagem de erro
			e.printStackTrace();
		} finally {
			System.exit( 0 );
		}
	}

	private void selecionaLookAndFeel( String vlstnLookAndFeel ) {

		    try {
		    	UIManager.setLookAndFeel( vlstnLookAndFeel );
		        SwingUtilities.updateComponentTreeUI(this);
		      } catch (UnsupportedLookAndFeelException ex1) {
		        System.err.println("LookAndFeel n�o suportado: " + vlstnLookAndFeel);
		      } catch (ClassNotFoundException ex2) {
		        System.err.println("Classe LookAndFeel n�o encontrada: " + vlstnLookAndFeel);
		      } catch (InstantiationException ex3) {
		        System.err.println("LookAndFeel n�o pode ser carregado: " + vlstnLookAndFeel);
		      } catch (IllegalAccessException ex4) {
		        System.err.println("LookAndFeel n�o pode ser usado: " + vlstnLookAndFeel);
			}
		  }
	/**
	 * Abre um arquivo da lista de recentes
	 * @param menuItem: Objeto que acionou o evento (item do menu)
	 */
	private void abreDaLista( Object menuItem ) {
		/**
		 * Separa nome do arquivo
		 * TODO Deve existir uma maneira melhor
		 */
		String s1 = menuItem.toString().substring(menuItem.toString().lastIndexOf("text="));
		String s2 = s1.substring( 5, s1.length() - 1 );

		fileName = new File( s2 );
		
		abreArquivo( fileName );
	}

	private void mostraSplash() {
		TelaSplash telaSplash = new TelaSplash();
		telaSplash.setVisible( true );
	}

	private void licencaGnu() {
		LicencaGnu licencaGnu = new LicencaGnu();
		licencaGnu.setVisible( true );	
	}
	
	private void licencaNuvola() {
		LicencaNuvola licencaNuvola = new LicencaNuvola();
		licencaNuvola.setVisible(true);
	}	

	public void insereSintaxe( String sintaxe ) {

		int posicaoAtual = textEditor.getCaret().getMark();
		
		StringBuffer novoTexto = new StringBuffer();
		novoTexto.append( textEditor.getText().substring( 0, posicaoAtual ) );
		novoTexto.append( sintaxe );
		novoTexto.append( textEditor.getText().substring( posicaoAtual ) );
		
		textEditor.setText( novoTexto.toString() );
		
		if ( cbDestacaPalavras.isSelected() ) {
			Lexico k = new Lexico( textEditor ); 
			k.ressaltaProximoToken();
		} else {
			Highlighter hh = textEditor.getHighlighter();
			hh.removeAllHighlights();
		}
	}

	private JComponent getPainelCentral() {

		JTabbedPane tabbedPane = new JTabbedPane();
		
        JComponent panelF = getAreaCodigoFonte();
      //  tabbedPane.addTab("C�digo Fonte", panelF );

        JComponent panelE = getAreaEditor();
        tabbedPane.addTab( "Editor", panelE );
        
        JComponent panelM = getAreaCodigoMacroAssembler();
        tabbedPane.addTab( "C�digo MacroAssembler", panelM );

        JComponent panelC = getAreaCodigoOtimizado();
        tabbedPane.addTab( "Rotinas de Biblioteca", panelC );

		return tabbedPane;
	}

	private JComponent getAreaCodigoFonte() {

		htmlFonte = new JLabel();
		htmlPanel = new JPanel();
		
		htmlPanel.setBackground( Color.WHITE );
		
		FlowLayout fl = new FlowLayout();
		fl.setAlignment( FlowLayout.LEFT );
		htmlPanel.setLayout( fl );
		
//		textFonte = criaCodigoArea();
//		textFonte.setFont( new Font( "Courier", Font.PLAIN, 12 ) );
//		
//		JScrollPane scroller = new JScrollPane( textFonte );
//
//		textFonte.addFocusListener( fonteListener );
//		textFonte.addMouseListener( fonteMouseListener );
		
		return null;
	}
	
	private JComponent getAreaEditor() {

		textEditor = criaCodigoArea();
		textEditor.setFont( new Font( "Courier", Font.PLAIN, 12 ) );
		textEditor.setEditable( true );
		JScrollPane scroller = new JScrollPane( textEditor ); 
		
		textEditor.addFocusListener( editorListener );
		TeclaListener keyListener = new TeclaListener( textEditor );
		textEditor.addKeyListener( keyListener );
		
		return scroller;
	}
	
	private JComponent getAreaCodigoMacroAssembler() {

		textMacroAssembler = criaCodigoArea();
		textMacroAssembler.setEditable(false);
		textMacroAssembler.setFont( new Font( "Courier", Font.PLAIN, 12 ) );
		final JScrollPane scroller = new JScrollPane( textMacroAssembler );
		
		return scroller;
	}
	
	private JComponent getAreaCodigoOtimizado() {

		textRotinas = criaCodigoArea();
		textRotinas.setFont( new Font( "Courier", Font.PLAIN, 12 ) );
		textRotinas.setEditable(false);
		final JScrollPane scroller = new JScrollPane( textRotinas );
		return scroller;
	}
	
	private JTextArea criaCodigoArea() {
		
		JTextArea tArea = new JTextArea( 30, 71 );
		tArea.setLineWrap( true );
		tArea.setEnabled( true );
		tArea.setAutoscrolls( true );
		tArea.setFocusable( true );
		tArea.setBorder(LINE_BORDER);
		return tArea;
	}

	private JComponent getPainelSul() {
		
		JPanel panel = new JPanel();
		barraProgresso = new JProgressBar();
		barraProgresso.setMinimum( 0 );
		barraProgresso.setMaximum( 100 );
	     
		panel.setLayout( new BorderLayout() );
		pastasMensagens = (JTabbedPane) getPainelStatus();
		panel.add( pastasMensagens, BorderLayout.CENTER );
		panel.add( barraProgresso, BorderLayout.SOUTH );
		
		return panel;
	}
	
	private JComponent getPainelStatus() {

		JTabbedPane tabbedPane = new JTabbedPane();
		
        JComponent panel1 = getTextStatus();
        tabbedPane.addTab("Status da Compila��o", panel1 );

        JComponent panel2 = getTextLexico();
        tabbedPane.addTab( "L�xico", panel2 );

        JComponent panel3 = getTextSintatico();
        tabbedPane.addTab("Sint�tico", panel3 );

        JComponent panel4 = getTextSemantico();
        tabbedPane.addTab("Sem�ntico", panel4 );
		
        JComponent panel5 = getTextPilhaSemantica();
        tabbedPane.addTab("Pilha Sem�ntica", panel5 );

        JComponent panel6 = getTableTabelaSimbolos();
        
        panel6.setPreferredSize( new Dimension( 70, 70 ) );
        tabbedPane.addTab("Tabela de Simbolos ", panel6 );

        return tabbedPane;
	}

	private JComponent getTextStatus() {

		textStatus = criaTextArea();
		final JScrollPane scroller = new JScrollPane( textStatus );
		return scroller;
	}
	
	private JComponent getTextLexico() {

		textLexico = criaTextArea();
		textLexico.setFont( new Font( "Courier", Font.PLAIN, 12 ) );
		Color azul = new Color( 20, 20, 250 );
		textLexico.setForeground( azul );
		textLexico.setEditable(false);
		final JScrollPane scroller = new JScrollPane( textLexico );
		return scroller;
	}
	
	private JComponent getTextSintatico() {

		textSintatico = criaTextArea();
		textSintatico.setFont( new Font( "Courier", Font.PLAIN, 12 ) );
		Color verde = new Color( 20, 120, 50 );
		textSintatico.setForeground( verde );
		textSintatico.setEditable(false);
		final JScrollPane scroller = new JScrollPane( textSintatico );
		return scroller;
	}
	
	private JComponent getTextSemantico() {

		textSemantico = criaTextArea();
		textSemantico.setFont( new Font( "Courier", Font.PLAIN, 12 ) );
		Color verdeAzulado = new Color( 50, 90, 90 );
		textSemantico.setForeground( verdeAzulado );
		textSemantico.setEditable(false);
		final JScrollPane scroller = new JScrollPane( textSemantico );
		return scroller;
	}
	
	private JComponent getTextPilhaSemantica() {

		textPilhaSemantica = criaTextArea();
		textPilhaSemantica.setFont( new Font( "Courier", Font.PLAIN, 12 ) );
		Color vermelho = new Color( 120, 50, 50 );
		textPilhaSemantica.setForeground( vermelho );
		final JScrollPane scroller = new JScrollPane( textPilhaSemantica );
		return scroller;
	}
	
	private JComponent getTableTabelaSimbolos() {

		tableTabelaSimbolos = new JTable( 1, 1 );
		
		JScrollPane scroller = new JScrollPane( tableTabelaSimbolos );
		return scroller;
	}
	
	private JTextArea criaTextArea() {
		
		JTextArea tArea = new JTextArea( 10, 71 );
		
		tArea.setLineWrap( true );
		tArea.setEnabled( true );
		tArea.setAutoscrolls( true );
		tArea.setFocusable( true );
		tArea.setEditable(false);
		return tArea;
	}

	private void mostraSobreCesar() {
		
		JLabel lblSobre;
		JLabel lblVerto;
		JLabel lblRodape;
		JPanel painelSobre = new JPanel();
		
		StringBuffer sb1 = new StringBuffer();
		sb1.append( "<html>" );
		sb1.append( "<font color=blue size=+1>M�quina Hipot�tica: Cesar 16 - vers�o 1.1.1</font>" );
		lblVerto = new JLabel( sb1.toString() ); 
		sb1.append( "</html>" );

		lblVerto.setBorder( BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(""),
                BorderFactory.createEmptyBorder(5,10,10,10)) );		

		StringBuffer sb2 = new StringBuffer();
		sb2.append( "<html>" );
		sb2.append( "<font color=black>Autores:</font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "<font color=green>Raul Fernando Weber</font><br>" );
		sb2.append( "<font color=green>Taisy Silva Weber</font><br>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "<font color=black>Vers�es Win32:</font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "<font color=green>Fabio Augusto Dal Castel</font><br>" );
		sb2.append( "<font color=green>Carlos Arthur Lang Lisb�a</font><br>" );
		sb2.append( "</html>" );
		
		lblSobre = new JLabel( sb2.toString() ); 

		lblSobre.setBorder( BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Cr�ditos:"),
                BorderFactory.createEmptyBorder(10,10,10,10)) );		
		
		StringBuffer sb3 = new StringBuffer();
		sb3.append( "<html>" );
		sb3.append( "<font color=blue>" );
		sb3.append( "O Cesar � uma m�quina hipot�tica desenvolvida no Instituto<br>" );
		sb3.append( "de Inform�tica da UFRGS. Est� dispon�vel para download no<br>" );
		sb3.append( "site:</font> <font color=green>ftp://ftp.inf.ufrgs.br/pub</font><font color=blue>, na pasta info118.<br>" );
		sb3.append( "<br><br>" );
		sb3.append( "Todos os direitos do Cesar s�o reservados aos autores.</font>" );
		sb3.append( "</html>" );

		lblRodape = new JLabel( sb3.toString() ); 

		lblRodape.setBorder( BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(""),
                BorderFactory.createEmptyBorder(10,10,10,10)) );		
	
		painelSobre.setLayout( new BorderLayout() );
		painelSobre.add( lblVerto, BorderLayout.NORTH );
		painelSobre.add( lblSobre, BorderLayout.CENTER );
		painelSobre.add( lblRodape, BorderLayout.SOUTH );
		
		JOptionPane.showMessageDialog( null, painelSobre, "Sobre o Cesar", JOptionPane.INFORMATION_MESSAGE );
	}
	
	private void abreAjuda() {
		AjudaVerto ajudaVerto = new AjudaVerto();
		ajudaVerto.setVisible( true );	
	}

	private void abreAjudaMacro() {
		AjudaMacroAssembler ajudaMacroAssembler = new AjudaMacroAssembler();
		ajudaMacroAssembler.setVisible( true );	
	}
	
	private void mostraSobre() {
		
		JLabel lblAutores;
		JLabel lblColaboradores;
		JPanel pnlSobre;
		JLabel lblVerto;
		JLabel lblRodape;
		JPanel painelSobre = new JPanel();
		
		StringBuffer sb1 = new StringBuffer();
		sb1.append( "<html>" );
		sb1.append( "<font color=blue size=+2>Verto 2.6.2</font>" );
		lblVerto = new JLabel( sb1.toString() ); 
		sb1.append( "</html>" );

		lblVerto.setBorder( BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(""),
                BorderFactory.createEmptyBorder(5,10,10,10)) );		

		StringBuffer sb2 = new StringBuffer();
		
		sb2.append( "<html>" );
		sb2.append( "<TABLE BORDER=0>" );
		sb2.append( "<TR><TD>" );
		sb2.append( "Alexandre de Oliveira Zamberlam<br>" );
		sb2.append( "<font color=green><i>alexz@feevale.br</i></font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "Ana Carolina S. S. Jaskulski<br>" );
		sb2.append( "<font color=green><i>anaschneider@gmail.com</i></font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "Carlos S�rgio Schneider<br>" );
		sb2.append( "<font color=green><i>carlos@schneider.et.br</i></font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "Fernando Oscar Korndorfer<br>" );
		sb2.append( "<font color=green><i>fernando@esmeril.com.br</i></font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "Liliane Maria Passerino<br>" );
		sb2.append( "<font color=green><i>liliana@cinted.ufrgs.br</i></font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "Lucas Eskeff Freitas<br>" );
		sb2.append( "<font color=green><i>eskeff@gmail.com</i></font>" );
		sb2.append( "<br>" ); 
		sb2.append( "</TD><TD>" ); 
		sb2.append( "Mariana Kreisig<br>" );
		sb2.append( "<font color=green><i>marianakreisig@gmail.com</i></font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "Paulo Roberto Ferreira Jr.<br>" );
		sb2.append( "<font color=green><i> paulo.ferreira@ufpel.edu.br</i></font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "Ricardo Ferreira de Oliveira<br>" );
		sb2.append( "<font color=green><i>ricardofo@feevale.br</i></font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "Samuel Ant�nio Klein<br>" );
		sb2.append( "<font color=green><i>samuel3dstudio@gmail.com</i></font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "Thiago Glaser<br>" );
		sb2.append( "<font color=green><i>thiago.glaser@gmail.com</i></font>" );
		sb2.append( "<br><br>" ); 
		sb2.append( "Vandersilvio da Silva<br>" );
		sb2.append( "<font color=green><i>vandersilvio@hotmail.com</i></font>" );
		sb2.append( "</TD></TR>" );
		sb2.append( "</html>" );
		
		lblAutores = new JLabel( sb2.toString() ); 
		
		lblAutores.setBorder( BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Autores:"),
                BorderFactory.createEmptyBorder(10,10,10,10)) );		
		
		StringBuffer sb3 = new StringBuffer();
		sb3.append( "<html>" );
		sb3.append( "<font color=green><i>http://verto.sf.net</i></font>" );
		sb3.append( "</html>" );
		
		lblColaboradores = new JLabel( sb3.toString() ); 

		lblColaboradores.setBorder( BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Projeto no SourceForge"),
                BorderFactory.createEmptyBorder(10,10,10,10)) );		
		
		pnlSobre = new JPanel();
		pnlSobre.setLayout( new BorderLayout() );
		pnlSobre.add( lblAutores, BorderLayout.CENTER );
		pnlSobre.add( lblColaboradores, BorderLayout.SOUTH );
		
		StringBuffer sb4 = new StringBuffer();
		sb4.append( "<html>" );
		sb4.append( "<font color=blue>" );
		sb4.append( "Desenvolvido na Universidade Feevale" );
		sb4.append( "<br>" );
		sb4.append( "Novo Hamburgo - RS" );
		sb4.append( "<br>" );
		sb4.append( "Vers�o 2.6.2 - junho/2010" );
		sb4.append( "</font>" );
		sb4.append( "</html>" );

		lblRodape = new JLabel( sb4.toString() ); 

		lblRodape.setBorder( BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(""),
                BorderFactory.createEmptyBorder(10,10,10,10)) );		
	
		painelSobre.setLayout( new BorderLayout() );
		painelSobre.add( lblVerto, BorderLayout.NORTH );
		
		painelSobre.add(pnlSobre, BorderLayout.CENTER );
		painelSobre.add( lblRodape, BorderLayout.SOUTH );
		
		JOptionPane.showMessageDialog( null, painelSobre, "Sobre o Verto", JOptionPane.INFORMATION_MESSAGE );
	}

	private void abreArquivo() {

		JFileChooser fileChooser = new JFileChooser();
		
		fileChooser.setFileSelectionMode( JFileChooser.FILES_ONLY );

		fileChooser.addChoosableFileFilter( filtro );
		// fileChooser.setFileFilter( filter );
		
		int result = fileChooser.showOpenDialog( c );
		
		if( result == JFileChooser.CANCEL_OPTION ) {
			return;
		}
		
		if ( result == JFileChooser.APPROVE_OPTION ) {
			System.out.println( "Gildinha" );
		}
		
		fileName = fileChooser.getSelectedFile();

		if( abreArquivo( fileName ) ) {		
			/**
			 * Adiciona nome do arquivo na lista de arquivos recentes
			 */
			parametrosVerto.adicionaArquivo(fileName.toString());

			/**
			 * Recarrega o menu de arquivos
			 */
			carregaMenuArquivo( mySelf.getJMenuBar() );
		}
	}

	private boolean abreArquivo( File fileName ) {

		
		
		if( fileName == null || fileName.getName().trim().equals( "" ) ) {
			JOptionPane.showMessageDialog( c, "Nome de Arquivo Inv�lido", "Nome de Arquivo Inv�lido", JOptionPane.ERROR_MESSAGE );
			return false;
		} else {
			linhaAtual = 1;
			
			try {
				FileReader fr = new FileReader( fileName );
				BufferedReader bfr = new BufferedReader( fr );
				
				linhas = "";
				String linha;
				
				do {
					linha = bfr.readLine();
					if ( linha != null ) {
						linhas += linha + (char) 13 + (char) 10;
						linhaAtual++;
					}
				} while( linha != null );

				linhaAtual--;
				
				fr.close();	

				/* Posso usar um texto ou um html */
				htmlFonte.setForeground( Color.BLUE );
				htmlFonte.setBackground( Color.WHITE );
				htmlFonte.setFont(new Font( "Courier", Font.PLAIN, 12 ) );
				htmlFonte.setText( incluiNumeracao( textEditor.getText() ) );
				htmlPanel.add( htmlFonte );
				
				textEditor.setText( linhas.toString() );  
				//textFonte.setText( incluiNumeracao( textEditor.getText() ) );
				
				textEditor.setCaretPosition(0);
			//	textFonte.setCaretPosition(0);
				
				limpaObjetos();
				setTitle(TITULO+fileName);
				return true;
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog( c, e.getMessage(), "Erro na Localiza��o do Arquivo", JOptionPane.ERROR_MESSAGE );
				return false;
			} catch (IOException e) {
				JOptionPane.showMessageDialog( c, e.getMessage(), "Erro de Entrada/Sa�da", JOptionPane.ERROR_MESSAGE );
				return false;
			} 
		}
	}

	private void salvaArquivo() {
		
		if ( fileName == null) {
			salvaArquivoComo();
			//JOptionPane.showMessageDialog( c, "Nenhum arquivo aberto no momento!", "Erro ao Salvar Arquivo", JOptionPane.ERROR_MESSAGE );
		} else {
			FileWriter fw;
			try {
				fw = new FileWriter( fileName );
				BufferedWriter bfw = new BufferedWriter( fw ); 
				bfw.write( this.textEditor.getText() );
				bfw.close();
				/**
				 * Adiciona nome do arquivo na lista de arquivos recentes
				 */
				parametrosVerto.adicionaArquivo( fileName.toString() );
				/**
				 * Recarrega o menu de arquivos
				 */
				carregaMenuArquivo( mySelf.getJMenuBar() );
				
				JOptionPane.showMessageDialog( c, "Arquivo Salvo: " + fileName, "Salvando Arquivo", JOptionPane.INFORMATION_MESSAGE );
			} catch (IOException e) {
				JOptionPane.showMessageDialog( c, e.getMessage(), "Erro de Entrada/Sa�da", JOptionPane.ERROR_MESSAGE );
			} 
		}
	}
	
	private void novo(){
		limpaObjetos(true);
		fileName = null;
		setTitle(TITULO);
	}
	

	private void salvaArquivoComo() {
		
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.addChoosableFileFilter( filtro );
		int result = fileChooser.showSaveDialog( c );
		
		if( result == JFileChooser.CANCEL_OPTION ) {
			return;
		}
		
		fileName = fileChooser.getSelectedFile();
		
		if( fileName == null || fileName.getName().trim().equals( "" ) ) {
			JOptionPane.showMessageDialog( c, "Nome de Arquivo Inv�lido", "Nome de Arquivo Inv�lido", JOptionPane.ERROR_MESSAGE );
		} else {
			FileWriter fw;
			try {
				fw = new FileWriter( fileName );
				BufferedWriter bfw = new BufferedWriter( fw ); 
				bfw.write( this.textEditor.getText() );
				bfw.close();

				/**
				 * Adiciona nome do arquivo na lista de arquivos recentes
				 */
				parametrosVerto.adicionaArquivo( fileName.toString() );

				/**
				 * Recarrega o menu de arquivos
				 */
				carregaMenuArquivo( mySelf.getJMenuBar() );
				
				JOptionPane.showMessageDialog( c, "Arquivo Salvo: " + fileName, "Salvando Arquivo", JOptionPane.INFORMATION_MESSAGE );
				setTitle(TITULO+fileName);
			} catch (IOException e) {
				JOptionPane.showMessageDialog( null, e.getMessage(), "Erro de Entrada/Sa�da", JOptionPane.ERROR_MESSAGE );
			} 
		}
	}

	private void compilaArquivo() {
		
		if ( textEditor.getText().length() <= 1 ) {
			JOptionPane.showMessageDialog( c, "O texto fonte no editor est� vazio!", "Aten��o!", JOptionPane.WARNING_MESSAGE );
		} else {
			if(fileName!=null){
				try {
					pastasFontes.setSelectedIndex( 0 );
	
					limpaObjetos();
	
					System.out.println( "antes do Sintatico" );
					
					sin = new Sintatico( textEditor.getText() );   
	
					System.out.println( "antes do Sintatico" );
	
					sin.setNomeFonte( fileName.getName().trim() );
					
					
					String nomeAsm = diretorioParaAssembler + fileName.getName().trim().substring( 0, fileName.getName().trim().indexOf( "." ) ) + ".asm";
					String nomeMem = diretorioParaMneumonico + fileName.getName().trim().substring( 0, fileName.getName().trim().indexOf( "." ) ) + ".mem";
				
					FileWriter fw = new FileWriter( nomeAsm ); 
					BufferedWriter bfw = new BufferedWriter( fw ); 
	
					//JOptionPane.showMessageDialog( c, "Compila��o sem erros", "Arquivo gerado: " + nomeMem, JOptionPane.INFORMATION_MESSAGE );
					
					bfw.write( sin.getFonte() );
					textMacroAssembler.setText( sin.getFonte() );
							
					
					
					
					bfw.close();
					
					System.out.println( "antes do vasm" );
					
					VertoAsm vasm =  new VertoAsm( nomeAsm, nomeMem );
	
					System.out.println( "depois do vasm" );
	
					mensagensStatus.append( "Compila��o terminada com sucesso!\n\n" );
					mensagensStatus.append( "Numero de linhas do c�digo fonte : " + linhaAtual + "\n" );
					
					setMensagemStatus( mensagensStatus.toString() );
					bfw.close();
					fw.close(); 
				} catch ( ErroLexicoException el ) { 
					JOptionPane.showMessageDialog( c, el.getMessage(), "Erro L�xico", JOptionPane.ERROR_MESSAGE );
					// setMensagemLexico( "Erro L�xico: " + el.getMessage() );
					setMensagemErroStatus( "Erro L�xico: " + el.getMessage() );
					throw new ErroDeCompilacaoException( el.getMessage() );
				} catch ( ErroSintaticoException es ) {
					JOptionPane.showMessageDialog( c, es.getMessage(), "Erro Sint�tico", JOptionPane.ERROR_MESSAGE );
					// setMensagemSintatico( "\nErro Sint�tico: " + es.getMessage() );
					setMensagemErroStatus( "Erro Sint�tico: " + es.getMessage() );
					throw new ErroDeCompilacaoException( es.getMessage() );
				} catch ( ErroSemanticoException esm ) {
					JOptionPane.showMessageDialog( c, esm.getMessage(), "Erro Sem�ntico", JOptionPane.ERROR_MESSAGE );
					// setMensagemSemantico( "Erro Sem�ntico: " + esm.getMessage() );
					
					setMensagemErroStatus( "Erro Sem�ntico: " + esm.getMessage() );
					throw new ErroDeCompilacaoException( esm.getMessage() );
				} catch ( ErroDeCompilacaoException ec ) {
					JOptionPane.showMessageDialog( c, ec.getMessage(), "Erro de Compila��o", JOptionPane.ERROR_MESSAGE );
					setMensagemErroStatus( "Erro de Compila��o: " + ec.getMessage() );
				} catch ( Throwable e ) {
					JOptionPane.showMessageDialog( c, e.getMessage(), "Erro Desconhecido", JOptionPane.ERROR_MESSAGE );
					setMensagemErroStatus( "Erro Ignorado: " + e.getMessage() + "\nUltima a��o sint�tica: " + ultimaAcaoSintatica + "\nUltima a��o sem�ntica: " + ultimaAcaoSemantica );
					
				}finally{
					pastasMensagens.setSelectedIndex(0);
					
					new Thread(){
						@Override
						public void run() {
							for (int i = 0; i <10; i++) {
								if(i%2==0){
									setMensagemStatus( mensagensStatus.toString(),Color.RED );
								}else{
									setMensagemStatus( mensagensStatus.toString() );
								}
								try {
									sleep(50);
								} catch (InterruptedException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								repaint();
							}
							super.run();
						}
					}.start();
					
				} 
			}else{
				setMensagemErroStatus( "Erro Ignorado: Sem arquivo fonte" + "\nUltima a��o sint�tica: " + ultimaAcaoSintatica + "\nUltima a��o sem�ntica: " + ultimaAcaoSemantica );
			}
		}
	}

	private void limpaObjetos() {
		limpaObjetos(false);
	}
	
	private void limpaObjetos(boolean novo) {

		mensagensStatus = new StringBuffer();
		if(novo){
			textEditor.setText(" ");
		}
		textMacroAssembler.setText( " " );
		textLexico.setText( " " );
		textSintatico.setText( " " );
		textSemantico.setText( " " );
		textPilhaSemantica.setText( " " );
		textStatus.setText( " " );
		textRotinas.setText( " " ); 
		
	}

	
	private Action getAction(String name)
	{
		Action action = null;
		Action[] actions = textEditor.getActions();
 
		for (int i = 0; i < actions.length; i++)
		{
			if (name.equals( actions[i].getValue(Action.NAME).toString() ) )
			{
				action = actions[i];
				break;
			}
		}
 
		return action;
	}

	
	private void destacaLinhaErro() {
			textEditor.requestFocus();
				try {
					textEditor.setCaretPosition(textEditor.getLineStartOffset(linhaErro - 3));
				} catch (BadLocationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				selectLine.actionPerformed( null );
//			Highlighter h = textEditor.getHighlighter();
//			h.removeAllHighlights();
//		          try {
//		        	  h.addHighlight(i, i+1, new DefaultHighlighter.DefaultHighlightPainter( new Color( 180, 220, 250 ) ) );
//				} catch (BadLocationException e) {
//					e.printStackTrace();
//				}
		}

	public void montaCodigoFonte() {
		
	}
	
	public void setMensagemStatus( String mensagem ) {
		
		Color azul = new Color( 20, 20, 250 );
		textStatus.setFont( new Font( "Arial", Font.BOLD, 12 ) );
		textStatus.setForeground( azul );
		textStatus.setText( mensagem );
	}
	
	public void setMensagemStatus( String mensagem,Color c ) {

		textStatus.setFont( new Font( "Arial", Font.BOLD, 12 ) );
		textStatus.setForeground( c );
		textStatus.setText( mensagem );
	}
	
	public void setMensagemLexico( String mensagem ) {

		textLexico.setText( mensagem );
	}
	
	public void setMensagemSintatico( String mensagem ) {

		textSintatico.setText( mensagem );
	}
	
	public void addMensagemSintatico( String mensagem ) {

		textSintatico.append( mensagem );
	}
	
	public void setMensagemSemantico( String mensagem ) {

		textSemantico.setText( mensagem );
	}
	
	public void addMensagemSemantico( String mensagem ) {

		textSemantico.append( mensagem );
	}
	
	public void setMensagemPilhaSemantica( String mensagem ) {

		textPilhaSemantica.setText( mensagem );
	}
	
	public void setMensagemTabelaSimbolos( JTable t ) {

		tableTabelaSimbolos = t;
		// textTabelaSimbolos.setText( mensagem );
	}
	
	public void setMensagemErroStatus( String mensagem ) {

		Color vermelho = new Color( 150, 10, 10 );
		textStatus.setFont( new Font( "Arial", Font.BOLD, 12 ) );
		textStatus.setForeground( vermelho );
		textStatus.setText( mensagem );
	}

	public void setFimBarraProgresso( int m ) {

		barraProgresso.setMinimum( 0 );
		barraProgresso.setMaximum( m );
	}

	public void atualizaBarraProgresso( int n ) {
	  	barraProgresso.setValue( n );
	}	
	  
	public void setLinhaErro( int i ) {
	  	linhaErro = i;
	}
	  
	private String incluiNumeracao( String texto ) {
		
		int i = 0;
		int j = 2;
		StringBuffer textoNumerado = new StringBuffer();

		if ( texto != null ) {
			textoNumerado.append( "[0001] - " );
			while ( i < texto.length() ) {

				if ( texto.charAt( i ) == '\n' ) {
					textoNumerado.append( texto.charAt( i ) );
					if ( i < ( texto.length()-1 ) ) {
						textoNumerado.append( "[" );
						textoNumerado.append( formatadorLinha.format( j ) );
						textoNumerado.append( "] - " );
						linhaAtual = j;
						j++;
					}
				} else {
					textoNumerado.append( texto.charAt( i ) );
				}
				i++;
			}
			return textoNumerado.toString();
		} else {
			return null;
		}
	}
	
	public static String buscaDiretorioRelatorio() {

		Properties queries = null;
		String nomeAplicativo = null;

		queries = new Properties();
		File homedir = new File(System.getProperty("user.home"));

		try {
			try {
				try {
					queries.load(new FileInputStream(trilhaDiretorio));
				} catch (FileNotFoundException e) {
					queries.store(new FileOutputStream(trilhaDiretorio),
							"criando tabela");
					queries.load(new FileInputStream(trilhaDiretorio));
				}
				if (queries.getProperty("Relatorio") == null) {
					return homedir.toString();
				} else {
					nomeAplicativo = queries.getProperty("Relatorio");
					return nomeAplicativo;
				}
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog( mySelf, "Arquivo n�o encontrado!", "Entre em: Compilar->Diretorios Default e cadastre.", JOptionPane.WARNING_MESSAGE );
				return homedir.toString();			}
		} catch (IOException e) {
			JOptionPane.showMessageDialog( mySelf, "Erro de I/O!", "Erro de I/O!", JOptionPane.ERROR_MESSAGE );
			e.printStackTrace();
		}
		return homedir.toString();			
	}
	
	public static String buscaDiretorioAssemblerCesar() {

		Properties queries = null;
		String nomeAplicativo = null;

		queries = new Properties();
		File homedir = new File(System.getProperty("user.home"));

		try {
			try {
				try {
					queries.load(new FileInputStream(trilhaDiretorio));
				} catch (FileNotFoundException e) {
					queries.store(new FileOutputStream(trilhaDiretorio),
							"criando tabela");
					queries.load(new FileInputStream(trilhaDiretorio));
				}
				if (queries.getProperty("Assembler Cesar") == null) {
					return homedir.toString();
				} else {
					nomeAplicativo = queries.getProperty("Assembler Cesar");
					return nomeAplicativo;
				}
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog( mySelf, "Arquivo n�o encontrado!", "Entre em: Compilar->Diretorios Default e cadastre.", JOptionPane.WARNING_MESSAGE );
				return homedir.toString();			}
		} catch (IOException e) {
			JOptionPane.showMessageDialog( mySelf, "Erro de I/O!", "Erro de I/O!", JOptionPane.ERROR_MESSAGE );
			e.printStackTrace();
		}
		return homedir.toString();			
	}
	
	public static String buscaDiretorioMneumonico() {

		Properties queries = null;
		String nomeAplicativo = null;

		queries = new Properties();
		File homedir = new File(System.getProperty("user.home"));

		try {
			try {
				try {
					queries.load(new FileInputStream(trilhaDiretorio));
				} catch (FileNotFoundException e) {
					queries.store(new FileOutputStream(trilhaDiretorio),
							"criando tabela");
					queries.load(new FileInputStream(trilhaDiretorio));
				}
				if (queries.getProperty("Mneum�nicos") == null) {
					return homedir.toString();
				} else {
					nomeAplicativo = queries.getProperty("Mneum�nicos");
					return nomeAplicativo;
				}
			} catch (FileNotFoundException e) {
				JOptionPane.showMessageDialog( mySelf, "Arquivo n�o encontrado!", "Entre em: Compilar->Diretorios Default e cadastre.", JOptionPane.WARNING_MESSAGE );
				return homedir.toString();			}
		} catch (IOException e) {
			JOptionPane.showMessageDialog( mySelf, "Erro de I/O!", "Erro de I/O!", JOptionPane.ERROR_MESSAGE );
			e.printStackTrace();
		}
		return homedir.toString();			
	}
	

	/**
	 * Classe Interna: EditorListener
	 * 
	 */	  
	class EditorListener implements FocusListener {

		public void focusGained(FocusEvent arg0) {
		}

		public void focusLost(FocusEvent arg0) {
		//	textFonte.setText( incluiNumeracao( textEditor.getText() ) );
		}
	}
	 
	/**
	 * Classe Interna: FonteListener
	 * 
	 */	  
	class FonteListener implements FocusListener {

		public void focusGained(FocusEvent arg0) {
			pastasFontes.setSelectedIndex( 0 );
		}

		public void focusLost(FocusEvent arg0) { 
		}
	}

	/**
	 * Classe Interna: FonteMouseListener
	 * 
	 */	  
	class FonteMouseListener implements MouseInputListener {

		int linha, deslocamento, posicao, posicaoAbsoluta;
		
		public void mouseClicked(MouseEvent arg0) {
			try {
				/* Posiciono na pasta de Edi��o na mesma posi��o clicada no fonte */
				linha = textFonte.getLineOfOffset( textFonte.getCaretPosition() );
				posicao = textFonte.getLineEndOffset( linha ) - textFonte.getCaretPosition();
				posicaoAbsoluta = textEditor.getLineEndOffset( linha ) - posicao;
				if ( posicaoAbsoluta < 0 ) {
					posicaoAbsoluta = 0;
				}
				pastasFontes.setSelectedIndex( 1 );
				textEditor.setCaretPosition( posicaoAbsoluta );
				textEditor.grabFocus();
				
			} catch (BadLocationException e) {
				e.printStackTrace();
			}
		}

		public void mouseEntered(MouseEvent arg0) {
		}

		public void mouseExited(MouseEvent arg0) {
		}

		public void mousePressed(MouseEvent arg0) {
		}

		public void mouseReleased(MouseEvent arg0) {
			try {
				pastasFontes.setSelectedIndex( 1 );
				textEditor.grabFocus();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void mouseDragged(MouseEvent arg0) {
			try {
				pastasFontes.setSelectedIndex( 1 );
				textEditor.grabFocus();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void mouseMoved(MouseEvent arg0) {
		}
	}
	
	/**
	 * Classe Interna: JanelaListner
	 * 
	 */	  
	class JanelaListner implements WindowListener {

		public RuntimeException windowClosingNotify(WindowEvent arg0) {
			return null;
		}

		public RuntimeException windowClosingDelivered(WindowEvent arg0) {
			return null;
		}

		public void windowOpened(WindowEvent arg0) {
		}

		public void windowClosing(WindowEvent arg0) {
			// Grava parametros ao sair do Verto
			finaliza();
		
		}

		public void windowClosed(WindowEvent arg0) {
		}

		public void windowIconified(WindowEvent arg0) {
		}

		public void windowDeiconified(WindowEvent arg0) {
		}

		public void windowActivated(WindowEvent arg0) {
		}

		public void windowDeactivated(WindowEvent arg0) {
		}
		
	}
	
	public void setTableTabelaSimbolos(JTable tableTabelaSimbolos ) {

		Color corHeaderJTable;
		
		tableTabelaSimbolos.setEnabled( false );

		//if ( cbUsaCores.isSelected() ) {
		if ( parametrosVerto.isUsaCores() ) {
			// Op��o de Cor para Header	
			JTableHeader jth = tableTabelaSimbolos.getTableHeader();
		//	if ( aparenciaListener.isMotif() ) {
		//		corHeaderJTable = new Color( 10, 100, 150 );
		//		jth.setForeground( Color.WHITE );
		////	} else if ( aparenciaListener.isWindows() ) {
		//		corHeaderJTable = new Color( 100, 180, 220 );
		//		jth.setForeground( Color.BLACK );
		//	} else {
				corHeaderJTable = new Color( 170, 170, 220 );
				jth.setForeground( Color.BLACK );
		//	}
			jth.setBackground( corHeaderJTable );
		}

		JScrollPane jsp = new JScrollPane( tableTabelaSimbolos );
		jsp.setPreferredSize( new Dimension( 50, 50 ) );
		pastasMensagens.removeTabAt( 5 );
		pastasMensagens.addTab( "Tabela de S�mbolos ", (Component) jsp );
	}

	public void exibeRotina( String arquivo) {
		
		StringBuffer bufferRotina = new StringBuffer();
		
		pastasFontes.setSelectedIndex( 2 );
		textRotinas.grabFocus();
		
		textRotinas.setText( "" );
		
		try {
			BufferedReader in = new BufferedReader( new InputStreamReader( getClass().getClassLoader().getResourceAsStream( "asm/" + arquivo ) ) );
			try {
				String s;
				bufferRotina.append( "\n" );
				while( ( s = in.readLine() ) != null ) {
					bufferRotina.append( (String) s + "\n" );
				}
			} finally {
				textRotinas.setText( bufferRotina.toString() );
				textRotinas.setCaretPosition(0);
				in.close();
			}
		} catch( Exception e ) {
			textRotinas.setText( "rotina: " + arquivo + " n�o encontrada!" );
			
			e.printStackTrace();
		}
	}
	
	public void setaCoresUIManager() {

		UIManager.put("TextField.selectionForeground",
				Cor.textFieldSelectionForeground);
		UIManager.put("TextField.selectionBackground",
				Cor.textFieldSelectionBackground);
		UIManager.put("ComboBox.disabledBackground", new Color(238, 238, 238));
		UIManager.put("ComboBox.disabledForeground", new Color(20, 80, 130));
		UIManager.put("TextArea.foreground", Cor.textAreaForeground);
		UIManager.put("TextArea.background", Cor.textAreaBackground);
	}

	public JCheckBoxMenuItem getCbDestacaPalavras() {
		return cbDestacaPalavras;
	}

	public void setCbDestacaPalavras(JCheckBoxMenuItem cbDestacaPalavras) {
		this.cbDestacaPalavras = cbDestacaPalavras;
	}

	public void atualizaTextFonte() {
		textFonte.setText( incluiNumeracao( textEditor.getText() ) );
	}

	public String getUltimaAcaoSintatica() {
		return ultimaAcaoSintatica;
	}

	public void setUltimaAcaoSintatica(String ultimaAcaoSintatica) {
		this.ultimaAcaoSintatica = ultimaAcaoSintatica;
	}

	public String getUltimaAcaoSemantica() {
		return ultimaAcaoSemantica;
	}

	public void setUltimaAcaoSemantica(String ultimaAcaoSemantica) {
		this.ultimaAcaoSemantica = ultimaAcaoSemantica;
	}
	
	public static void inicia( String args[]) {
		Verto v = new Verto();
		v.setVisible( true );
	}
	
	public static void main( String args[] ) {
		
		SplashWindow.splash(Verto.class.getResource("/imagens/Verto.png"));
        SplashWindow.invokeMain(Verto.class.getName(), args);
        SplashWindow.disposeSplash();
	    
		
//		int vetor[] = {2,1,0,3,4,5,6,4,3,10};
////		int vetor[] = {0,1,2,3,4,5,6,7,8,9};
//        for (int i = 0; i < 9; i++) {
//			for (int j = 0; j < i; j++) {
//				if(vetor[i]<vetor[j]){
//					int troca  = vetor[i];
//					vetor[i] = vetor[j];
//					vetor[j] = troca;
//				}
//			}
//		}
//        for (int i = 0; i < vetor.length; i++) {
//        	System.err.println(vetor[i]);
//		}
        
	}

}

package verto.semantico;
/*
 * $Id: PilhaEstrutura.java,v 1.3 2008/04/07 17:36:50 mariana Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * 
 */

import java.util.Stack;

import verto.VertoAsm;
import verto.exception.ErroSemanticoException;
import verto.sintatico.Sintatico;

/**
 * Classe: Pilha Sem�ntica
 * 
 * Esta classe modela a pilha sem�ntica.
 *  
 * Este Analisador Sem�ntico toma as suas a��es baseado na chamada do Sint�tico. Este,
 * por sua vez, chama o Sem�ntico a cada vez que reconhece uma regra. Esta t�cnica � 
 * conhecida como Tradu��o Dirigida pela Sintaxe.
 *  
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * 
 * @see Sintatico
 * @see Semantico
 * @see PilhaSemantica
 * @see NodoPilhaSemantica
 * @see VertoAsm
 * @see ErroSemanticoException
 * 
 * @version 2.6.2
 */
public class PilhaEstrutura {

	public static final int T_SE       = 1;
	public static final int T_ENQUANTO = 2;
	public static final int T_PARA     = 3;
	public static final int T_REPITA   = 4;
	public static final int T_CASO     = 5;

	private Stack pilha;
	
	public PilhaEstrutura() {
		pilha = new Stack();
	}	
	
	public NodoEstrutura pop() {
		
		NodoEstrutura nodo;
		nodo = ( NodoEstrutura ) pilha.pop();
		return( nodo ); 
	}

	public NodoEstrutura push( String l1, String l2, int tipo ) {
		
		NodoEstrutura nodo = new NodoEstrutura( l1, l2, tipo );
		pilha.push( nodo );
		return( nodo );
	}
	
	public NodoEstrutura push( NodoEstrutura nodo ) {
		
		pilha.push( nodo );
		return( nodo );
	}
}
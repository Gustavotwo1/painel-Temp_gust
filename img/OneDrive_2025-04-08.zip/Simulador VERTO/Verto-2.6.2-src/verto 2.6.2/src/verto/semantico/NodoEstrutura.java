package verto.semantico;
import verto.exception.ErroSemanticoException;

/*
 * $Id: NodoEstrutura.java,v 1.3 2008/04/07 17:36:50 mariana Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */

/**
 * Classe: NodoPilhaSem�ntica
 * 
 * Esta classe modela objetos que formar�o a pilha de niveis de estrutura.
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * 
 * @see Semantico
 * @see PilhaSemantica
 * @see ErroSemanticoException
 * 
 * @version 2.6.2
 */
public class NodoEstrutura {
	
	private String label1; // fimEntao 	inicioEnquanto 	inicioRepita	inicioPara
	private String label2; // Senao 	fimEnquanto 					fimPara
	private int    tipoEstrutura;
	
	public NodoEstrutura( String l1, String l2, int tipo ) {
		label1 = l1;
		label2 = l2;
		tipoEstrutura = tipo;
	}

	public String getLabel1() {
		return label1;
	}

	public void setLabel1(String label1) {
		this.label1 = label1;
	}

	public String getLabel2() {
		return label2;
	}

	public void setLabel2(String label2) {
		this.label2 = label2;
	}

	public int getTipoEstrutura() {
		return tipoEstrutura;
	}

	public void setTipoEstrutura(int tipoEstrutura) {
		this.tipoEstrutura = tipoEstrutura;
	}
}
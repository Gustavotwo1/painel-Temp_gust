package verto.semantico;
import verto.exception.ErroSemanticoException;
import verto.lexico.Lexico;

/*
 * $Id: NodoPilhaSemantica.java,v 1.2 2008/04/07 17:36:50 mariana Exp $
 * 
 * Portions copyright (C) 2008 Alexandre de Oliveira Zamberlam
 * Portions copyright (C) 2008 Ana Carolina S. S. Jaskulski
 * Portions copyright (C) 2008 Carlos S�rgio Schneider
 * Portions copyright (C) 2008 Fernando Oscar Korndorfer
 * Portions copyright (C) 2008 Mariana Kreisig
 * Portions copyright (C) 2008 Paulo Roberto Ferreira Jr.
 * Portions copyright (C) 2008 Ricardo Ferreira de Oliveira
 * Portions copyright (C) 2008 Thiago Glaser
 * 
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  
 */

/**
 * Classe: NodoPilhaSem�ntica
 * 
 * Esta classe modela objetos que formar�o a pilha sem�ntica.
 * 
 * @author Alexandre de Oliveira Zamberlam
 * @author Ana Carolina S. S. Jaskulski
 * @author Carlos S�rgio Schneider
 * @author Fernando Oscar Korndorfer
 * @author Mariana Kreisig 
 * @author Paulo Roberto Ferreira Jr.
 * @author Ricardo Ferreira de Oliveira
 * @author Thiago Glaser
 * @author Lucas Eskeff Freitas
 * 
 * @see Semantico
 * @see PilhaSemantica
 * @see ErroSemanticoException
 * 
 * @version 2.6.2
 */
public class NodoPilhaSemantica {
	
	private String codigo;
	private int tipoAssociado;
	private int regraQueEmpilhou;
	
	public NodoPilhaSemantica( String c, int t, int r ) {

		codigo = c;
		tipoAssociado = t;
		regraQueEmpilhou = r;
	}
	
	/**
	 * @return Retorna o c�digo objeto empilhado.
	 */
	public String getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo o c�digo a ser empilhado.
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return Retorna a regra que empilhou o c�digo.
	 */
	public int getRegraQueEmpilhou() {
		return regraQueEmpilhou;
	}
	/**
	 * @param regraQueEmpilhou numero da regra que empilhou o c�digo.
	 */
	public void setRegraQueEmpilhou(int regraQueEmpilhou) {
		this.regraQueEmpilhou = regraQueEmpilhou;
	}
	/**
	 * @return Retorna o tipo associado.
	 */
	public int getTipoAssociado() {
		return tipoAssociado;
	}
	/**
	 * @return Retorna o tipo associado.
	 */
	public String getDsTipoAssociado() {
		switch ( tipoAssociado ) {
		case Lexico.T_INTEIRO: return "T_INTEIRO"; 
		case Lexico.T_CARACTER: return "T_CARACTER"; 
		case Lexico.T_LOGICO: return "T_LOGICO"; 
		default: return "T_DESCONHECIDO";
		}
	}
	/**
	 * @return Retorna o tipo associado.
	 */
	public String getDescricaoTipo() {
		switch ( tipoAssociado ) {
		case Lexico.T_INTEIRO: return "Inteiro"; 
		case Lexico.T_CARACTER: return "Caracter"; 
		case Lexico.T_LOGICO: return "L�gico"; 
		default: return "Desconhecido";
		}
	}
	/**
	 * @param tipoAssociado o tipo associado ao c�digo.
	 */
	public void setTipoAssociado(int tipoAssociado) {
		this.tipoAssociado = tipoAssociado;
	}
}
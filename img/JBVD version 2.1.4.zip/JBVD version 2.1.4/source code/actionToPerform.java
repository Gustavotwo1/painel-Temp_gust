package jbvd;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import javax.swing.text.*;


public class actionToPerform implements ActionListener{

    private static final StyleContext context = new StyleContext();
    private static final Style commentStyle = context.addStyle("reservedWordStyle", null);
    private static final Style stringStyle = context.addStyle("stringStyle", null);
    private static Boolean multiLineComment = false;
    private static final float[] darkGreen = Color.RGBtoHSB(255, 140, 0, null);

    static{
        commentStyle.addAttribute(StyleConstants.Foreground, Color.GRAY);
        stringStyle.addAttribute(StyleConstants.Foreground, Color.getHSBColor(darkGreen[0], darkGreen[1], darkGreen[2]));
    }

    private Main m;

    private String filePath;

    private String parentFilePath;

    private String fileName;

    private String packageName = null;

    public actionToPerform(Main m){
        this.m = m;
    }

    public String getFilePath(){
        return filePath;
    }

    public String getParentFilePath(){
        return parentFilePath;
    }

    public String getFileName(){
        return fileName;
    }

    public String getPackageName(){
        return packageName;
    }

    public void actionPerformed(ActionEvent e){
        JFileChooser fc = new JFileChooser();
        SourceCodeFileFilter filter = new SourceCodeFileFilter();
        fc.setFileFilter(filter);
        fc.setAcceptAllFileFilterUsed(false);
        JFrame frame2 = new JFrame();
        Container container2 = frame2.getContentPane();
        GridBagLayout gbl2 = new GridBagLayout();
        container2.setLayout(gbl2);
        JPanel fcPanel = new JPanel(new GridBagLayout());
        int returnVal = fc.showOpenDialog(fcPanel);
        Document doc1 = m.getTextArea().getDocument();
        Document doc2 = m.getBytecodeTextArea().getDocument();
        if(returnVal == 0){
            m.getTextArea().setText("");
            m.getBytecodeTextArea().setText("");
            filePath = fc.getSelectedFile().getAbsolutePath().replace("\\","/");
            parentFilePath = fc.getSelectedFile().getParent().replace("\\","/");
            int index = fc.getSelectedFile().getName().lastIndexOf('.');
            fileName = fc.getSelectedFile().getName().substring(0,index);
            File chosenFile = fc.getSelectedFile();
            m.getTextArea().setText("");
            if(chosenFile!=null){
            try{
                if(fc.getSelectedFile().getAbsolutePath().toLowerCase().endsWith("java")){
                    FileReader fr = new FileReader(chosenFile);
                    BufferedReader br = new BufferedReader(fr);
                    packageName = null;
                    int identation = 0;
                    String line = br.readLine();
                    if(line.lastIndexOf("{") == line.length() - 1){
                        identation += 3;
                    }
                    while(line != null){
                        String line2 = line; //attempting to get package name
                        if(line2.indexOf("package") == 0){
                            int ch = 7; // in order to move to the next character after the word package
                            while(line2.charAt(ch) == 32){
                                ch++;
                            }
                            int initIndex = ch;
                            while (line2.charAt(ch)!= '.' && line2.charAt(ch)!=';'){
                                ch++;
                            }
                            int endIndex = ch;
                            packageName = line2.substring(initIndex,endIndex);
                        }
                        if((line.indexOf('"')==-1) && (line.indexOf('\'')==-1)){
                            print(line, doc1);
                        }
                        else if((line.indexOf('"')!=-1) && ((line.charAt(line.indexOf('"')-1) != '\'') || (line.charAt(line.indexOf('"')+1) != '\''))){
                            String leftSubstring = line.substring(0, line.indexOf('"'));
                            if((multiLineComment == true)|| (leftSubstring.indexOf("//")!=-1)||((leftSubstring.indexOf("/*")!=-1) && (leftSubstring.indexOf("*/")==-1))){
                                print(line, doc1);
                            }
                            else{
                                print(leftSubstring, doc1);
                                line = line.substring(line.indexOf('"')+1);
                                if((line.indexOf('"')-1 < 0) || (line.charAt(line.indexOf('"')-1) != '\\') || ((line.charAt(line.indexOf('"')-1) == '\\') && (line.charAt(line.indexOf('\\')+1) == '\\') /* case "\\" */)){
                                    doc1.insertString(doc1.getLength(), '"'+line.substring(0,line.indexOf('"')+1), stringStyle);
                                }
                                else{
                                    doc1.insertString(doc1.getLength(), "\"", stringStyle);
                                    int i = line.indexOf('"');
                                    while(i>0 && line.charAt(i-1)== '\\'){
                                        doc1.insertString(doc1.getLength(), line.substring(0,i+1), stringStyle);
                                        line = line.substring(i+1);
                                        i = line.indexOf('"');
                                    }
                                    doc1.insertString(doc1.getLength(), line.substring(0,i+1), stringStyle);


                                }
                                line = line.substring(line.indexOf('"')+1);
                                continue; // in order to check for new strings in the right substring
                            }
                        }
                        else if(line.indexOf('\'')!=-1){
                            String leftSubstring = line.substring(0, line.indexOf('\''));
                            if((multiLineComment == true)|| (leftSubstring.indexOf("//")!=-1)||((leftSubstring.indexOf("/*")!=-1) && (leftSubstring.indexOf("*/")==-1))){
                                print(line, doc1);
                            }
                            else{
                                print(leftSubstring, doc1);
                                line = line.substring(line.indexOf('\'')+1);
                                doc1.insertString(doc1.getLength(), '\''+line.substring(0,line.indexOf('\'')+1), stringStyle);
                                line = line.substring(line.indexOf('\'')+1);
                                continue; // in order to check for new strings in the right substring
                            }
                        }
                        doc1.insertString(doc1.getLength(), "\n", null);
                        line = br.readLine();
                        if(line != null){
                            line = line.trim();
                            if(line.lastIndexOf("}") == line.length() - 1 || line.charAt(0) == '}'){
                                identation -= 3;
                            }
                            for(int i = 0; i < identation; i++){
                                doc1.insertString(doc1.getLength(), " ", null);
                            }
                            if(line.lastIndexOf("{") == line.length() - 1){
                                identation += 3;
                            }
                        }
                    }
                }
                BytecodeConversion bc = new BytecodeConversion(m);
                if(fc.getSelectedFile().getAbsolutePath().toLowerCase().endsWith("java")){
                    bc.convertToBytecode(doc2);
                }
                else{
                    JavaConversion jc = new JavaConversion(m);
                    bc.convertToBytecode(doc2);
                    jc.convertToJava();
                }
            }
            catch (FileNotFoundException fnfe){
            }
            catch (IOException ioe){

            }
            catch(Exception ne){
            }
            }
        }
    }

    private void print(String line, Document doc1) throws Exception{
        if((line.indexOf("/*")!=-1) && (line.indexOf("/*")!=0) && (line.indexOf("*/")!=-1)){
            print(line.substring(0, line.indexOf("/*")), doc1);
            print(line.substring(line.indexOf("/*"),line.indexOf("*/")+2), doc1);
            print(line.substring(line.indexOf("*/")+2), doc1);
        }
        else if(line.indexOf("//")!= -1){  //single line comments
            ReservedWordsPrinter.printLine(line.substring(0, line.indexOf("//")), doc1);
            int index = line.indexOf("//")-1;
            doc1.insertString(doc1.getLength(), line.substring(index < 0 ? 0 : index), commentStyle);
        }
        else if(line.indexOf("/*")!=-1 && line.indexOf("*/")==-1){ //multiline comments
            multiLineComment = true;
            ReservedWordsPrinter.printLine(line.substring(0, line.indexOf("/*")), doc1);
            int index = line.indexOf("/*")-1;
            doc1.insertString(doc1.getLength(), line.substring(index < 0 ? 0 : index), commentStyle);
        }
        else if (line.indexOf("*/")!=-1){
            multiLineComment = false;
            doc1.insertString(doc1.getLength(), line.substring(0,line.indexOf("*/")+2), commentStyle);
            ReservedWordsPrinter.printLine(line.substring(line.indexOf("*/")+2), doc1);
        }
        else{
            if(multiLineComment == false){
                ReservedWordsPrinter.printLine(line, doc1);
            }
            else{
                doc1.insertString(doc1.getLength(), line, commentStyle);
            }
        }

    }

}

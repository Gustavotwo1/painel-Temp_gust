package jbvd;

import java.awt.*;
import javax.swing.*;

public class Main {

    private JTextPane sourceCode;

    private JTextPane byteCode;

    private actionToPerform action;

    private JFrame frame;


    public JTextPane getTextArea(){
        return this.sourceCode;
    }

    public JTextPane getBytecodeTextArea(){
        return this.byteCode;
    }

    public actionToPerform getAction(){
        return action;
    }

    public JFrame getFrame(){
        return frame;
    }

    public static void main(String[] args) {

        Main m = new Main();
        m.frame = new JFrame();
        m.frame.setResizable(false);
        m.frame.setTitle("JBVD - Java Bytecode Viewer & Decompiler - Developed By Nicole Tryfona");
        Container container = m.frame.getContentPane();
        GridBagLayout gbl = new GridBagLayout();
        container.setLayout(gbl);
        JPanel classPanel = new JPanel(new BorderLayout());
        classPanel.setBorder(BorderFactory.createTitledBorder("Class Source Code"));
        classPanel.setPreferredSize(new Dimension(500,500));
        JPanel bytecodePanel = new JPanel(new BorderLayout());
        bytecodePanel.setBorder(BorderFactory.createTitledBorder("Class Bytecode"));
        bytecodePanel.setPreferredSize(new Dimension(500,500));
        //Scrolling is controlled by the implementation of the Scrollable interface.
        //By overriding the getScrollableTracksViewportWidth() method we can achieve a
        //non-wrapping text pane:
        m.sourceCode = new JTextPane(){
            @Override
            public boolean getScrollableTracksViewportWidth()
                {
                    return getUI().getPreferredSize(this).width
                        <= getParent().getSize().width;
                }
        };
        m.sourceCode.setEditable(false);
        JScrollPane pane1 = new JScrollPane(m.sourceCode);
        pane1.setMinimumSize(new Dimension(487,467));
        classPanel.add(pane1);
        m.byteCode = new JTextPane(){
            @Override
            public boolean getScrollableTracksViewportWidth()
                {
                    return getUI().getPreferredSize(this).width
                        <= getParent().getSize().width;
                }
        };
        m.byteCode.setEditable(false);
        JScrollPane pane2 = new JScrollPane(m.byteCode);
        pane2.setMinimumSize(new Dimension(487, 467));
        bytecodePanel.add(pane2);
        container.add(classPanel);
        container.add(bytecodePanel);
        JButton button = new JButton("File Selection");
        m.action = new actionToPerform(m);
        button.addActionListener(m.action);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridwidth = 2;
        c.weighty = 4;
        c.anchor = GridBagConstraints.CENTER;
        c.insets = new Insets(10,0,10,0);
        container.add(button, c);
        m.frame.pack();
        m.frame.setVisible(true);
        m.frame.setLocationRelativeTo(null);
        m.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}

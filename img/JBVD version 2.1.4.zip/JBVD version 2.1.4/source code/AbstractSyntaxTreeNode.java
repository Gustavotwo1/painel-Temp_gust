/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jbvd;

/**
 *
 * @author ΝΙΚΟΛΕΤΑ
 */
public class AbstractSyntaxTreeNode {

    private int pcValue;
    private String data;
    private AbstractSyntaxTreeNode left;
    private AbstractSyntaxTreeNode right;

    AbstractSyntaxTreeNode(int pcValue){
        this.pcValue = pcValue;
        data = null;
        left = right = null;
    }

    AbstractSyntaxTreeNode(int pcValue, String data){
        this.pcValue = pcValue;
        this.data = data;
        left = right = null;
    }

    AbstractSyntaxTreeNode(int pcValue, AbstractSyntaxTreeNode left, AbstractSyntaxTreeNode right){
        this.pcValue = pcValue;
        this.right = right;
        this.left = left;
    }

    AbstractSyntaxTreeNode(int pcValue, String data, AbstractSyntaxTreeNode left, AbstractSyntaxTreeNode right){
        this.pcValue = pcValue;
        this.data = data;
        this.right = right;
        this.left = left;
    }

    public void setPcValue(int pcValue){
        this.pcValue = pcValue;
    }

    public int getPcValue(){
        return this.pcValue;
    }

    public void setData(String data){
        this.data = data;
    }

    public String getData(){
        return this.data;
    }

    public void setLeft(AbstractSyntaxTreeNode left){
        this.left = left;
    }

    public AbstractSyntaxTreeNode getLeft(){
        return this.left;
    }

    public void setRight(AbstractSyntaxTreeNode right){
        this.right = right;
    }

    public AbstractSyntaxTreeNode getRight(){
        return this.right;
    }

}

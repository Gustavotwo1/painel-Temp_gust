package jbvd;

import javassist.*;
import javassist.bytecode.*;
import java.util.*;
import java.lang.reflect.Method;
import javax.swing.text.*;
import java.awt.Color;

public class JavaConversion {

    private Main m;

    private static final StyleContext context = new StyleContext();
    private static final Style reservedWordStyle = context.addStyle("reservedWordStyle", null);
    private static final HashMap <String, String> dataTypes = new HashMap<String, String>();

    static{
        reservedWordStyle.addAttribute(StyleConstants.Foreground, Color.BLUE);
        dataTypes.put("I", "int");
        dataTypes.put("J", "long");
        dataTypes.put("L", "long");
        dataTypes.put("D", "double");
        dataTypes.put("F", "float");
        dataTypes.put("S", "short");
        dataTypes.put("B", "byte");
        dataTypes.put("Z", "boolean");
        dataTypes.put("C", "char");
    }
    
    private HashMap<Integer, Object[]> varTypes = new HashMap<Integer, Object[]>();
    private LinkedHashMap<Integer, String> instructions = new LinkedHashMap<Integer, String>();
    private Iterator iterator;
    private int currentPC;
    private int currentVar;
    private int currentException;
    private int exceptionIndex;
    private Stack operandStack = new Stack();
    private Stack<Integer> lowerPCValues = new Stack<Integer>();
    private ArrayList<Integer> rightBracketList = new ArrayList<Integer>();
    private Stack<AbstractSyntaxTreeNode[]> branchNodeStack = new Stack<AbstractSyntaxTreeNode[]>();
    private Stack<AbstractSyntaxTreeNode[]> gotoNodeStack = new Stack<AbstractSyntaxTreeNode[]>();
    private HashMap<Integer, AbstractSyntaxTreeNode> breakNodes = new HashMap<Integer, AbstractSyntaxTreeNode>();
    private LinkedList<AbstractSyntaxTreeNode[]> caseNodeList = new LinkedList<AbstractSyntaxTreeNode[]>();
    private String currentInstruction = null;
    private String previousInstruction = null;
    private String bytecode = null;
    private String action = null;
    private String symbol = null;
    private AbstractSyntaxTree tree;
    private AbstractSyntaxTreeNode previousNode;

    public JavaConversion(Main m){
        this.m = m;
    }

    public void convertToJava()throws Exception{
        Document doc = m.getTextArea().getDocument();
        ClassPool cp = new ClassPool();
        cp.insertClassPath(m.getAction().getParentFilePath());
        CtClass cc = cp.get(m.getAction().getFileName());
        ClassFile cf = cc.getClassFile();
        String className = cf.getName();
        String packageName = " ";
        varTypes = new HashMap<Integer, Object[]>();
        while(className.indexOf(".")!=-1){
            packageName = packageName.concat(className.substring(0,className.indexOf(".")+1));
            className = className.substring(className.indexOf(".")+1);
        }
        if(!packageName.equalsIgnoreCase(" ")){
            packageName=packageName.substring(0,packageName.length()-1);
            doc.insertString(doc.getLength(), "package", reservedWordStyle);
            doc.insertString(doc.getLength(), packageName+";\n\n", null);
        }
        Object[] imports = cc.getRefClasses().toArray();
        for(int i=0;i<imports.length;i++){
            String temp=(String)imports[i];
            if(temp.indexOf("lang")==-1 && !temp.equalsIgnoreCase(cf.getName())){
                doc.insertString(doc.getLength(), "import ", reservedWordStyle);
                doc.insertString(doc.getLength(), temp+";\n", null);
            }
        }
        if(imports.length > 0){
            doc.insertString(doc.getLength(), "\n", null);
        }
        String accessFlags = Modifier.toString(cf.getAccessFlags());
        int index = accessFlags.indexOf("synchronized");
        if(index!=-1){
            accessFlags = accessFlags.substring(0,index);
        }
        doc.insertString(doc.getLength(), accessFlags+" ", reservedWordStyle);
        if(index!=-1){
            doc.insertString(doc.getLength(), "class ", reservedWordStyle);
        }
        doc.insertString(doc.getLength(), className, null);
        if(cf.getSuperclass()!=null && !cf.getSuperclass().equalsIgnoreCase("java.lang.Object")){
            doc.insertString(doc.getLength(), " extends ", reservedWordStyle);
            doc.insertString(doc.getLength(), cf.getSuperclass(), null);
        }
        if(cf.getInterfaces().length!=0){
            doc.insertString(doc.getLength(), " implements", reservedWordStyle);
            for(int i=0;i<cf.getInterfaces().length;i++){
                 doc.insertString(doc.getLength(), " "+cf.getInterfaces()[i], null);
            }
        }
        doc.insertString(doc.getLength(), "{\n\n", null);
        List list = cf.getFields();
        int n = list.size();
        for(int i=0; i<n; i++){
            FieldInfo finfo = (FieldInfo)list.get(i);
            int acc = finfo.getAccessFlags();
            doc.insertString(doc.getLength(), "   "+Modifier.toString(AccessFlag.toModifier(acc)), reservedWordStyle);
            String descriptor = finfo.getDescriptor();
            int isArray = 0;
            if(descriptor.indexOf('[')!=-1){
                isArray=1;
                descriptor = descriptor.substring(1);
            }
            if(dataTypes.get(descriptor)!=null){
                doc.insertString(doc.getLength(), " " + dataTypes.get(descriptor), reservedWordStyle);
            }
            else{
                int index2 = descriptor.indexOf("/");
                while(index2!=-1){
                    descriptor = descriptor.substring(index2+1);
                    index2 = descriptor.indexOf("/");
                }
                if(descriptor.indexOf(";")!=-1){
                    descriptor = descriptor.substring(0,descriptor.length()-1);
                }
                doc.insertString(doc.getLength(), " "+descriptor, reservedWordStyle);
            }
            if(isArray==1){
                    doc.insertString(doc.getLength(), "[ ]", null);
            }
            doc.insertString(doc.getLength(), " "+finfo.getName()+";\n", null);
        }
        doc.insertString(doc.getLength(), "\n", null);
        CtConstructor[] constructors = cc.getDeclaredConstructors();
        for(int i=0;i<constructors.length;i++){
            MethodInfo minfo = constructors[i].getMethodInfo();
            printMethod(cc, cp, minfo, doc, true, className);

        }
        list = cf.getMethods();
        n = list.size();
        for (int i = 0; i < n; ++i) {
            MethodInfo minfo = (MethodInfo)list.get(i);
            if(!minfo.getName().equalsIgnoreCase("<init>")){
                printMethod(cc, cp, minfo, doc, false, className);
            }
        }
        doc.insertString(doc.getLength(), "\n}", null);

    }

    public void disassembler(CtClass cc, MethodInfo minfo, Document doc)throws Exception{
        currentPC = 0;
        currentVar = -1;
        currentException = 0;
        exceptionIndex = 0;
        operandStack = new Stack();
        branchNodeStack = new Stack <AbstractSyntaxTreeNode[]>();
        gotoNodeStack = new Stack <AbstractSyntaxTreeNode[]>();
        breakNodes = new HashMap <Integer, AbstractSyntaxTreeNode>();
        currentInstruction = null;
        previousInstruction = currentInstruction;
        bytecode = null;
        action = null;
        symbol = null;
        tree = new AbstractSyntaxTree(-1,null);
        previousNode = tree.getRoot();
        CodeAttribute code = minfo.getCodeAttribute();
        ExceptionTable e = code.getExceptionTable();

        ArrayList<Object []> sortedExceptions = this.exceptionTableSorting(e);

        while(iterator.hasNext()){
            currentPC = (Integer) iterator.next();
            currentInstruction = instructions.get(currentPC);
            if(currentInstruction.indexOf(" ")!=-1){
                bytecode = currentInstruction.substring(0, currentInstruction.indexOf(" "));
            }
            else{
                bytecode = currentInstruction;
            }

            action = (SymbolTable.symbolTable.get(bytecode))[0];
            symbol = (SymbolTable.symbolTable.get(bytecode))[1];

            if(exceptionIndex < sortedExceptions.size()){
                exceptionHandling(sortedExceptions, e, cc);
            }
            if(!action.equalsIgnoreCase("noAction")){
                Method method = JavaConversion.class.getDeclaredMethod(action+"Action");
                method.invoke(this);
            }
            previousInstruction = currentInstruction;
            if(action.equalsIgnoreCase("desynchronize")){
                continue;
            }
            System.out.println(currentPC + "\n");
            iterator.remove();
        }
        tree.printTree(doc);

    }

    private ArrayList <Object []> exceptionTableSorting(ExceptionTable e){
        ArrayList <Object []> sortedExceptions = new ArrayList <Object []>();
        for(int i=0; i < e.size(); i++){
            if(e.startPc(i) != e.handlerPc(i)){
                sortedExceptions.add(new Object[]{e.startPc(i), i});
                sortedExceptions.add(new Object[]{e.endPc(i), i});
                sortedExceptions.add(new Object[]{e.handlerPc(i),i});
            }
        } 
        bubbleSort(sortedExceptions);
        for (int i=0; i<sortedExceptions.size(); i++){
            System.out.println(sortedExceptions.get(i)[0]+" "+sortedExceptions.get(i)[1]);
        }
        return sortedExceptions;

    }

    private void bubbleSort(ArrayList <Object []> sortedExceptions){
        int j;
        boolean flag = true;
        Object[] temp;
        while (flag) {
            flag = false;
            for(j = 0; j < sortedExceptions.size() - 1; j++){
                if((Integer)sortedExceptions.get(j)[0] > (Integer)sortedExceptions.get(j+1)[0]){
                    temp = sortedExceptions.get(j);
                    sortedExceptions.set(j, sortedExceptions.get(j+1));
                    sortedExceptions.set(j+1, temp);
                    flag = true;
                }
            }
        }
    }

    private void exceptionHandling(ArrayList <Object []> sortedExceptions, ExceptionTable e, CtClass cc){
        Object[] object = sortedExceptions.get(exceptionIndex);
        int value = (Integer)object[0];
        int index = (Integer)object[1];
        int type = e.catchType(index);
        if(value == e.startPc(index)){
            // eliminating multiple starts in case there is an end or handle with the same value
            int tempExceptionIndex = exceptionIndex + 1;
            Object[] nextObject = sortedExceptions.get(tempExceptionIndex);
            int nextValue = (Integer)nextObject[0];
            int nextIndex = (Integer)nextObject[1];
            while(value == nextValue){
                if(nextValue != e.startPc(nextIndex)){
                    object = nextObject;
                    value = nextValue;
                    index = nextIndex;
                    exceptionIndex = tempExceptionIndex;
                    break;
                }
                else{
                    tempExceptionIndex++;
                    nextObject = sortedExceptions.get(tempExceptionIndex);
                    nextValue = (Integer)nextObject[0];
                    nextIndex = (Integer)nextObject[1];
                }
            }
        }
        String currentExceptionType = cc.getClassFile().getConstPool().getClassInfo(type);
        if(currentPC == value){
            if(value == e.startPc(index)){
                AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, "try{", null, null);
                tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
                previousNode = currentNode;
                //checking for nested try blocks
                do{
                    exceptionIndex++;
                    int nextIndex = (Integer)sortedExceptions.get(exceptionIndex)[1];
                    if(value == ((Integer)sortedExceptions.get(exceptionIndex)[0]).intValue() && e.endPc(index) != e.endPc(nextIndex) && e.catchType(nextIndex) != 0){
                        currentNode = new AbstractSyntaxTreeNode(currentPC, "try{", null, null);
                        tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
                        previousNode = currentNode;
                    }
                }while(value == ((Integer)sortedExceptions.get(exceptionIndex)[0]).intValue());
            }
            else if(value == e.endPc(index)){
                AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, "}", null, null);
                tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
                previousNode = currentNode;
                action = "noAction";
                exceptionIndex++;
                // after an "end" there must be only a non-null "handle" with the same index or with a smaller startPC
                Object[] nextObject = sortedExceptions.get(exceptionIndex);
                int nextValue = (Integer) nextObject[0];
                int nextIndex = (Integer) nextObject[1];
                if(nextValue != e.handlerPc(nextIndex)){
                    while((index != nextIndex && nextValue != e.handlerPc(index)) && !(e.startPc(nextIndex) < e.startPc(index) && e.catchType(nextIndex) != 0)){
                        nextObject = sortedExceptions.get(++exceptionIndex);
                        nextValue = (Integer) nextObject[0];
                        nextIndex = (Integer) nextObject[1];
                    }
                }
            }
            else if(value == e.handlerPc(index)){
                AbstractSyntaxTreeNode currentNode = null;
                if(currentExceptionType != null){
                    currentExceptionType = currentExceptionType.substring(currentExceptionType.lastIndexOf(".") + 1);
                    currentNode = new AbstractSyntaxTreeNode(currentPC, "catch(" + currentExceptionType + " e" + (++currentException) + "){", null, null);
                    if(exceptionIndex == sortedExceptions.size()-1 || (Integer)sortedExceptions.get(exceptionIndex+1)[0] != value){
                        //AbstractSyntaxTreeNode endingNode = new AbstractSyntaxTreeNode(Integer.parseInt(instructions.get(idx - 1).toString().substring(5)), "}", null, null);
                        AbstractSyntaxTreeNode endingNode = new AbstractSyntaxTreeNode(Integer.parseInt(previousInstruction.substring(5)), "}", null, null);
                        currentNode.setRight(endingNode);
                    }
                }
                else{
                    currentNode = new AbstractSyntaxTreeNode(currentPC, "finally{", null, null);
                    //AbstractSyntaxTreeNode endingNode = new AbstractSyntaxTreeNode(Integer.parseInt(instructions.get(idx - 1).toString().substring(5)), "}", null, null);
                    AbstractSyntaxTreeNode endingNode = new AbstractSyntaxTreeNode(Integer.parseInt(previousInstruction.substring(5)), "}", null, null);
                    currentNode.setRight(endingNode);
                }
                tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
                previousNode = currentNode;
                action = "noAction";
                do{
                    exceptionIndex++;
                }while(exceptionIndex < sortedExceptions.size() && value == ((Integer)sortedExceptions.get(exceptionIndex)[0]).intValue());
            }
        }
        else if(currentPC < value){
            if(value == e.handlerPc(index)){
                action = "noAction";
            }
        }
        else{
            exceptionIndex++;
        }
    }

    
    private void pushAction(){
        //the symbol represents the value to be pushed
        if(symbol == null){
            operandStack.push("var" + currentInstruction.substring(currentInstruction.indexOf(" ") + 1));
        }
        else if(symbol.equalsIgnoreCase("[")){ //the variable to be pushed is an array cell
            String index = operandStack.pop().toString();
            String arrayref = operandStack.pop().toString();
            operandStack.push(arrayref + "[" + index + "]");
        }
        else if(symbol.equalsIgnoreCase("-")){ //bipush, sipush, iconst, lconst case
            operandStack.push(currentInstruction.substring(currentInstruction.indexOf(" ") + 1));
        }
        else{ //symbol!=null
            if(symbol.equalsIgnoreCase("this")){
                if(varTypes.get(0)!=null){
                    symbol = "var0";
                }
            }
            operandStack.push(symbol);
        }
    }

    private void popAction(){
        AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
        currentNode.setData(operandStack.pop().toString() + ";");
        tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
        previousNode = currentNode;
    }
    
    private void operationAction(){
        //the symbol represents the operation type
        String op1 = operandStack.pop().toString();
        String op2 = operandStack.pop().toString();
        operandStack.push("(" + op1 + symbol + op2 + ")");
    }

    private void storeAction(){
        //the symbol represents the variable type
        String value = operandStack.pop().toString();
        //AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
        //tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
        //previousNode = currentNode;
        if(symbol != null && (!symbol.equalsIgnoreCase("["))){
            AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
            tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
            previousNode = currentNode;
            int index = Integer.parseInt(currentInstruction.substring(7));
            if(currentVar < index){
                currentVar = index;
                currentNode.setData(symbol + " var" + index + " = " + value + ";");
                varTypes.put(index, new Object[]{null, null});
            }
            else{
                if(varTypes.get(index) != null){
                    currentNode.setData("var" + index + " = " + value + ";");
                }
                else{
                    currentNode.setData(symbol + " var" + index + " = " + value + ";");
                    varTypes.put(index, new Object[]{null, null});
                }
            }
        }
        else if(symbol != null){ //the variable is an array cell
            String index = operandStack.pop().toString();
            String arrayref = operandStack.pop().toString();
            if(arrayref.startsWith("new")){
                arrayref = arrayref.replaceAll("\\[[0-9]*\\]", "[ ]");
                if(arrayref.contains("{")){
                    operandStack.push(arrayref.substring(0, arrayref.length()-1) + "," + value + "}");
                }
                else{
                    operandStack.push(arrayref + "{" + value + "}");
                }
            }
            else{
                AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
                tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
                currentNode.setData(arrayref + "[" + index + "] = " + value + ";");
            }
        }
        else{ // astore case
            if(value.contains("{new")){
                value = value.replaceAll("\\{new [a-zA-Z]*[\\[ \\]]*", "{");
                value = value.replaceAll(",new [a-zA-Z]*[\\[ \\]]*", ",");
            }
            AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
            tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
            previousNode = currentNode;
            int index = Integer.parseInt(currentInstruction.substring(7));
            if(currentVar < index || varTypes.get(index)== null){
                if(value.indexOf('"') == 0){
                    varTypes.put(index, new Object[]{currentNode, "String"});
                    currentNode.setData("String var" + index + " = " + value + ";");
                }
                else if(value.equalsIgnoreCase("null")){
                    varTypes.put(index, new Object[]{currentNode, "Object"});
                    currentNode.setData("Object var" + index + " = " + value + ";");
                }
                else if(value.indexOf("new") == 0) {
                    String type = value.toString();
                    if(type.indexOf("{") != -1){
                        type = type.substring(type.indexOf(" ") + 1, type.indexOf("{"));
                    }
                    else if(type.indexOf("[") != -1){
                        String type2 = type.substring(type.indexOf(" ") + 1, type.indexOf("["));
                        for(int i = 1; i < type.length(); i++){
                            if(type.charAt(i) == '['){
                                type2 = type2 + "[ ]";
                            }
                        }
                        type = type2;
                    }
                    else if(type.indexOf("(") != -1){
                        type = type.substring(type.indexOf(" ") + 1, type.indexOf("("));
                    }
                    currentNode.setData(type + " var" + index + " = " + value + ";");
                    varTypes.put(index, new Object[]{currentNode, type});
                }
                else if(value.contains("valueOf")){
                    String type = value.substring(0, value.indexOf('.'));
                    varTypes.put(index, new Object[]{currentNode, type});
                    currentNode.setData(type + " var" + index + " = " + value + ";");
                }
                else if (value.indexOf("var") == 0){
                    String index2 = value.substring(value.indexOf("r") + 1);
                    String type = null;
                    type = (String)(varTypes.get(Integer.parseInt(index2))[1]);        
                    currentNode.setData(type + " var" + index + " = " + value + ";");
                    varTypes.put(index, new Object[]{currentNode, type});
                }
                currentVar = index;
            }
            else{
                currentNode.setData("var" + index + " = " + value + ";");
                AbstractSyntaxTreeNode temp = (AbstractSyntaxTreeNode)(varTypes.get(index)[0]);
                previousNode = currentNode;
                if(value.indexOf('"') == 0){
                    value = "String";
                }
                else if(value.indexOf("var") == 0){
                    String index2 = value.substring(value.indexOf("r") + 1);
                    value = (String)(varTypes.get(Integer.parseInt(index2))[1]);
                }
                else{
                    if(value.indexOf(" ") != -1){
                        value = value.substring(value.indexOf(" ") + 1);
                    }
                    if(value.indexOf("(") != -1){
                        value = value.substring(0, value.indexOf("("));
                    }
                }
                if(temp!=null && !value.equalsIgnoreCase("null")){
                    temp.setData(temp.getData().substring(temp.getData().indexOf(" ")));
                    temp.setData(value + temp.getData());
                }
                if(!value.equalsIgnoreCase("null")){
                    varTypes.get(index)[1] = value;
                }
            }
        }
    }

    private void castAction(){
        //the symbol here represents the casting type
        String num = operandStack.pop().toString();
        operandStack.push("((" + symbol + ")" + num + ")");
    }
    
    private void newAction(){
        String className = null;
        if(currentInstruction.indexOf(".") != -1){
            className = currentInstruction.substring(currentInstruction.lastIndexOf(".") + 1);
        }
        else{
            className = currentInstruction.substring(currentInstruction.lastIndexOf(" ") + 1);
        }
        operandStack.push("new " + className);
    }

    private void  creationAction(){
        //the symbol represents whether the array is of a standard type or of a reference type
        String type = currentInstruction;
        if(currentInstruction.contains(symbol)){
            type = currentInstruction.substring(currentInstruction.lastIndexOf(symbol) + 1);
        }
        if(type.contains(";")){
            type = type.substring(0, type.indexOf(";"));
        }
        if(symbol.equalsIgnoreCase(".") && !currentInstruction.contains(symbol)){
            type = currentInstruction.substring(currentInstruction.lastIndexOf(" ") + 1);
            if(type.startsWith("[")){
                type = type.substring(type.lastIndexOf("[") + 1);
                if(dataTypes.containsKey(type)){
                    type = dataTypes.get(type);
                }
            }
        }
        for(int i=0; i < currentInstruction.length(); i++){
            if(currentInstruction.charAt(i) == '['){
                type = type + "[ ]";
            }
        }
        String length = operandStack.pop().toString();
        operandStack.push("new " + type + "[" + length + "]");
    }
    
    private void multiCreationAction(){
        String type = currentInstruction.substring(currentInstruction.lastIndexOf("[") + 1);
        int dimensions = 0;
        String dims = currentInstruction.substring(currentInstruction.indexOf("["));
        for(int j = 0; j < dims.length(); j++){
            if (dims.charAt(j) == '['){
                dimensions++;
            }
        }
        String formedDims = "";
        for(int j = 0; j < dimensions; j++) {
            formedDims = "[" + operandStack.pop() + "]" + formedDims;
        }
        String typeFormed = "";
        if(dataTypes.get(type) != null){
            typeFormed = dataTypes.get(type);
        }
        else{
            typeFormed = type.substring(type.lastIndexOf(".") + 1, type.length() - 1);
        }
        operandStack.push("new " + typeFormed + formedDims);
    }

    private void swapAction(){
        String op1 = operandStack.pop().toString();
        String op2 = operandStack.pop().toString();
        operandStack.push(op1);
        operandStack.push(op2);
    }

    private void singleOperationAction(){
        operandStack.push("(~"+operandStack.pop().toString()+")");
    }
    
    private void incrementAction(){
        int index = Integer.parseInt(currentInstruction.substring(currentInstruction.indexOf(" ") + 1, currentInstruction.lastIndexOf(" ")));
        int value = Integer.parseInt(currentInstruction.substring(currentInstruction.lastIndexOf(" ") + 1));
        AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
        tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
        previousNode = currentNode;
        if(value < 128){
            currentNode.setData("var" + index + "+= " + value + ";");
        }
        //else if(value < 256 && idx > 0 && !((String)instructions.get(idx-1)).equalsIgnoreCase("wide")){
        else if(value < 256 && previousInstruction != null && !previousInstruction.equalsIgnoreCase("wide")){
            value = 128 - (value - 128);
            currentNode.setData("var" + index + "-= " + value + ";");
        }
        else if(value < 32768){
            currentNode.setData("var" + index + "+= " + value + ";");
        }
        else{
            value = 32768 - (value - 32768);
            currentNode.setData("var" + index + "-= " + value + ";");
        }
    }

    private void lengthAction(){
        String arrayref = operandStack.pop().toString();
        operandStack.push(arrayref + ".length");
    }

    private void instanceAction(){
        operandStack.push(operandStack.pop()+" instanceof class");
    }

    private void throwAction(){
        String throwValue = operandStack.pop().toString();
        throwValue = throwValue.substring(3);
        if(varTypes.containsKey(Integer.parseInt(throwValue))){
            AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
            currentNode.setData("throw var" + throwValue + ";");
            tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
        }
    }
    
    private void returnAction(){
        Object obj = operandStack.pop();
        AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
        currentNode.setData("return " + obj + ";");
        tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
        previousNode = currentNode;
    }
    
    private void getFieldAction(){
        String field = currentInstruction.substring(currentInstruction.lastIndexOf(".") + 1);
        field = field.substring(0, field.indexOf("("));
        String ref = operandStack.pop().toString();
        operandStack.push(ref + "." + field);
    }

    private void putFieldAction(){
        String value = operandStack.pop().toString();
        String objectref = operandStack.pop().toString();
        String field = currentInstruction.substring(currentInstruction.lastIndexOf(".") + 1, currentInstruction.indexOf("("));
        AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
        tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
        previousNode = currentNode;
        currentNode.setData(objectref + "." + field + " = " + value + ";");
    }
    
    private void putStaticAction() throws Exception{
        String value = operandStack.pop().toString();
        String field = currentInstruction.substring(currentInstruction.lastIndexOf(".") + 1, currentInstruction.indexOf("("));
        String className = currentInstruction.substring(currentInstruction.lastIndexOf(" ") + 1, currentInstruction.lastIndexOf("."));
        ClassPool cp = new ClassPool();
        cp.insertClassPath(m.getAction().getParentFilePath());
        CtClass cc = cp.get(m.getAction().getFileName());
        ClassFile cf = cc.getClassFile();
        String classname = cf.getName();
        AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
        tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
        previousNode = currentNode;
        if(className.equalsIgnoreCase(classname)){
            currentNode.setData(field + " = " + value + ";");
        }
        else{
            currentNode.setData(className + "." + field + " = " + value + ";");
        }      
    }
    
    private void getStaticAction()throws Exception{
        String field = currentInstruction.substring(currentInstruction.lastIndexOf(".") + 1, currentInstruction.indexOf("("));
        String className = currentInstruction.substring(currentInstruction.lastIndexOf(" ") + 1, currentInstruction.lastIndexOf("."));
        if(className.indexOf(".") != -1){
            className = className.substring(className.lastIndexOf(".") + 1);
        }
        ClassPool cp = new ClassPool();
        cp.insertClassPath(m.getAction().getParentFilePath());
        CtClass cc = cp.get(m.getAction().getFileName());
        ClassFile cf = cc.getClassFile();
        String classname = cf.getName();
        if(className.equalsIgnoreCase(classname)){
            operandStack.push(field);
        }
        else{
            operandStack.push(className + "." + field);
        }
    }

    private void checkcastAction(){
        String className = currentInstruction.substring(currentInstruction.lastIndexOf(".") + 1);
        operandStack.push("(" + className + ")" + operandStack.pop());
    }
    
    private void invokeAction(){
        //the symbol represents the kind of method that gets invoked
        int numOfArgs = 0;
        String args = null;
        if(currentInstruction.lastIndexOf("(") != currentInstruction.indexOf(")") - 1){
            args = currentInstruction.substring(currentInstruction.lastIndexOf("(") + 1, currentInstruction.indexOf(")"));
        }
        if(args != null){
            int i = 0;
            char previousChar = '\0';
            while (i < args.length()) {
                if(!symbol.equalsIgnoreCase("special") && (args.charAt(i) >= 65 && args.charAt(i) <= 90 && previousChar != '/')){
                    numOfArgs++;
                }
                else if(args.charAt(i) >= 65 && args.charAt(i) <= 90 && previousChar != '/' && (previousChar < 97 || previousChar > 122)){
                    numOfArgs++;
                }
                previousChar = args.charAt(i);
                i++;
            }
        }
        if(currentInstruction.contains("util") && args != null && args.contains("Object")){  //to be fixed
            genericsHandling(numOfArgs);
        }
        args = "";
        for(int i = 0; i < numOfArgs; i++){
            args = operandStack.pop() + "," + args;
        }
        if(!args.equalsIgnoreCase("")) {
            args = args.substring(0, args.length() - 1);
        }
        if(!symbol.equalsIgnoreCase("special")){
            String method = currentInstruction.substring(currentInstruction.lastIndexOf(".") + 1, currentInstruction.indexOf("("));
            if(symbol.equalsIgnoreCase("virtual")){
                method = operandStack.pop() + "." + method + "(" + args + ")";
            }
            else{
                String className = currentInstruction.substring(0, currentInstruction.lastIndexOf("."));
                className = className.substring(className.lastIndexOf(".") + 1);
                method = className + "." + method + "(" + args + ")";
            }
            String returnType = currentInstruction.substring(currentInstruction.indexOf(")") + 1, currentInstruction.lastIndexOf(")"));
            if(returnType.equalsIgnoreCase("v")){
                AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
                currentNode.setData(method + ";");
                tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
                previousNode = currentNode;
            }
            else{
                operandStack.push(method);
            }
        }
        else{
            String className = null;
            className = currentInstruction.substring(0, currentInstruction.indexOf("<") - 1);
            className = className.substring(className.lastIndexOf(".") + 1);
            String temp0 = operandStack.pop().toString();
            if(temp0.equalsIgnoreCase("this")){
                AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
                currentNode.setData("super(" + args + ");");
                tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
                previousNode = currentNode;
            }
            else{
                //String temp = (operandStack.pop() + "(" + args + ")");
                String temp = (temp0 + "(" + args + ")");
                operandStack.push(temp);
            }
        }
    }

    private void genericsHandling(int numOfArgs){
        String newType = "";
        String delimiter = "";
        for(int i=1; i <= numOfArgs; i++){
            String newArg = operandStack.elementAt(operandStack.size() - i).toString();
            if(i > 1){
                delimiter = ", ";
            }
            if(newArg.startsWith("\"")){
                newType = "String" + delimiter + newType;
            }
            else if(newArg.contains(".valueOf")){
                newType = newArg.substring(0, newArg.indexOf('.')) + delimiter + newType;
            }
            else if(newArg.startsWith("new")){
                newArg = newArg.substring(newArg.indexOf(' ') + 1) + delimiter + newType;
                if(newArg.indexOf("(") != -1){
                    newArg = newArg.substring(0, newArg.indexOf('('));
                }
                else if(newArg.indexOf("[") != -1){
                    newArg = newArg.replaceAll("\\[[0-9]*\\]", "[ ]");
                }
                if(newArg.contains("{")){
                    newArg = newArg.substring(0, newArg.indexOf('{'));
                }
                newType = newArg + delimiter + newType;
            }
            else if (newArg.startsWith("var")){
                newType = varTypes.get(Integer.parseInt(newArg.substring(3)))[1].toString() + delimiter + newType;
            }
        }
        String [] newTypes = newType.split(",");
        for(int i = 0; i < newTypes.length; i++){
            newTypes[i] = newTypes[i].trim();
        }
        String variable = operandStack.elementAt(operandStack.size() - (numOfArgs + 1)).toString();
        String varIndex = variable.substring(3);
        AbstractSyntaxTreeNode nodeToChange = (AbstractSyntaxTreeNode) varTypes.get(Integer.parseInt(varIndex))[0];
        String oldType = varTypes.get(Integer.parseInt(varIndex))[1].toString();
        if(!oldType.contains("<")){ //to be fixed
            if(!oldType.contains(".") && !oldType.startsWith("int") && !oldType.startsWith("float") && !oldType.startsWith("char") && !oldType.startsWith("double") && !oldType.startsWith("byte") && !oldType.startsWith("long") && !oldType.startsWith("short") && !oldType.startsWith("boolean") && !oldType.startsWith("String")){
                nodeToChange.setData(nodeToChange.getData().replaceAll(varTypes.get(Integer.parseInt(varIndex))[1].toString(), varTypes.get(Integer.parseInt(varIndex))[1].toString() + "<" + newType + ">"));
                varTypes.get(Integer.parseInt(varIndex))[1] = varTypes.get(Integer.parseInt(varIndex))[1] + "<" + newType + ">";
            }
        }
        else{
            delimiter = "";
            newType = "";
            oldType = oldType.substring(oldType.indexOf('<') + 1, oldType.indexOf('>'));
            String[] oldTypes = oldType.split(",");
            for(int i = 0; i < oldTypes.length; i++){
                if(i > 0){
                    delimiter = ", ";
                }
                oldTypes[i] = oldTypes[i].trim();
                if(oldTypes[i].equalsIgnoreCase("Object") || !oldTypes[i].equalsIgnoreCase("Object") && !oldTypes[i].equalsIgnoreCase(newTypes[i])){
                    newTypes[i] = "Object";
                }
                newType = newType + delimiter + newTypes[i];
            }
            nodeToChange.setData(nodeToChange.getData().replace(oldType, newType));
            varTypes.get(Integer.parseInt(varIndex))[1] = varTypes.get(Integer.parseInt(varIndex))[1].toString().replace(oldType, newType);
        }


    }
    
    private void ldcAction(){
        String value = currentInstruction.substring(currentInstruction.indexOf("=") + 1).trim();
        value = escapeCharacters(value);
        if(value.charAt(0) != 34){
            if(value.indexOf(" ") != -1){
                value = value.substring(value.lastIndexOf(" ")).trim();
            }
        }
        operandStack.push(value);
    }

    protected static String escapeCharacters(String value){
        if(value.contains("\\")){
            value = value.replaceAll("\\\\", "\\\\\\\\");
        }
        if(value.contains("\n")){
            value = value.replaceAll("\\n", "\\\\n");
        }
        if(value.contains("\t")){
            value = value.replaceAll("\\t", "\\\\t");
        }
        if(value.contains("\r")){
            value = value.replaceAll("\\r", "\\\\r");
        }
        if(value.contains("\b")){
            value = value.replaceAll("\\b", "\\\\b");
        }
        if(value.contains("\f")){
            value = value.replaceAll("\\f", "\\\\f");
        }
        if(value.contains("\'")){
            value = value.replaceAll("\\'", "\\\\'");
        }
        /*if(value.indexOf("\"") != -1 && value.indexOf("\"") != 0 && value.indexOf("\"") != value.length()-1){
            value = value.substring(1, value.length()-1);
            value = value.replaceAll("\\", "\\\\");
            value = "\"" + value + "\"";
        }*/
        return value;

    }
    
    private void dupAction(){
        //the symbol represents the kind of duplication
        if(symbol == null){
            //operandStack.push(operandStack.peek());
        }
        else if(symbol.equalsIgnoreCase("x1")){
            operandStack.add(operandStack.size() - 3, operandStack.peek());
        }
        else if(symbol.equalsIgnoreCase("x2")){
            operandStack.add(operandStack.size() - 4, operandStack.peek());
        }
        else if(symbol.equalsIgnoreCase("2")){
            operandStack.push(operandStack.get(operandStack.size() - 2));
            operandStack.push(operandStack.get(operandStack.size() - 2));
        }
        else if(symbol.equalsIgnoreCase("2_x1")){
            operandStack.add(operandStack.size() - 4, operandStack.peek());
            operandStack.add(operandStack.size() - 5, operandStack.get(operandStack.size() - 2));
        }
        else if(symbol.equalsIgnoreCase("2_x2")){
            operandStack.add(operandStack.size() - 5, operandStack.peek());
            operandStack.add(operandStack.size() - 6, operandStack.get(operandStack.size() - 2));
        }
    }

    private void synchronizeAction(){
        //using previousNode as currentNode because the previous node is an astore node used internally for the monitorenter
        currentVar -= 1;
        exceptionIndex++; //skipping try block involved in synchronization
        previousNode.setData("synchronized(" + operandStack.pop() + "){");
    }

    private void desynchronizeAction(){
        exceptionIndex += 2; //skipping catch & finally blocks involved in synchronization
        operandStack.pop();
        AbstractSyntaxTreeNode currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
        tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
        previousNode = currentNode;
        currentNode.setData("}");
        currentPC = (Integer)iterator.next();
        currentInstruction = (String) instructions.get(currentPC);
        int gotoValue = Integer.parseInt(currentInstruction.substring(currentInstruction.indexOf(" ") + 1));
        iterator.remove();
        while(currentPC < gotoValue - 1){ //discard all instructions until athrow
            currentPC = (Integer)iterator.next();
            iterator.remove();
        }
    }

    private void branchAction(){
        if(symbol == null){ //fcmp, dcmp, lcmp bytecodes
            iterator.remove();
            currentPC = (Integer) iterator.next();
            currentInstruction = (String)instructions.get(currentPC);
            bytecode = currentInstruction.substring(0, currentInstruction.indexOf(" "));
            symbol = (SymbolTable.symbolTable.get(bytecode))[1];
            symbol = symbol.substring(1, symbol.lastIndexOf(" "));
        }
        int branchValue = Integer.parseInt(currentInstruction.substring(currentInstruction.indexOf(" ") + 1));
        AbstractSyntaxTreeNode currentNode = null;
        if((branchValue < currentPC) && !symbol.equalsIgnoreCase("goto")){ //do while case
            StringBuilder logicalOperator = new StringBuilder();
            StringBuilder leftBracket = new StringBuilder();
            StringBuilder rightBracket = new StringBuilder();
            currentNode = setCurrentDoWhileNode(branchValue, logicalOperator);
            if(currentNode == null){
                currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
                createLoopNode(currentNode, branchValue);
                tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
            }
            else{
                while(!rightBracketList.isEmpty() && rightBracketList.remove(Integer.valueOf(currentPC + 3))){
                    rightBracket.append(")");
                }
            }
            previousNode = currentNode;
            if(symbol.contains(" ")){ //cases if ifeq, ifne, iflt, ifgt, ifge, ifle, ifnull, ifnonnull
                setDoWhileNodeData(currentNode, leftBracket.toString() + operandStack.pop() + symbol + rightBracket.toString(), logicalOperator.toString());

            }
            else{
                String operand1 = operandStack.pop().toString();
                String operand2 = operandStack.pop().toString();
                setDoWhileNodeData(currentNode, leftBracket.toString() + operand2 + " " + symbol + " " + operand1 + rightBracket.toString(), logicalOperator.toString());
            }
        }
        else if((branchValue < currentPC) && symbol.equalsIgnoreCase("goto")){ //while case
            AbstractSyntaxTreeNode temp = branchNodeStack.pop()[0];
            temp.setData(temp.getData().replace("if", "while"));
            if(previousNode.getRight() != null && previousNode.getRight().getPcValue() < previousNode.getPcValue()){ //previous node is do while node
                currentNode = previousNode.getLeft();
            }
            else{
                currentNode = previousNode.getRight();
            }
            currentNode.setRight(temp);
            previousNode = temp; //going back to while node
        }
        else if(branchValue > currentPC && !symbol.equalsIgnoreCase("goto")){
            StringBuilder logicalOperator = new StringBuilder();
            StringBuilder leftBracket = new StringBuilder();
            StringBuilder rightBracket = new StringBuilder();
            currentNode = setCurrentIfNode(branchValue, logicalOperator, leftBracket, rightBracket);
            if(currentNode == null){
                currentNode = new AbstractSyntaxTreeNode(currentPC, null, null);
                AbstractSyntaxTreeNode endingBranchNode = new AbstractSyntaxTreeNode(branchValue, "}", null, null);
                branchNodeStack.push(new AbstractSyntaxTreeNode[]{currentNode, endingBranchNode});
                currentNode.setRight(endingBranchNode);
                tree.addNode(branchNodeStack, previousNode, currentNode, currentPC);
                previousNode = currentNode;
            }
            symbol = inverseRelationalOperator(symbol);
            if(symbol.contains(" ")){
                setIfNodeData(currentNode, leftBracket.toString() + operandStack.pop() + symbol + rightBracket.toString(), logicalOperator.toString());
            }
            else{
                String operand1 = operandStack.pop().toString();
                String operand2 = operandStack.pop().toString();
                setIfNodeData(currentNode, leftBracket.toString() + operand2 + " " + symbol + " " + operand1 + rightBracket.toString(), logicalOperator.toString());
            }
        }
        else{ //goto going forward
            AbstractSyntaxTreeNode[] caseNode = null;
            while(caseNodeList.size() != 0 && caseNodeList.peek()[0].getPcValue() < currentPC){
                caseNode = caseNodeList.pop();
            }
            if((caseNodeList.size() != 0 && caseNodeList.peek()[0].getPcValue() == currentPC + 3)
                    || caseNode != null && caseNode[1].getPcValue() == currentPC + 3){
                if(branchValue != caseNode[1].getPcValue()){ //there is a default case
                    AbstractSyntaxTreeNode currentCase = caseNode[0];
                    while(currentCase.getLeft() != caseNode[1]){
                        currentCase = currentCase.getLeft();
                    }
                    AbstractSyntaxTreeNode defaultCaseNode = new AbstractSyntaxTreeNode(caseNode[1].getPcValue(), null, null);
                    defaultCaseNode.setData("default :{");
                    caseNodeList.add(new AbstractSyntaxTreeNode[] {defaultCaseNode, caseNode[1]});
                    AbstractSyntaxTreeNode endingDefaultCaseNode = new AbstractSyntaxTreeNode(branchValue, "}", null, null);
                    defaultCaseNode.setRight(endingDefaultCaseNode);
                    endingDefaultCaseNode.setRight(caseNode[1]);
                    currentCase.setLeft(defaultCaseNode);
                    if(currentCase != caseNode[0]){
                        currentCase.getRight().setRight(defaultCaseNode);
                    }
                }
                AbstractSyntaxTreeNode breakNode = new AbstractSyntaxTreeNode(currentPC, "break;", null, null);
                tree.addNode(branchNodeStack, previousNode, breakNode, currentPC);
                AbstractSyntaxTreeNode endingCaseNode = breakNode.getRight();
                endingCaseNode.setRight(caseNode[1]);
                endingCaseNode.getRight().setPcValue(branchValue);
                previousNode = caseNode[0];
            }
            else{
                if(!gotoNodeStack.empty() && branchValue == gotoNodeStack.peek()[1].getPcValue()){//else if case
                    AbstractSyntaxTreeNode previousElseNode = gotoNodeStack.peek()[0];
                    AbstractSyntaxTreeNode ifNode = previousElseNode.getRight();
                    previousElseNode.setData("else " + ifNode.getData());
                    previousElseNode.setRight(ifNode.getRight());
                    previousElseNode.setLeft(ifNode.getLeft().getRight());
                    while(branchNodeStack.peek()[0] != ifNode){
                        if(branchNodeStack.peek()[0].getLeft() != null){
                            branchNodeStack.peek()[1].setRight(branchNodeStack.peek()[0].getLeft());
                        }
                        branchNodeStack.pop();
                    }
                    branchNodeStack.peek()[1].setLeft(ifNode.getLeft().getLeft());
                    ifNode.setLeft(null);
                    ifNode.setRight(null);
                    branchNodeStack.peek()[0] = previousElseNode;
                    gotoNodeStack.pop();
                }
                AbstractSyntaxTreeNode endingBranchNode = new AbstractSyntaxTreeNode(branchValue, "}", null, null);
                while(!branchNodeStack.empty() && branchNodeStack.peek()[1].getPcValue() <= branchValue){
                    if(branchNodeStack.peek()[0].getLeft() != null){
                        branchNodeStack.peek()[1].setRight(branchNodeStack.peek()[0].getLeft());
                    }
                    endingBranchNode.setLeft(branchNodeStack.peek()[1]);
                    currentNode = branchNodeStack.pop()[0];
                }
                AbstractSyntaxTreeNode elseNode = new AbstractSyntaxTreeNode(endingBranchNode.getLeft().getPcValue(), "else{", null, null);
                elseNode.setRight(endingBranchNode);
                endingBranchNode.setRight(currentNode.getLeft());
                currentNode.setLeft(elseNode);
                previousNode = endingBranchNode;
                while(previousNode.getLeft() != null && previousNode.getLeft().getPcValue() < previousNode.getPcValue()){
                    previousNode = previousNode.getLeft();
                    previousNode.setRight(endingBranchNode.getRight());
                }
                previousNode = elseNode;
                gotoNodeStack.push(new AbstractSyntaxTreeNode[]{elseNode, endingBranchNode});
            }
        }
    }

    private AbstractSyntaxTreeNode createLoopNode(AbstractSyntaxTreeNode currentNode, int branchValue){
        AbstractSyntaxTreeNode temp = tree.findNode(tree.getRoot(), branchValue);
        AbstractSyntaxTreeNode loopNode = new AbstractSyntaxTreeNode(branchValue, null, null, temp);
        AbstractSyntaxTreeNode whileNode = null;
        loopNode.setData("do{");
        if(temp == null){ //when the first statement is do...while
            tree.setRoot(loopNode);
        }
        else if(temp.getRight().getData().equalsIgnoreCase("do{") && (whileNode = findDoWhileNode(temp, currentNode)) != null){
            loopNode = temp.getRight();
            whileNode.setData(whileNode.getData().replace(");", " ||") + currentNode.getData().replace("}while(", " "));
            currentNode = whileNode;
            currentNode.setLeft(null);

        }
        else{
            loopNode.setRight(temp.getRight());
            temp.setRight(loopNode);
        }
        currentNode.setRight(loopNode);
        return currentNode;
    }

    private AbstractSyntaxTreeNode findDoWhileNode(AbstractSyntaxTreeNode temp, AbstractSyntaxTreeNode currentNode){
        AbstractSyntaxTreeNode current = temp.getRight();
        while(current.getRight() != temp.getRight()){
            if(current.getRight().getPcValue() < current.getPcValue()){
                current = current.getLeft();
            }
            else{
                current = current.getRight();
            }
        }
        if(current.getLeft() == currentNode){
            return current;
        }
        return null;
    }

    private AbstractSyntaxTreeNode setCurrentDoWhileNode(int branchValue, StringBuilder logicalOperator){
        AbstractSyntaxTreeNode currentNode = null;
        String operator = "";
        if(previousNode != null && previousNode.getData().startsWith("}while") && previousNode.getRight().getPcValue() == branchValue){
                currentNode = previousNode;
                operator = "||";
        }
        else if(previousNode.getData().startsWith("if") && previousNode.getRight().getPcValue() > branchValue){
            if(previousNode.getLeft() != null && previousNode.getLeft().getPcValue() > previousNode.getRight().getPcValue()){
                branchNodeConcatenation(branchValue);
            }
            operator = "&&";
            previousNode.setRight(null);
            previousNode.setData(previousNode.getData().replace("if", "}while").replace("{", ";"));
            currentNode = previousNode;
            currentNode = createLoopNode(currentNode, branchValue);
        }
        logicalOperator.append(operator);
        return currentNode;

    }

    private void setDoWhileNodeData(AbstractSyntaxTreeNode currentNode, String data, String logicalOperator){
        if(currentNode.getData() == null){
            currentNode.setData("}while(" + data + ");");
        }
        else{
            currentNode.setData(currentNode.getData().replace(");", " " + logicalOperator + " " + data + ");"));
        }
    }

    private AbstractSyntaxTreeNode setCurrentIfNode(int branchValue, StringBuilder logicalOperator, StringBuilder leftBracket, StringBuilder rightBracket){
        AbstractSyntaxTreeNode currentNode = null;
        String operator = "";
        int previousBranchValue = -1;
        if(previousNode != null && previousNode.getData().startsWith("if") && previousNode.getRight() != null){
            previousBranchValue = previousNode.getRight().getPcValue();
        }
        else if(previousNode == null || (previousNode != null && !previousNode.getData().startsWith("if"))){
            leftBracket.append("((");
            rightBracketList.add(branchValue);
            lowerPCValues.push(branchValue);
        }
        if(previousNode != null && previousNode.getData().startsWith("if") && previousNode.getLeft() != null && previousNode.getLeft().getPcValue() <= branchValue && !containsGotoStatement(branchValue, previousNode.getLeft().getPcValue())){
            branchNodeConcatenation(branchValue);
        }
        if(previousNode != null && previousNode.getData().startsWith("if") && previousBranchValue == branchValue){
            currentNode = previousNode;
            operator = "&&";
        }
        else if(previousNode != null && previousNode.getData().startsWith("if") && (previousBranchValue == currentPC + 3 || (previousBranchValue < branchValue && previousBranchValue > currentPC + 3)) && !containsGotoStatement(branchValue, previousBranchValue)){
            currentNode = previousNode;
            currentNode.getRight().setPcValue(branchValue);
            operator = "||";
        }
        logicalOperator.append(operator);
        if(branchValue < previousBranchValue){
            if(!rightBracketList.isEmpty() && !rightBracketList.contains(branchValue)){
                leftBracket.append("((");
                lowerPCValues.push(branchValue);
            }
            else{
                leftBracket.append("(");
            }
            rightBracketList.add(branchValue);
        }
        while(!lowerPCValues.empty() && lowerPCValues.peek() < branchValue){
            rightBracketList.add(branchValue);
            lowerPCValues.pop();
        }
        while(!rightBracketList.isEmpty() && rightBracketList.remove(Integer.valueOf(currentPC + 3))){
            rightBracket.append(")");
        }
        return currentNode;

    }

    private void branchNodeConcatenation(int branchValue){
        AbstractSyntaxTreeNode[] branchNode2 = branchNodeStack.pop();
        AbstractSyntaxTreeNode[] branchNode1 = branchNodeStack.pop();
        String operator = "&&";
        if(previousNode.getLeft().getPcValue() == branchValue){
            operator = "||";
        }
        String data = branchNode2[0].getData().replace("if(", "").replace("){", "");
        setIfNodeData(branchNode1[0], data, operator);
        branchNode1[0].setRight(branchNode1[1]);
        branchNodeStack.push(branchNode1);
        previousNode = branchNode1[0];
    }

    private boolean containsGotoStatement(int branchValue, int previousBranchValue){
        Iterator it = instructions.keySet().iterator();
        int key = (Integer)it.next();
        while(key < branchValue){
            if(instructions.get(key).startsWith("goto " + branchValue) && (previousBranchValue == key + 3 || previousBranchValue == branchValue)){
                return true;
            }
            key = (Integer)it.next();
        }
        return false;
    }

    private String inverseRelationalOperator(String operator){
        if (operator.contains("==")){
            operator = operator.replace("==", "!=");
        }
        else if (operator.contains("!=")){
            operator = operator.replace("!=", "==");
        }
        else if (operator.contains("<=")){
            operator = operator.replace("<=", ">");
        }
        else if (operator.contains(">=")){
            operator = operator.replace(">=", "<");
        }
        else if (operator.contains("<")){
            operator = operator.replace("<", ">=");
        }
        else if (operator.contains(">")){
            operator = operator.replace(">", "<=");
        }
        else if (operator.contains("&")){
            operator = operator.replace("&", "|");
        }
        else if (operator.contains("|")){
            operator = operator.replace("|", "&");
        }
        else{
            operator = null;
        }
        return operator;
    }

    private void setIfNodeData(AbstractSyntaxTreeNode currentNode, String data, String logicalOperator){
        if(currentNode.getData() == null){
            currentNode.setData("if(" + data + "){");
        }
        else{
            if(logicalOperator.equalsIgnoreCase("||")){
                char[] previousData = currentNode.getData().toCharArray();
                ArrayList<Character> newData = new ArrayList<Character>();
                int i = 0;
                for(i = 0; i < previousData.length-1; i++){
                    if(previousData[i] == ' '){
                        newData.add(previousData[i]);
                        continue;
                    }
                    String charsToCheck = String.copyValueOf(new char [] {previousData[i], previousData[i+1]});
                    String checkResult = inverseRelationalOperator(charsToCheck);
                    if(checkResult != null){
                        newData.add(checkResult.charAt(0));
                        if(checkResult.length() == 2){
                            newData.add(checkResult.charAt(1));
                        }
                        i++;
                    }
                    else{
                        newData.add(previousData[i]);
                    }
                }
                newData.add(previousData[i]);
                currentNode.setData("");
                for(i = 0; i < newData.size(); i++){
                    currentNode.setData(currentNode.getData() + newData.get(i));
                }
            }
            currentNode.setData(currentNode.getData().replace("){", " " + logicalOperator + " " + data + "){"));
        }
    }

    private void switchAction(){
        AbstractSyntaxTreeNode switchNode = new AbstractSyntaxTreeNode(currentPC, null, null);
        AbstractSyntaxTreeNode endSwitchNode = new AbstractSyntaxTreeNode(-1, null, null);
        endSwitchNode.setData("}aaa");
        AbstractSyntaxTreeNode currentNode = switchNode;
        currentNode.setData("switch(" + operandStack.pop() + "){");
        String[] cases = currentInstruction.split("\n");
        if(cases[1].contains("default")){
            String defaultCase = cases[1];
            for(int i = 1; i < cases.length - 1; i++){
                cases[i] = cases[i + 1];
            }
            cases[cases.length - 1] = defaultCase;
        }
        for(int i = 1; i < cases.length; i++){
            cases[i] = cases[i].substring(cases[i].lastIndexOf('\t') + 1);
            String[] values = cases[i].split(":");
            values[1] = values[1].substring(1);
            if(values[1].contains("}")){
                values[1] = values[1].substring(0, values[1].length() - 1);
            }
            if(Integer.parseInt(values[1]) == currentNode.getPcValue()){
                currentNode.setData(currentNode.getData().replace('{', ' '));
                currentNode.setData(currentNode.getData() + "case " + values[0] + ":{");
            }
            else{
                if(cases[i].startsWith("default")){
                    currentNode.getRight().setPcValue(Integer.parseInt(values[1]));
                    currentNode.getRight().setRight(endSwitchNode);
                    endSwitchNode.setPcValue(Integer.parseInt(values[1]));
                    currentNode.setLeft(endSwitchNode);
                }
                else{
                    AbstractSyntaxTreeNode newCaseNode = new AbstractSyntaxTreeNode(Integer.parseInt(values[1]), null, null);
                    newCaseNode.setData("case " + values[0] + ":{");
                    AbstractSyntaxTreeNode endingCaseNode = new AbstractSyntaxTreeNode(-1, "}", null, null);
                    newCaseNode.setRight(endingCaseNode);
                    caseNodeList.add(new AbstractSyntaxTreeNode[] {newCaseNode, endSwitchNode});
                    if(currentNode.getData().startsWith("case")){
                        currentNode.getRight().setPcValue(newCaseNode.getPcValue());
                        currentNode.setLeft(newCaseNode);
                        currentNode.getRight().setRight(newCaseNode);
                    } 
                    else{
                        currentNode.setRight(newCaseNode);
                    }
                    currentNode = newCaseNode;
                }
            }
        }
        tree.addNode(branchNodeStack, previousNode, switchNode, currentPC);
        previousNode = switchNode;
    }
    
    
    public void printMethod(CtClass cc, ClassPool cp, MethodInfo minfo, Document doc, Boolean isConstructor, String className) throws Exception{
        ExceptionsAttribute exa = minfo.getExceptionsAttribute();
        CodeAttribute code = minfo.getCodeAttribute();
        ExceptionTable e = code.getExceptionTable();
        for(int i =0; i<e.size(); i++){
            System.out.println(e.startPc(i)+"start");
            System.out.println(e.endPc(i)+"end");
            System.out.println(e.handlerPc(i)+"handler");
            System.out.println(cc.getClassFile().getConstPool().getClassInfo(e.catchType(i)));
        }
        String[] exceptions = null;
        if(exa!=null){
            exceptions = minfo.getExceptionsAttribute().getExceptions();
        }
        int acc = minfo.getAccessFlags();
        CtClass returnTypeClass = Descriptor.getReturnType(minfo.getDescriptor(),cp);
        String returnType = minfo.getDescriptor();
        if(returnTypeClass != null){
            returnType = Descriptor.getReturnType(minfo.getDescriptor(),cp).toString();
        }
        else{
            returnType = returnType.substring(returnType.lastIndexOf('/')+1, returnType.length()-1);
        }
        if(returnType != null && returnType.indexOf('[') != -1){
          returnType = returnType.substring(returnType.indexOf("[")+1,returnType.indexOf("]"));
        }
        if(isConstructor){
            doc.insertString(doc.getLength(), "   "+Modifier.toString(AccessFlag.toModifier(acc)), reservedWordStyle);
        }
        else{
            doc.insertString(doc.getLength(), "   "+Modifier.toString(AccessFlag.toModifier(acc))+ " "+ returnType+" ", reservedWordStyle);
        }
        if(isConstructor){
            doc.insertString(doc.getLength(), " " + className +"(", null);
        }
        else{
            doc.insertString(doc.getLength(), minfo.getName()+"(", null);
        }
        String arguments = minfo.getDescriptor().substring(1,minfo.getDescriptor().indexOf(")"));
        int i=0;
        int varCount = 1;
        if(Modifier.toString(AccessFlag.toModifier(acc)).contains("static")){ // static methods don't use this so astore_0 refers to var0
            varCount = 0;
        }
        int array = 0;
        while(i<arguments.length()){
            int firstCase = 0;
            int standardType = 0;
            if(i!= arguments.length()-1 && arguments.charAt(i+1)>=97 && arguments.charAt(i+1)<=122){
                String newArg = minfo.getDescriptor().substring(i);
                newArg = newArg.substring(0, newArg.indexOf(";"));
                i+=newArg.length();
                if(array != 1){
                    doc.insertString(doc.getLength(), newArg.substring(newArg.lastIndexOf("/")+1)+" var"+varCount, null);
                }
                else{
                    doc.insertString(doc.getLength(), newArg.substring(newArg.lastIndexOf("/")+1)+"[ ] var"+varCount, null);
                    array = 0;
                }
                varTypes.put(varCount, new Object[]{null, newArg.substring(newArg.lastIndexOf("/")+1)});
                firstCase = 1;
            }
            else if(arguments.charAt(i)=='['){
                array = 1;
                i++;
                continue;
            }
            else{
                if(array!=1){
                    doc.insertString(doc.getLength(), dataTypes.get(String.valueOf(arguments.charAt(i)))+" ", reservedWordStyle);
                }
                else{
                    doc.insertString(doc.getLength(), dataTypes.get(String.valueOf(arguments.charAt(i)))+"[ ] ", reservedWordStyle);
                }
                doc.insertString(doc.getLength(), "var"+varCount, null);
                varTypes.put(varCount, new Object[]{null, null});
                standardType = 1;
            }
            if((i<=arguments.length()-1 && standardType == 0) || (standardType == 1 && i<arguments.length()-1)){
                doc.insertString(doc.getLength(), ", ", null);
            }
            if(firstCase == 0){
                i++;
            }
            varCount++;
            standardType = 0;
        }
        doc.insertString(doc.getLength(), ")", null);
        if(exceptions!=null){
            doc.insertString(doc.getLength(), " throws ", reservedWordStyle);
            for(int j=0;j<exceptions.length-1;j++){
                doc.insertString(doc.getLength(), exceptions[j].substring(exceptions[j].lastIndexOf(".")+1)+", ", null);
            }
            doc.insertString(doc.getLength(), exceptions[exceptions.length-1].substring(exceptions[exceptions.length-1].lastIndexOf(".")+1)+"(){\n", null);
        }
        else{
            doc.insertString(doc.getLength(), "{\n", null);
        }
        CodeAttribute ca = minfo.getCodeAttribute();
        ConstPool pool = minfo.getConstPool();
        CodeIterator ci = ca.iterator();
        currentPC = 0;
        while(ci.hasNext()){
            int index2 = ci.next();
            String instruction = InstructionPrinter.instructionString(ci, index2, pool);
            if(instruction.startsWith("wide")){
                instruction = instruction.substring(5);
                instructions.put(currentPC, "wide");
                currentPC = currentPC + 3;
            }
            instructions.put(currentPC, instruction);
            if(instruction.indexOf(" ")!=-1){
                bytecode = instruction.substring(0, instruction.indexOf(" "));
            }
            else{
                bytecode = instruction;
            }
            currentPC = currentPC + calculatePC(bytecode,instruction, currentPC);
        }
        iterator = instructions.keySet().iterator();
        currentPC = 0;
        disassembler(cc, minfo, doc);
        doc.insertString(doc.getLength(), "   }\n\n", null);
    }

    public static int calculatePC(String bytecode, String currentInstruction, int currentPC){
        if(bytecode.equalsIgnoreCase("astore")||bytecode.equalsIgnoreCase("bipush")|| bytecode.equalsIgnoreCase("dload")){
            return 2;
        }
        if(bytecode.equalsIgnoreCase("dstore")||bytecode.equalsIgnoreCase("fload")|| bytecode.equalsIgnoreCase("fstore")){
            return 2;
        }
        if(bytecode.equalsIgnoreCase("iload")||bytecode.equalsIgnoreCase("istore")|| bytecode.equalsIgnoreCase("ldc")||bytecode.equalsIgnoreCase("lload")){
            return 2;
        }
        if(bytecode.equalsIgnoreCase("lstore")||bytecode.equalsIgnoreCase("aload")|| bytecode.equalsIgnoreCase("newarray")||bytecode.equalsIgnoreCase("ret")){
            return 2;
        }
        if(bytecode.equalsIgnoreCase("checkcast")||bytecode.equalsIgnoreCase("getfield")|| bytecode.equalsIgnoreCase("getstatic")||bytecode.equalsIgnoreCase("goto")){
            return 3;
        }
        if(bytecode.equalsIgnoreCase("if_acmpeq")||bytecode.equalsIgnoreCase("if_acmpne")|| bytecode.equalsIgnoreCase("if_icmpeq")||bytecode.equalsIgnoreCase("if_icmpne")){
            return 3;
        }
        if(bytecode.equalsIgnoreCase("if_icmplt")||bytecode.equalsIgnoreCase("if_icmpge")|| bytecode.equalsIgnoreCase("if_icmpgt")||bytecode.equalsIgnoreCase("if_icmple")){
            return 3;
        }
        if(bytecode.equalsIgnoreCase("ifeq")||bytecode.equalsIgnoreCase("ifne")|| bytecode.equalsIgnoreCase("iflt")||bytecode.equalsIgnoreCase("ifge")){
            return 3;
        }
        if(bytecode.equalsIgnoreCase("ifgt")||bytecode.equalsIgnoreCase("ifle")|| bytecode.equalsIgnoreCase("ifnonnull")||bytecode.equalsIgnoreCase("ifnull")){
            return 3;
        }
        if(bytecode.equalsIgnoreCase("iinc")||bytecode.equalsIgnoreCase("instanceof")|| bytecode.equalsIgnoreCase("invokespecial")||bytecode.equalsIgnoreCase("invokestatic")){
            return 3;
        }
        if(bytecode.equalsIgnoreCase("invokevirtual")||bytecode.equalsIgnoreCase("jsr")|| bytecode.equalsIgnoreCase("ldc_w")||bytecode.equalsIgnoreCase("ldc2_w")){
            return 3;
        }
        if(bytecode.equalsIgnoreCase("anewarray")||bytecode.equalsIgnoreCase("new")|| bytecode.equalsIgnoreCase("putfield")||bytecode.equalsIgnoreCase("putstatic")||bytecode.equalsIgnoreCase("sipush")){
            return 3;
        }
        if(bytecode.equalsIgnoreCase("multianewarray")){
            return 4;
        }
        if(bytecode.equalsIgnoreCase("wide")){
            return 3;
        }
        if(bytecode.equalsIgnoreCase("goto_w")||bytecode.equalsIgnoreCase("invokeinterface")|| bytecode.equalsIgnoreCase("jsr_w")){
            return 5;
        }
        if(bytecode.equalsIgnoreCase("lookupswitch")|| bytecode.equalsIgnoreCase("tableswitch")){
            String cases = currentInstruction.substring(currentInstruction.indexOf("{")+1,currentInstruction.indexOf("}")).trim().replace('\n', ' ').replace('\t',' ');
            String returnValue = null;
            if(cases.indexOf("default")!=0){
                returnValue = cases.substring(cases.indexOf(" ")+1);
                returnValue = returnValue.substring(0,returnValue.indexOf(" "));
            }
            else{
                returnValue = cases.substring(cases.indexOf(" ")+1);
                returnValue = returnValue.substring(returnValue.indexOf(":")+1);
                returnValue = returnValue.substring(returnValue.indexOf(" ")+1);
                returnValue = returnValue.substring(0,returnValue.indexOf(" "));
            }
            return Integer.parseInt(returnValue) - currentPC;
        }
        else{
            return 1;
        }
    }

}

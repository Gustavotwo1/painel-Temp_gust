package jbvd;

import javassist.*;
import java.util.*;
import javassist.bytecode.*;
import javax.tools.*;
import javax.tools.DiagnosticCollector;
import javax.tools.Diagnostic;
import java.io.*;
import javax.swing.*;
import javax.swing.text.*;
import java.awt.Color;

public class BytecodeConversion {
    private Main m;

    private static final StyleContext context = new StyleContext();
    private static final Style headingStyle = context.addStyle("headingStyle", null);
    private static final Style counterStyle = context.addStyle("counterStyle",null);
    private static final Style nestedClassNameStyle = context.addStyle("nestedClassNameStyle",null);
    private static final Style compilationErrorsHeadingStyle = context.addStyle("compilationErrorHeadingStyle",null);
    private static final float[] darkGreen = Color.RGBtoHSB(0, 100, 0, null);

    static{
        headingStyle.addAttribute(StyleConstants.Foreground, Color.RED);
        counterStyle.addAttribute(StyleConstants.Foreground, Color.getHSBColor(darkGreen[0], darkGreen[1], darkGreen[2]));
        nestedClassNameStyle.addAttribute(StyleConstants.Underline, true);
        compilationErrorsHeadingStyle.addAttribute(StyleConstants.Bold, true);
        compilationErrorsHeadingStyle.addAttribute(StyleConstants.Underline, true);
        compilationErrorsHeadingStyle.addAttribute(StyleConstants.FontSize, 13);
    }

    public BytecodeConversion(Main m){
        this.m = m;
    }

    public void getNestedClassBytecodes(String name,Document doc)throws Exception{
        doc.insertString(doc.getLength(), "Nested Class Name: "+ name+"\n\n", nestedClassNameStyle);
        ClassPool cp = ClassPool.getDefault();
        cp.insertClassPath(m.getAction().getParentFilePath());
        CtClass cc = cp.get(name);
        ClassFile cf = cc.getClassFile();
        CtMethod[] dmethods = cc.getDeclaredMethods();
        int size2 = dmethods.length;
        doc.insertString(doc.getLength(), "General Information: \n\n", headingStyle);
        doc.insertString(doc.getLength(), "Major Version:\t"+ cf.getMajorVersion()+ "\nMinor Version:\t"+cf.getMinorVersion() + "\nSuperclass:\t" + cf.getSuperclass()+ "\nModifiers:\t"+ Integer.toHexString(cf.getAccessFlags())+ "\n\n", null);
        List list = cf.getFields();
        int n = list.size();
        doc.insertString(doc.getLength(), "Fields:\n\n", headingStyle);
        for(int i=0; i<n; i++){
            FieldInfo finfo = (FieldInfo)list.get(i);
            int acc = finfo.getAccessFlags();
            doc.insertString(doc.getLength(), "Access Flag:\t"+Modifier.toString(AccessFlag.toModifier(acc))+"\tName:\t"+finfo.getName()+"\tDescriptor:\t"+finfo.getDescriptor()+"\n", null);
        }
        String[] infs = cf.getInterfaces();
        if(infs!=null && infs.length > 0){
            doc.insertString(doc.getLength(), "Interfaces:\t"+infs[0], null);
            for (int i = 1; i < infs.length; ++i){
                doc.insertString(doc.getLength(), ", "+infs[i], null);
            }
        }
        list = cf.getMethods();
        n = list.size();
        doc.insertString(doc.getLength(), "\nMethods Information:\n\n", headingStyle);
        for (int i = 0; i < n; ++i) {
            MethodInfo minfo = (MethodInfo)list.get(i);
            int acc = minfo.getAccessFlags();
            doc.insertString(doc.getLength(), Modifier.toString(AccessFlag.toModifier(acc))+ " " + minfo.getName() + "\t"+ minfo.getDescriptor()+"\t", null);
            CodeAttribute ca = minfo.getCodeAttribute();
            doc.insertString(doc.getLength(), "max stack: " + ca.getMaxStack()+ ",   max locals: " + ca.getMaxLocals()+ ", " + "   catch blocks: "+ca.getExceptionTable().size()+ "\n", null);
        }
        doc.insertString(doc.getLength(), "\n", null);
        for(int i=0; i<size2; i++){
            MethodInfo minfo = cf.getMethod(dmethods[i].getName());
            doc.insertString(doc.getLength(), "Bytecode of " + dmethods[i].getName() + " method:\n\n", headingStyle);
            CodeAttribute ca = minfo.getCodeAttribute();
            ConstPool pool = minfo.getConstPool();
            CodeIterator ci = ca.iterator();
            while(ci.hasNext()){
                int index = ci.next();
                String instruction = InstructionPrinter.instructionString(ci,index,pool);
                instruction = JavaConversion.escapeCharacters(instruction);
                doc.insertString(doc.getLength(), InstructionPrinter.instructionString(ci,index,pool), null);
                doc.insertString(doc.getLength(), "\n", null);
            }
            doc.insertString(doc.getLength(), "\n", null);
            doc.insertString(doc.getLength(), "\n", null);
        }
        CtConstructor[] constructors = cc.getDeclaredConstructors();
        for(int i=0;i<constructors.length;i++){
            MethodInfo minfo = constructors[i].getMethodInfo();
            doc.insertString(doc.getLength(), "Bytecode of " + constructors[i].getLongName()+  " (constructor):\n\n", headingStyle);
            CodeAttribute ca = minfo.getCodeAttribute();
            ConstPool pool = minfo.getConstPool();
            CodeIterator ci = ca.iterator();
            while(ci.hasNext()){
                int index = ci.next();
                String instruction = InstructionPrinter.instructionString(ci,index,pool);
                instruction = JavaConversion.escapeCharacters(instruction);
                doc.insertString(doc.getLength(), instruction, null);
                doc.insertString(doc.getLength(), "\n", null);
            }
            doc.insertString(doc.getLength(), "\n", null);
        }
        CtClass[] innerClasses = cc.getNestedClasses();
        if(innerClasses.length >0){
            CtClass innerClass;
            doc.insertString(doc.getLength(), "Nested Classes of " + cc.getName()+" class:\n\n", headingStyle);
            for(int i=0; i<innerClasses.length; i++){
                innerClass = cp.get(innerClasses[i].getName());
                getNestedClassBytecodes(innerClasses[i].getName(),doc);
            }
        }


    }


    public void convertToBytecode(Document doc) throws Exception{
        doc.insertString(doc.getLength(), "", null);
        doc.remove(0, doc.getLength());
        boolean compilationErrors = false;
        if(m.getAction().getFilePath().toLowerCase().endsWith("java")){
            compilationErrors = compileSourceCode(doc);
        }
        if(compilationErrors == false){
            ClassPool cp = new ClassPool();
            cp.insertClassPath(m.getAction().getParentFilePath());
            CtClass cc = cp.get(m.getAction().getFileName());
            ClassFile cf = cc.getClassFile();
            CtMethod[] dmethods = cc.getDeclaredMethods();
            doc.insertString(doc.getLength(), "General Information:\n\n", headingStyle);
            doc.insertString(doc.getLength(), "Major Version:\t" + cf.getMajorVersion() + "\nMinor Version:\t" + cf.getMinorVersion() + "\nSuperclass:\t" + cf.getSuperclass() + "\nModifiers:\t" + Integer.toHexString(cf.getAccessFlags()) + "\n\n", null);
            List list = cf.getFields();
            int n = list.size();
            doc.insertString(doc.getLength(), "Fields:\n\n", headingStyle);
            for(int i = 0; i < n; i++){
                FieldInfo finfo = (FieldInfo) list.get(i);
                int acc = finfo.getAccessFlags();
                doc.insertString(doc.getLength(), "Access Flag:\t" + Modifier.toString(AccessFlag.toModifier(acc)) + "\tName:\t" + finfo.getName() + "\tDescriptor:\t" + finfo.getDescriptor() + "\n", null);
            }
            String[] infs = cf.getInterfaces();
            if(infs != null && infs.length > 0){
                doc.insertString(doc.getLength(), "Interfaces:\t" + infs[0], null);
                for(int i = 1; i < infs.length; ++i){
                    doc.insertString(doc.getLength(), ", " + infs[i], null);
                }
            }
            list = cf.getMethods();
            n = list.size();
            doc.insertString(doc.getLength(), "\nMethods Information:\n\n", headingStyle);
            for(int i = 0; i < n; ++i){
                MethodInfo minfo = (MethodInfo) list.get(i);
                int acc = minfo.getAccessFlags();
                String access = Modifier.toString(AccessFlag.toModifier(acc));
                doc.insertString(doc.getLength(), Modifier.toString(AccessFlag.toModifier(acc)) + " " + minfo.getName() + "\t" + minfo.getDescriptor() + "\t", null);
                CodeAttribute ca = minfo.getCodeAttribute();
                if(access.indexOf("abstract") == -1){
                    doc.insertString(doc.getLength(), "max stack: " + ca.getMaxStack() + ",   max locals: " + ca.getMaxLocals() + ", " + "   catch blocks: " + ca.getExceptionTable().size() + "\n", null);
                }
                else{
                    doc.insertString(doc.getLength(), "\n", null);
                }
            }
            doc.insertString(doc.getLength(), "\n", null);
            for(int i = 0; i < n; i++){
                MethodInfo minfo = (MethodInfo) list.get(i);
                int acc = minfo.getAccessFlags();
                String access = Modifier.toString(AccessFlag.toModifier(acc));
                if(access.indexOf("abstract") == -1){
                    if(!minfo.getName().equalsIgnoreCase("<init>")){
                        doc.insertString(doc.getLength(), "Bytecode of " + minfo.getName() + " method:\n\n", headingStyle);
                        CodeAttribute ca = minfo.getCodeAttribute();
                        ConstPool pool = minfo.getConstPool();
                        CodeIterator ci = ca.iterator();
                        int currentPC = 0;
                        while(ci.hasNext()){
                            doc.insertString(doc.getLength(), currentPC + "    ", counterStyle);
                            int index = ci.next();
                            String instruction = InstructionPrinter.instructionString(ci, index, pool);
                            if(instruction.indexOf('\"') != -1){
                                instruction = JavaConversion.escapeCharacters(instruction);
                            }
                            if(instruction.startsWith("wide")){
                                doc.insertString(doc.getLength(), "wide \n", null);
                                currentPC = currentPC + JavaConversion.calculatePC("wide", "wide", currentPC);
                                doc.insertString(doc.getLength(), currentPC + "    ", counterStyle);
                                instruction = instruction.substring(5);
                            }
                            String bytecode = instruction;
                            if(bytecode.indexOf(" ") != -1){
                                bytecode = instruction.substring(0, instruction.indexOf(" "));
                            }
                            currentPC = currentPC + JavaConversion.calculatePC(bytecode, instruction, currentPC);
                            doc.insertString(doc.getLength(), instruction, null);
                            doc.insertString(doc.getLength(), "\n", null);
                        }
                        doc.insertString(doc.getLength(), "\n", null);
                        doc.insertString(doc.getLength(), "\n", null);
                    }
                }
            }
            CtConstructor[] constructors = cc.getDeclaredConstructors();
            for(int i = 0; i < constructors.length; i++){
                MethodInfo minfo = constructors[i].getMethodInfo();
                doc.insertString(doc.getLength(), "Bytecode of " + constructors[i].getLongName() + " (constructor):\n\n", headingStyle);
                CodeAttribute ca = minfo.getCodeAttribute();
                ConstPool pool = minfo.getConstPool();
                CodeIterator ci = ca.iterator();
                int currentPC = 0;
                while(ci.hasNext()){
                    doc.insertString(doc.getLength(), currentPC + "    ", counterStyle);
                    int index = ci.next();
                    String instruction = InstructionPrinter.instructionString(ci, index, pool);
                    instruction = JavaConversion.escapeCharacters(instruction);
                    String bytecode = instruction;
                    if(bytecode.indexOf(" ") != -1){
                        bytecode = instruction.substring(0, instruction.indexOf(" "));
                    }
                    currentPC = currentPC + JavaConversion.calculatePC(bytecode, instruction, currentPC);
                    doc.insertString(doc.getLength(), instruction, null);
                    doc.insertString(doc.getLength(), "\n", null);
                }
                doc.insertString(doc.getLength(), "\n", null);
            }
            CtClass[] innerClasses = cc.getNestedClasses();
            if(innerClasses.length > 0){
                CtClass innerClass;
                doc.insertString(doc.getLength(), "Nested Classes of " + cc.getName() + " class:\n\n", nestedClassNameStyle);
                for(int i = 0; i < innerClasses.length; i++){
                    innerClass = cp.get(innerClasses[i].getName());
                    getNestedClassBytecodes(innerClasses[i].getName(), doc);
                }
            }
        }

    }

    private boolean compileSourceCode(Document doc) throws Exception{
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        String fp = m.getAction().getFilePath();
        List<File> filesList = new ArrayList<File>();
        filesList.add(new File(fp));
        List<File> clp = new ArrayList<File>();
        File path = new File(m.getAction().getParentFilePath());// path is C:\
        String flag = path.toString(); //flag is C:\
        String pack = m.getAction().getPackageName(); //package is null
        boolean compilationErrors = false;
        while(flag != null){
            path = new File(flag);
            clp.add(path);
            if((path.getName().equals(pack) || pack == null)){
                if(path.getParentFile() != null){
                    clp.add(path.getParentFile());
                }
                break;
            }
            flag = path.getParent();
        }
        int l = 0;
        do{
            l = 0;
            DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<JavaFileObject>();
            StandardJavaFileManager fileManager = compiler.getStandardFileManager(diagnostics, null, null);
            Iterable<? extends JavaFileObject> compilationUnits = fileManager.getJavaFileObjectsFromFiles(filesList);
            fileManager.setLocation(StandardLocation.CLASS_PATH, clp);
            compiler.getTask(null, fileManager, diagnostics, null, null, compilationUnits).call();
            ArrayList<String> errors = new ArrayList(0);
            ArrayList<String> warnings = new ArrayList(0);
            for(Diagnostic diagnostic : diagnostics.getDiagnostics()){
                int appear = 1;
                if(diagnostic.getKind() != Diagnostic.Kind.ERROR){
                    warnings.add(diagnostic.toString());
                }
                else{
                    compilationErrors = true;
                    String error = diagnostic.toString();
                    if(error.indexOf("cannot find symbol") != -1){
                        if(error.indexOf("symbol  : class ") != -1){
                            l++;
                            int startIndex = error.indexOf("symbol  : class ") + 16;
                            int i = 0;
                            int endIndex = 0;
                            while (error.charAt(startIndex + i) != '\n') {
                                endIndex = startIndex + i;
                                i++;
                            }
                            String missingClass = error.substring(startIndex, endIndex + 1);
                            String missingFilePath = filesList.get(0).getParent() + "\\" + missingClass + ".java";
                            filesList.add(new File(missingFilePath));
                            fileManager.close();
                            appear = 0;
                        }
                    }
                    if(appear == 1){
                        errors.add(error);
                    }
                }
            }
            if(errors.size() > 0){
                JOptionPane jop = new JOptionPane();
                jop.showMessageDialog(m.getFrame(), "Compilation errors detected!");
                doc.insertString(doc.getLength(), "The following compilation errors occured:" + "\n\n", compilationErrorsHeadingStyle);
                for(int i = 0; i < errors.size(); i++){
                    doc.insertString(doc.getLength(), errors.get(i) + "\n\n", headingStyle);
                }
            }
        }while(l != 0);
        return compilationErrors;
    }

}

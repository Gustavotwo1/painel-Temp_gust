/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jbvd;

/**
 *
 * @author ΝΙΚΟΛΕΤΑ
 */

import javax.swing.text.*;
import java.awt.Color;
import java.util.*;

public class ReservedWordsPrinter {
    
    private static final StyleContext context = new StyleContext();
    private static final Style reservedWordStyle = context.addStyle("reservedWordStyle", null);
    private static final Style stringStyle = context.addStyle("stringStyle", null);
    private static final float[] darkGreen = Color.RGBtoHSB(255, 140, 0, null);
    
    static{
        reservedWordStyle.addAttribute(StyleConstants.Foreground, Color.BLUE);
        stringStyle.addAttribute(StyleConstants.Foreground, Color.getHSBColor(darkGreen[0], darkGreen[1], darkGreen[2]));
    }

    public static Set<String> keywords = new HashSet<String> (Arrays.asList(
        "assert",
        "abstract", "boolean", "break", "byte",
        "case", "catch", "char", "class",
        "const", "continue", "default", "do",
        "double", "else", "extends", "false", "final",
        "finally", "float", "for", "goto",
        "if", "implements", "import",
        "instanceof", "int", "interface",
        "long", "native", "new", "package",
        "private", "protected", "public",
        "return", "short", "static", "super",
        "switch", "synchronized", "this",
        "throw", "throws", "transient", "true",
        "try", "void", "volatile", "while"));

    public static void printLine(String line, Document doc)throws Exception{
       
        //deal with comments
        //deal with strings
        StringBuilder word = new StringBuilder(0);
        char[] lineArray = line.toCharArray();
        char previousChar=' ', nextChar=' ';
        Boolean isString = false; //for string printing in decompiling
        int slashOccurencies = 0;
        for(int i=0; i<lineArray.length; i++){
            if((lineArray[i] == '"') && ((lineArray[i-1]!='\'') || (lineArray[i+1]!='\'')) && (slashOccurencies % 2 == 0)){
                if(isString == false){
                    isString = true;
                }
                else{
                    isString = false;
                }
                previousChar = '"'; // for typical reason but is is unnecessary
                doc.insertString(doc.getLength(),String.valueOf(lineArray[i]), stringStyle);
                slashOccurencies = 0;
            }
            else if(lineArray[i] == '\\'){
                slashOccurencies++;
                doc.insertString(doc.getLength(),String.valueOf(lineArray[i]), stringStyle);
                previousChar = '\\';
            }
            else if(isString == true){
                doc.insertString(doc.getLength(),String.valueOf(lineArray[i]), stringStyle);
                slashOccurencies = 0;
            }
            else if (Character.isLetter(lineArray[i])){
                word.append(lineArray[i]);
                slashOccurencies = 0;
            }
            else{
                nextChar = lineArray[i];
                if(word.length()!= 0){
                    if(isKeyword(word.toString(), previousChar, nextChar)){
                        doc.insertString(doc.getLength(), word.toString(), reservedWordStyle);
                    }
                    else{
                        doc.insertString(doc.getLength(), word.toString(), null);
                    }
                }
                previousChar = nextChar;
                doc.insertString(doc.getLength(),String.valueOf(nextChar), null);
                word.setLength(0);
                slashOccurencies = 0;
            }
        }

    }

    private static Boolean isKeyword(String word, char previous, char next){
        Boolean isKeyword = false;
        if((previous!= '}') && (previous!='(') && (previous!=' ') && (previous!='\t') && (previous!='.') && (previous!='=') &&  (previous!='/')){ //a keyword is precided by space \t } ( . = /
            return false;
        }
        if((next != '(') && (next != '{') && (next != '[') && (next != ':') && (next!=';') && (next!=' ') && (next!='\t') && (next!='.') && (next!='/')){ // a keyword is followed by { [ space \t ; : /.
            return false;
        }
        if(keywords.contains(word)){
            isKeyword = true;
        }
        return isKeyword;
    }


}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jbvd;

import javax.swing.text.*;
import java.util.*;

/**
 *
 * @author ΝΙΚΟΛΕΤΑ
 */
public class AbstractSyntaxTree {

    private static AbstractSyntaxTreeNode root;

    public AbstractSyntaxTree(int pcValue, String data){
        root = new AbstractSyntaxTreeNode(pcValue, data);
    }

    public AbstractSyntaxTreeNode getRoot(){
        return root;
    }

    public void setRoot(AbstractSyntaxTreeNode node){
        root = node;
    }

    public void addNode(Stack <AbstractSyntaxTreeNode[]> branchNodeStack, AbstractSyntaxTreeNode currentNode, AbstractSyntaxTreeNode newNode, int currentPC){
        AbstractSyntaxTreeNode previousNode;
        int leftPC = -1;
        int rightPC = -1;
        int newPC = newNode.getPcValue();
        do{
            previousNode = currentNode;
            if(currentNode.getLeft() == null){
                leftPC = -1;
            }
            else{
                leftPC = currentNode.getLeft().getPcValue();
            }
            if(currentNode.getRight() == null){
                rightPC = -1;
            }
            else{
                rightPC = currentNode.getRight().getPcValue();
            }
            if((newPC <= rightPC && newPC > leftPC) || (rightPC == leftPC)){
                currentNode = currentNode.getRight();
            }
            else if(newPC < rightPC && newPC < leftPC){
                if(rightPC < leftPC){
                    currentNode = currentNode.getRight();
                }
                else{
                    currentNode = currentNode.getLeft();
                }
            }
            else if(newPC > rightPC && newPC <= leftPC){
                currentNode = currentNode.getLeft();
            }
            else if(newPC > rightPC && newPC > leftPC){
                if(((leftPC > currentNode.getPcValue()) && rightPC < leftPC) || currentNode.getData().startsWith("while")){
                    currentNode = currentNode.getLeft();
                }
                else if(rightPC!=-1 && rightPC < currentNode.getPcValue()){ //do while case
                    currentNode = currentNode.getLeft();
                }
                else{
                    currentNode = currentNode.getRight();
                }
            }
        }while(currentNode!=null && newPC >= currentNode.getPcValue());
        if(previousNode.getRight() == currentNode){
            previousNode.setRight(newNode);
            while(previousNode.getLeft()!=null && previousNode.getLeft().getPcValue() < previousNode.getPcValue()){
                AbstractSyntaxTreeNode temp;
                temp = previousNode.getLeft();
                previousNode.setLeft(null);
                previousNode = temp;
                previousNode.setRight(newNode);

            }
        }
        else{
            previousNode.setLeft(newNode);
        }
        if(newNode.getRight()==null){
            newNode.setRight(currentNode);
        }
        else{
            if(newNode.getLeft()!=null){ //switch case
                newNode.getLeft().setRight(currentNode);
                newNode.setLeft(null);
            }
            else if(currentNode!=null){
                newNode.setLeft(currentNode);
            }
        }
        if(!branchNodeStack.empty() && ((branchNodeStack.peek())[1]) == previousNode){//if case
            if(newNode.getRight()==null){
                newNode.setRight(branchNodeStack.peek()[0].getLeft());
            }
            else{
                newNode.setLeft(branchNodeStack.peek()[0].getLeft());
            }
            branchNodeStack.peek()[0].setLeft(newNode);
            branchNodeStack.pop();
        }
        else if(!branchNodeStack.empty() && newNode.getPcValue() > branchNodeStack.peek()[1].getPcValue()){
            if(branchNodeStack.peek()[0].getLeft()!=null){
                branchNodeStack.peek()[1].setRight(branchNodeStack.peek()[0].getLeft());
            }
            branchNodeStack.pop();
        }
    }

    public AbstractSyntaxTreeNode findNode(AbstractSyntaxTreeNode root, int pcValue){
        AbstractSyntaxTreeNode current = root;
        AbstractSyntaxTreeNode previous = root;
        while(current!=null && current.getPcValue() < pcValue){
            previous = current;
            if(current.getLeft()!=null && current.getRight()!=null){
                int leftValue = current.getLeft().getPcValue();
                int rightValue = current.getRight().getPcValue();
                if(leftValue <= pcValue && rightValue > pcValue){
                    current = current.getLeft();
                }
                else if(leftValue <= pcValue && rightValue <= pcValue && leftValue > rightValue){
                    current = current.getLeft();
                }
                else if(rightValue < current.getPcValue()){
                    current = current.getLeft();
                }
                else{
                    current = current.getRight();
                }
            }
            else if(current.getLeft() == null && current.getRight() != null){
                current = current.getRight();
            }
            else{
                current = current.getLeft();
            }
        }
        if(current.getPcValue() >= pcValue){
            return previous;
        }
        else{
            return current;
        }
    }


    private AbstractSyntaxTreeNode popNode(Stack nodeStack){
        if(!nodeStack.empty()){
            return (AbstractSyntaxTreeNode)nodeStack.pop();
        }
        else{
            return null;
        }
    }


    public void printTree(Document doc)throws Exception{
        AbstractSyntaxTreeNode currentNode = this.getRoot();
        currentNode = currentNode.getRight();
        int identation = 6; //class and method identation
        Stack nodeStack = new Stack();
        while(currentNode!=null){
            if(currentNode.getData().startsWith("}")){ //ends code block
                identation -= 3;
            }
            for(int i=0; i<identation; i++){
                doc.insertString(doc.getLength(), " ", null);
            }
            if(currentNode.getData().startsWith("if") || currentNode.getData().startsWith("else if") || currentNode.getData().startsWith("while") || currentNode.getData().startsWith("}while")){ //deleting excessive brackets
                correctBranchNodeData(currentNode);
                optimizeBranchNodeData(currentNode);
            }
            ReservedWordsPrinter.printLine(currentNode.getData(), doc);
            if(currentNode.getData().endsWith("{")){ //new code block
                identation += 3;
            }
            doc.insertString(doc.getLength(), "\n", null);
            if(currentNode.getLeft()==null && currentNode.getRight()==null){
                currentNode = popNode(nodeStack);
            }
            else if(currentNode.getLeft()==null){
                if((!nodeStack.empty() && nodeStack.peek()==currentNode.getRight())||
                   currentNode.getRight().getPcValue() < currentNode.getPcValue()||
                   (!nodeStack.empty() && currentNode.getRight().getPcValue() > ((AbstractSyntaxTreeNode)nodeStack.peek()).getPcValue())){
                    currentNode = popNode(nodeStack);
                }
                else{
                    currentNode = currentNode.getRight();
                }
            }
            else if(currentNode.getRight()==null){
                if(!nodeStack.empty() && nodeStack.peek()==currentNode.getLeft()||
                   currentNode.getLeft().getPcValue() < currentNode.getPcValue()){
                    currentNode = popNode(nodeStack);
                }
                else{
                    currentNode = currentNode.getLeft();
                }
            }
            else{
                int leftValue = currentNode.getLeft().getPcValue();
                int rightValue = currentNode.getRight().getPcValue();
                int currentValue = currentNode.getPcValue();
                if(leftValue < rightValue){
                    if(leftValue > currentValue){
                        if(nodeStack.empty() || nodeStack.peek()!=currentNode.getRight()){
                            nodeStack.push(currentNode.getRight());
                            currentNode = currentNode.getLeft();
                        }
                    }
                    else{
                       currentNode = currentNode.getRight();
                    }
                }
                else{
                    if(rightValue > currentValue){
                        if(nodeStack.empty() || nodeStack.peek()!=currentNode.getLeft()){
                            nodeStack.push(currentNode.getLeft());
                            currentNode = currentNode.getRight();
                        }
                    }
                    else{
                        currentNode = currentNode.getLeft();
                    }
                }
            }
        }
    }

    protected static void correctBranchNodeData(AbstractSyntaxTreeNode currentNode){
        String currentNodeData = currentNode.getData();
        int leftBrackets = 0;
        int rightBrackets = 0;
        for(int i = 0; i < currentNodeData.length(); i++){
            if(currentNodeData.charAt(i) == '('){
                leftBrackets++;
            }
            else if(currentNodeData.charAt(i) == ')'){
                rightBrackets++;
            }
        }
        for(int i=0; i < leftBrackets - rightBrackets; i++){
            if(currentNode.getData().startsWith("}while")){
                currentNodeData = currentNodeData.replace(");", "));");
            }
            else{
                currentNodeData = currentNodeData.replace("{", "){");
            }
        }
        leftBrackets = 0;
        while((currentNodeData.startsWith("if((") || currentNodeData.startsWith("else if((") || currentNodeData.startsWith("while((") || currentNodeData.startsWith("}while(("))&& (currentNodeData.contains(")){") || currentNodeData.contains("));")) && leftBrackets == 0){
            int initialIndex = currentNodeData.indexOf('(') + 2;
            for(int i = initialIndex; i < currentNodeData.length() - 3; i++){
                if(currentNodeData.charAt(i) == '('){
                    leftBrackets++;
                }
                else if(currentNodeData.charAt(i) == ')' && leftBrackets != 0){
                    leftBrackets--;
                }
            }
            if(leftBrackets == 0){
                currentNodeData = new StringBuilder(currentNodeData).deleteCharAt(currentNodeData.indexOf('(')).toString();
                currentNodeData = new StringBuilder(currentNodeData).deleteCharAt(currentNodeData.lastIndexOf(')')).toString();
            }
        }
        currentNode.setData(currentNodeData);
    }
    
    private void optimizeBranchNodeData(AbstractSyntaxTreeNode currentNode){
        String currentNodeData = currentNode.getData();
        Stack <Integer []> bracketStack = new Stack<Integer []>();
        HashSet<Integer> bracketsToDelete = new HashSet<Integer>();
        ArrayList<Character> data = new ArrayList<Character>();
        for(int i = 3; i < currentNodeData.length()-2; i++){
            if(currentNodeData.charAt(i) == '('){
                if(currentNodeData.charAt(i-2) == '|'){
                    bracketStack.push(new Integer[] {i, 0, 0, 1});
                }
                else{
                    bracketStack.push(new Integer[] {i, 0, 0, 0});
                }
            }
            else if(currentNodeData.charAt(i) == ')'){
                if(bracketStack.peek()[1] != 0 && bracketStack.peek()[2] == 0 || bracketStack.peek()[1] == 0 && bracketStack.peek()[2] == 0 || bracketStack.peek()[3] != 0 && currentNodeData.charAt(i+1) == ')'){
                    bracketsToDelete.add(bracketStack.peek()[0]);
                    bracketsToDelete.add(i);
                }
                bracketStack.pop();
            }
            else if(!bracketStack.empty() && currentNodeData.charAt(i) == '&' && currentNodeData.charAt(i+1) == '&'){
                bracketStack.peek()[1] = 1;
                i++;
            }
            else if(!bracketStack.empty() && currentNodeData.charAt(i) == '|' && currentNodeData.charAt(i+1) == '|'){
                bracketStack.peek()[2] = 1;
                i++;
            }
        }
        for(int i = 0; i < currentNodeData.length(); i++){
            if(!bracketsToDelete.contains(i)){
                data.add(currentNodeData.charAt(i));
            }
        }
        currentNodeData = "";
        for(int i = 0; i < data.size(); i++){
            currentNodeData = currentNodeData + data.get(i);
        }
        currentNode.setData(currentNodeData);
    }

}

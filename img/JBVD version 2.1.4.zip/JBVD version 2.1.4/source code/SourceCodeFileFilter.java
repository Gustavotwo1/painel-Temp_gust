package jbvd;

import java.io.*;

public class SourceCodeFileFilter extends javax.swing.filechooser.FileFilter{
    
    private final String[] okFileExtensions = new String[] {"class","java"};

    SourceCodeFileFilter(){

    }

    public boolean accept(File file){

        for(String extension : okFileExtensions){
            if(file.getName().toLowerCase().endsWith(extension)){
                return true;
            }
            else if(file.isDirectory()){
                return true;
            }
        }
        return false;
    }

    public String getDescription (){
        return "Java Source Code Files";
    }

}

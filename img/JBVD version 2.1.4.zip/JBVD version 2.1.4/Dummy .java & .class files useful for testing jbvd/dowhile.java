public class dowhile{
   public void spin() {
        int i = 0;
	  int j;
	  do{
         	j=1;	
		i+=1;		
        }while(i < 100); 
   }
}

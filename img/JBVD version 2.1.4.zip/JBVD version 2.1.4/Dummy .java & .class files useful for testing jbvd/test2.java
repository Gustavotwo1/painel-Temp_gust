public class test2{
	public int add(int e, String y){
		String[][] a = new String[10][5];
		String s = "abc";
		int r = 1;
		int f=r;
		int g = e;
		String w = y;
		synchronized(s){
			s=y;
		}
		int[] x = new int[4];
		return 1;
      }
}
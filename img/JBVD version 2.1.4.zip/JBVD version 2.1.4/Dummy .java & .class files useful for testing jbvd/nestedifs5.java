public class nestedifs5{

	public nestedifs5(){
		super();
	}

	public int add(){
		Object o = new Object();
		int i=0;
		String s=null;
		String r = "abc";
		if(s!=null || i == 4){
			if(i==0){
				r = "av";
			}
		}
		else{
			i = 0;
		}	
		return 1;
      }
}

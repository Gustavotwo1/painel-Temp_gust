public class whiledowhile2{
	public int add(){
		int i=0;
		String s=null;
		String r = "abc";
		i=1;
		while(i<10){
			s = "abt";
			do{
				i= 1;
			}while(s!=null);			
		}
		i= 1;
		return 1;
      }
}

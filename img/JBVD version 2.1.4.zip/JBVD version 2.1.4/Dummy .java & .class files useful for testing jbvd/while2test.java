public class while2test{
   public void spin() {
        int i = 0;
	  int j = 0;
        while(i < 100) {
         	j=1;	
		i+=1;		
        }
   }
}


public class Hello3{
	public int add(float g,String s,int y, int x, String u){
		float f;
		int[][][] a = new int[10][5][7];
		int [][][] b;
		a[2][3][6] = 1;
		b = a;
		y = a.length;
		f=g;		
		return 1;
	}
}
public class dowhileif{
	public int add(){
		int i=0;
		String s=null;
		String r = "abc";
		i=1;
		do{
			if(s!=null){
				i= 1;
			}
			else{
				i = 0;
			}	
			i++;
		}while(i<10);
		i= 1;
		return 1;
      }
}

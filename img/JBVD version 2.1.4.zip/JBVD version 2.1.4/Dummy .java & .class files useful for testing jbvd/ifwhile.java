public class ifwhile{
	public int add(){
		int i=0;
		String s=null;
		String r = "abc";
		if(s!=null){
			i++;
			while(i<10){
				i++;
			}
			i= 1;
		}
		else{
			i = 0;
		}	
		return 1;
      }
}


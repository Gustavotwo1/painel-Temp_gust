public class test4{
	public int add(){
		int i=3;
		int j=4;
		if(i==0){
			j= 1;
		}
		else if(i==9){
			j = 0;
		}	
		else{
			j=4;
		}
		return 1;
      }
}

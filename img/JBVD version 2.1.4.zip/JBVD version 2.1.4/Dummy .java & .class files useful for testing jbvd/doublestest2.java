public class doublestest2{
	public int add(){
			double d = 2.2;
			int i = 1000000;
			long l1 = 1;
			if (d < 100.0) {
        			i=1;				
    			} 
			else if(d == 100.0){
				i=2;
			}
			else{ 
	        		i=-1;				
    			}
			return i;
      }
}

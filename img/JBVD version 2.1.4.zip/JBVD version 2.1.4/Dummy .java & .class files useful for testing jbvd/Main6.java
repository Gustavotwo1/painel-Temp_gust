import java.io.*;

public class Main6 {
	public static void main(String[] args) throws Exception{
			int i=0;
			try{
				i=10;
			}
			finally{
				i=11;
			}
	}

}

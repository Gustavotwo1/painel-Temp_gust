public class dowhileif2{
	public int add(){
		int i=0;
		String s=null;
		String r = "abc";
		i=1;
		do{
			if(s!=null){
				i= 1;
			}
			else{
				i = 0;
			}	
		}while(i<10);
		i= 1;
		return 1;
      }
}

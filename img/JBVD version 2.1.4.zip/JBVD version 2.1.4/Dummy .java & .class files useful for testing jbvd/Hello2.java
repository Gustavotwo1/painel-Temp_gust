public class Hello2{
	public int add(float g,String s,int y, int x, String u){
		int[][][] a = new int[10][5][7];
		a[2][3][6] = 1;
		y = a.length;		
		return 1;
	}
}
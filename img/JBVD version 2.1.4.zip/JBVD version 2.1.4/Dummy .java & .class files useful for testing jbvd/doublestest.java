public class doublestest{
	public int add(){
			double d = 2.2;
			int i = 1000000;
			long l1 = 1;
        		return 1;				
      }
}

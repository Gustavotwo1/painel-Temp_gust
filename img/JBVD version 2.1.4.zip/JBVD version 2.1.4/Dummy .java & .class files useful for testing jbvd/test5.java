public class test5{
	public int add(){
		int i=3;
		int j=4;
		if(i==0 || i==1){
			j= 1;
		}
		else if(i!=9 || i!=8 && i!=10){
			if(j!=0){
				j = 0;
			}
		}	
		else{
			if(j!=0){
				j = 1;
			}
			j=4;
		}
		return 1;
      }
}

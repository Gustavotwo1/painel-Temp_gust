public class increment{
   public void spin() {
        int i = 0;
	  int j;
	  do{
         	j=1;	
		i-=1;	
		i+=3;
		i+=128;
		i+=129;
		i+=32767;	
		i+=32768;
		i-=32768;
		i-=129;
        }while(i < 100);
	  do{
		i+=128;
	 }while(i < 100);
   }
}

public class nestedwhiles{
	public int add(){
		int i=0;
		String s=null;
		String r = "abc";
		i=1;
		while(i<10){
			s = "abt";
			while(s!=null){
				i= 1;
			}			
			i++;
		}
		i= 1;
		return 1;
      }
}


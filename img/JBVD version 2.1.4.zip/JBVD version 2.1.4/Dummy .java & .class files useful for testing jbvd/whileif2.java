import java.io.*;

public class whileif2{
	public int add(){
		int i=0;
		String q;
		String s=null;
		String r = "abc";
		InputStream input = null;
		String f = null;
		f = "rrr";
		q = f;
		i=1;
		while(i<10){
			if(s!=null){
				i= 1;
			}
			else{
				i = 0;
			}	
			i++;
		}
		i= 1;
		return 1;
      }
}

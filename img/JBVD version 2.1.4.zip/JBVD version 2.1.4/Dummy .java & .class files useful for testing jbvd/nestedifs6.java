public class nestedifs6{

	public nestedifs6(){
		super();
	}

	public int add(){
		Object o = new Object();
		int i=0;
		String s=null;
		String r = "abc";
		if(s!=null){
			if(i==0 || i!=1){
				r = "av";
			}
			i++;
		}
		else{
			i = 0;
		}	
		return 1;
      }
}

public class whileif{
	public int add(){
		int i=0;
		String s=null;
		String r = "abc";
		i=1;
		while(i<10){
			if(s!=null){
				i= 1;
			}
			else{
				i = 0;
			}	
			i++;
		}
		i= 1;
		return 1;
      }
}

import java.util.*;

public class generics{
	public int add(){
		//Stack<Integer> integers = new Stack<Integer>();
		HashMap<Integer, String> instructions = new LinkedHashMap<Integer, String>();
		//HashMap instructions = new LinkedHashMap();
		Stack integers = new Stack();
		//Integer i = 2;
		integers.push(new int[2][14]);
		//integers.push(new int[2]);
		//integers.push(new Stack());
		//integers.push(1);
		//integers.push("a");
		//integers.push(i);
		integers.push(new int[]{1,2});
		//instructions.put(1, "a");
		//instructions.put("a", "a");
		//instructions.put(1, 1);
		//instructions.put("a", 1);
		return integers.size();
      }
}
public class nestedifs4{

	public nestedifs4(){
		super();
	}

	public int add(){
		Object o = new Object();
		int i=0;
		String s=null;
		String r = "abc";
		if(s!=null || i==0){
				r = "av";
		}
		else{
			i = 0;
		}	
		return 1;
      }
}

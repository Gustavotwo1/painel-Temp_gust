public class ArrayInit{
	public int add(int e, String y){
		int[] v = {2,3,4};
		int[][] w = {{1,2}, {3,4}};
		Integer[][] u = {{1,2}, {3,4}};
		String[][] o = {{"a","b"}, {"c","d"}};
		return 1;
      }
}
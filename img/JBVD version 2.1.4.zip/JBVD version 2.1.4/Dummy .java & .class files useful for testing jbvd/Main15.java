import java.io.*;

public class Main15{
	
	private int integer;

       public static void main(String args) throws Exception{
	   
		InputStream input = null;
	   
		    try{
				String t = null;
				args="test";
				t = args;
				try {
                    		input = null;
                	      } catch (Exception e1) {
                    		System.out.println("Exception 1 caught");
                		}
				finally{
					System.out.println("finally 1");
				}
				input = new FileInputStream("c:\\data\\input-text.txt");
				int data = input.read();
				while(data != -1) {
					data = input.read();
				}
			}
			catch(IOException e){
                			try {
                    			input = null;
						System.out.println("try 2");
                			} catch (Exception e1) {
                    			System.out.println("Exception 2 caught");
                			}
					finally{
						System.out.println("finally 2");
					}

			}
			catch(Exception e2){
				System.out.println("Exception 3 caught");
			}
			finally{
				try {
					System.out.println("try 3");
                    		input = null;
				}
				finally{
					System.out.println("finally 3");
				}

			}
    	}
}

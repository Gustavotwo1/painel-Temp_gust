public class whiletest2{
   public void spin() {
        int i = 0;
        int j = 0;
	  if(i < 100 || i > 50) {
            j=1;	
            i+=1;		
        }
        while(i < 100 && i > 50) {
            j=1;	
            i+=1;		
        }
        j = 3;
   }
}

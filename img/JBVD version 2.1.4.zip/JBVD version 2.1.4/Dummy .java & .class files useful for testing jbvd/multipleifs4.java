public class multipleifs4{
	public int add(){
		int i=0;
		String s=null;
		if(i!=3 || s!=null && i!=-1 && i!=2){
			i= 1;
		}
		return 1;
      }
}

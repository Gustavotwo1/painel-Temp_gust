public class nestedifs{
	public int add(){
		int i=0;
		String s=null;
		String r = "abc";
		if(s!=null){
			if(i==0){
				r = "av";
			}
			else if(i == 1){
				r = "ab";
			}
			else{
				r = "ac";
			}
			i= 1;
		}
		else{
			i = 0;
		}	
		return 1;
      }
}

public class nestedifs3{
	public int add(){
		int i=0;
		String s=null;
		String r = "abc";
		if(s!=null){
			if(i==0){
				r = "av";
			}
			else{
				r = "ab";
			}
			i= 1;
		}
		else{
			i = 0;
		}	
		return 1;
      }
}

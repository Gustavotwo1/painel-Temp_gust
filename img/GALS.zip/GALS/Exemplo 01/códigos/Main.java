public class Main
{
  public static void main(String[] args)
  {
    Lexico lexico = new Lexico();
    Sintatico sintatico = new Sintatico();
    Semantico semantico = new Semantico();

    LineNumberReader in = new LineNumberReader(new InputStreamReader(System.in));
    String line = in.readLine();

    lexico.setInput( line );

    try
    {
      sintatico.parse(lexico, semantico);
      System.out.println(" = ");
      System.out.println(trans.getResult());
    }
    catch ( LexicalError e )
    {
      e.printStackTrace();
    }
    catch ( SintaticError e )
    {
      e.printStackTrace();
    }
    catch ( SemanticError e )
    {
      e.printStackTrace();
    }
  }
}

